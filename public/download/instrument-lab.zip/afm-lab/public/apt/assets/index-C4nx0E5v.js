(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function e(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(s){if(s.ep)return;s.ep=!0;const r=e(s);fetch(s.href,r)}})();const er={Si:{color:"#5ca6d6"},Cu:{color:"#dc9961"},B:{color:"#b983db"}},Ya=(i,t=5e3)=>1e9*.1*Math.sqrt(i*16605390666e-37/(2*1602176634e-28*t)),Bl=(i,t=5e3)=>(i*1e-9/.1)**2*2*1602176634e-28*t/16605390666e-37,us=i=>{const t=Math.sin(i*127.1+311.7)*43758.5453;return t-Math.floor(t)};function vo(i,t,e,n){const s=i/(t-1)*30,r=Math.sqrt(us(i*7+1)),a=us(i*7+2)*Math.PI*2,o=r*Math.cos(a),c=r*Math.sin(a),l=us(i*7+3),u=s<8?.72:.035,f=.015+.28*Math.exp(-.5*((s-19)/1.7)**2),d=l<u?"Cu":l<u+f?"B":"Si",p=us(i*7+4),g=d==="Cu"?p<.69?63:65:d==="B"?p<.8?11:10:p<.92?28:p<.97?29:30,v=Ya(g/n,e),m=Bl(v,e);return{event:i+1,element:d,charge:n,massToCharge:m,tof:v,hitX:o,hitY:c,x:o*8,y:c*8,z:s}}class zl{constructor(){this.mode="laser",this.voltage=5e3,this.charge=1,this.total=4096,this.duration=12,this.reset()}reset(){this.rows=[],this.index=0,this.elapsed=0,this.status="idle"}configure(t){if("mode"in t&&!["laser","voltage"].includes(t.mode))throw new RangeError("Unknown pulse mode");if("voltage"in t&&(!Number.isFinite(t.voltage)||t.voltage<2e3||t.voltage>8e3))throw new RangeError("Voltage outside educational range");if("charge"in t&&![1,2].includes(t.charge))throw new RangeError("Unsupported charge state");for(const e of["mode","voltage","charge"])e in t&&(this[e]=t[e]);this.reset()}start(){this.status==="complete"&&this.reset(),this.status="scanning"}pause(){this.status==="scanning"&&(this.status="paused")}get progress(){return this.index/this.total}get batchSize(){return 128}get cycleCount(){return Math.ceil(this.total/this.batchSize)}get sequence(){const t=this.elapsed/this.duration*this.cycleCount,e=Math.min(this.cycleCount-1,Math.floor(t)),n=t-Math.floor(t),s=vo(e*this.batchSize,this.total,this.voltage,this.charge),r=.18+.64*s.tof/Ya(65,this.voltage),a=this.status==="scanning"||this.status==="paused",o=a?n<.12?"pulse":n<.18?"evaporation":n<r?"flight":n<.86?"detection":"waiting":this.status;return{cycle:e,phase:n,row:s,stage:o,pulseOn:a&&n<.12,ionVisible:a&&n>=.18&&n<r,flightProgress:Math.max(0,Math.min(1,(n-.18)/(r-.18))),arrival:r}}get evaporated(){const t=this.elapsed/this.duration*this.cycleCount;return Math.min(this.total,(Math.floor(t)+(t%1>=.18?1:0))*this.batchSize)}tick(t){if(this.status!=="scanning"||!Number.isFinite(t)||t<=0)return;this.elapsed=Math.min(this.duration,this.elapsed+t);const e=this.elapsed/this.duration*this.cycleCount,n=Math.floor(e)+(e%1+1e-8>=.86?1:0),s=Math.min(this.total,n*this.batchSize);for(;this.index<s;)this.rows.push(vo(this.index,this.total,this.voltage,this.charge)),this.index++;this.elapsed>=this.duration-1e-8&&(this.elapsed=this.duration,this.status="complete")}metadata(){return{instrument:"APT",pulse_mode:this.mode,effective_acceleration_V_assumed:this.voltage,flight_length_m_assumed:.1,charge_state_assumed:this.charge,sample:"synthetic_Cu_rich_cap_Si_with_B_enriched_layer",reconstruction:"fixed_linear_back_projection_and_event_order_not_physical_inversion",nominal_volume:"radius_8_nm_depth_30_nm",timing:"32_representative_cycles_in_12_simulation_seconds_each_groups_128_independent_synthetic_events_not_128_ions_per_real_pulse",recording:"batch_committed_after_representative_flight_and_detection_gate",displayed_particle:"one_representative_ion_per_cycle_time_expanded_not_real_pulse_rate",limitations:"no_calibration_mass_overlap_multi_hit_efficiency_or_quantification"}}csv(){const t='"'+JSON.stringify(this.metadata()).replaceAll('"','""')+'"';return["event,synthetic_species,charge_assumed,mass_to_charge_Da_per_e,tof_ns,detector_x_normalized,detector_y_normalized,nominal_x_nm,nominal_y_nm,nominal_depth_nm,metadata",...this.rows.map(e=>[e.event,e.element,e.charge,e.massToCharge,e.tof,e.hitX,e.hitY,e.x,e.y,e.z,t].join(","))].join(`
`)}}const Mn=(i,t,e,n,s)=>({id:i,name:t,ko:e,role:n,check:s}),ss=[Mn("tip","Needle specimen","니들형 시료","Cu-rich 캡·Si·B-rich 층의 가상 니들입니다. 원자가 이온으로 제거되는 파괴 분석을 확대 표현합니다.","시료 고정·형상·관심 영역·FIB 준비 이력과 파손 가능성을 검토합니다."),Mn("electrode","Local electrode","국소 전극","니들 앞의 개구 전극입니다. 강한 전계 형성과 이온 추출의 개념을 나타냅니다.","전극–팁 정렬·개구 오염·제조사 허용 위치를 담당자가 확인합니다."),Mn("laser","Pulsed laser","펄스 레이저","레이저 보조 모드에서 니들 끝을 조사해 전계 증발을 유도합니다. 전압 모드에서는 광선을 숨깁니다.","레이저 정렬·동기·안전 인터록·광학계 상태를 제조사 절차로 확인합니다."),Mn("pulser","HV / pulse generator","고전압 · 펄스 발생기","정전 바이어스와 전압 펄스의 개념입니다. 화면 전압은 이상식의 유효 가속전압 가정입니다.","전압·펄스·트리거 로그를 확인합니다. 고전압부를 열거나 실제 값을 따라 설정하지 마세요."),Mn("flight","Flight path","이온 비행 경로","직선 TOF 경로로 시간과 m/z를 연결합니다. 반사형 경로나 에너지 분산은 모사하지 않습니다.","시간 영점·질량 눈금·정렬·기준 데이터와 잔류가스를 점검합니다."),Mn("detector","Position-sensitive detector","위치 민감 검출기","같은 이벤트의 도착 시간과 XY 위치를 기록해 스펙트럼·히트맵·점군을 누적합니다.","검출기 포화·데드타임·멀티히트·히트 분포와 기준 데이터를 확인합니다."),Mn("cryostat","Cryogenic stage","저온 시료 스테이지","냉각된 시료 환경의 개념입니다. 온도 조절·열전달·증발률은 계산하지 않습니다.","온도 안정화·열접촉·진동·냉각계 경보를 확인합니다."),Mn("vacuum","Vacuum chamber","초고진공 챔버","이온 비행과 시료 환경을 유지하는 진공 계통입니다.","진공 경보·탈가스·로드록 이력·누설 점검 기록을 확인합니다.")],kl=[{id:"signal",name:"검출 이벤트가 적거나 불안정함",parts:["tip","laser","pulser","cryostat"],steps:["시료 파손·고정과 온도 안정화 이력을 확인합니다.","선택 펄스 모드의 정렬·트리거·전압 로그를 기준 데이터와 비교합니다.","조건을 무작정 높이지 말고 취득을 중단한 뒤 담당자와 검토합니다."]},{id:"mass",name:"질량 피크가 넓거나 이동함",parts:["flight","pulser","laser","detector"],steps:["시간 영점·질량 교정과 트리거 동기를 확인합니다.","열 꼬리·에너지 분산·전하 상태·중첩 피크를 함께 검토합니다.","명목 m/z만으로 물질을 확정하지 말고 기준 시료와 비교합니다."]},{id:"map",name:"히트 분포나 재구성이 왜곡됨",parts:["tip","electrode","detector"],steps:["팁–전극 정렬과 검출기의 비정상 히트 분포를 확인합니다.","팁 형상 변화·국소 배율·검출 효율과 재구성 가정을 검토합니다.","TEM 등 별도 구조 정보로 검증하며 점군을 원래 구조와 동일하다고 단정하지 않습니다."]},{id:"vacuum",name:"진공·냉각 상태가 불안정함",parts:["vacuum","cryostat","tip"],steps:["경보·로드록·탈가스·온도 추이를 기록합니다.","취득을 중단하고 제조사의 안전 상태 전환 절차를 따릅니다.","인터록 해제·고전압 접근·저온 부품 직접 접촉은 하지 않습니다."]}];/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const qa="180",Ei={ROTATE:0,DOLLY:1,PAN:2},Mi={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},kc=0,xo=1,Hc=2,Hl=1,Vc=2,mn=3,Ln=0,Ie=1,_n=2,Pn=0,yi=1,Mo=2,So=3,Eo=4,Gc=5,Wn=100,Wc=101,Xc=102,Yc=103,qc=104,jc=200,$c=201,Zc=202,Kc=203,jr=204,$r=205,Jc=206,Qc=207,th=208,eh=209,nh=210,ih=211,sh=212,rh=213,ah=214,Zr=0,Kr=1,Jr=2,wi=3,Qr=4,ta=5,ea=6,na=7,Vl=0,oh=1,lh=2,Dn=0,ch=1,hh=2,uh=3,dh=4,fh=5,ph=6,mh=7,Gl=300,Ri=301,Ci=302,ia=303,sa=304,nr=306,ra=1e3,Yn=1001,aa=1002,Qe=1003,gh=1004,ds=1005,sn=1006,lr=1007,qn=1008,an=1009,Wl=1010,Xl=1011,Zi=1012,ja=1013,$n=1014,vn=1015,rs=1016,$a=1017,Za=1018,Ki=1020,Yl=35902,ql=35899,jl=1021,$l=1022,Je=1023,Ji=1026,Qi=1027,Zl=1028,Ka=1029,Kl=1030,Ja=1031,Qa=1033,Vs=33776,Gs=33777,Ws=33778,Xs=33779,oa=35840,la=35841,ca=35842,ha=35843,ua=36196,da=37492,fa=37496,pa=37808,ma=37809,ga=37810,_a=37811,va=37812,xa=37813,Ma=37814,Sa=37815,Ea=37816,ya=37817,ba=37818,Ta=37819,Aa=37820,wa=37821,Ra=36492,Ca=36494,Pa=36495,Da=36283,La=36284,Ia=36285,Ua=36286,_h=3200,vh=3201,Jl=0,xh=1,Cn="",Ve="srgb",Pi="srgb-linear",js="linear",se="srgb",ii=7680,yo=519,Mh=512,Sh=513,Eh=514,Ql=515,yh=516,bh=517,Th=518,Ah=519,bo=35044,To="300 es",rn=2e3,$s=2001;class Jn{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){const n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){const n=this._listeners;if(n===void 0)return;const s=n[t];if(s!==void 0){const r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){const e=this._listeners;if(e===void 0)return;const n=e[t.type];if(n!==void 0){t.target=this;const s=n.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,t);t.target=null}}}const be=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let Ao=1234567;const bi=Math.PI/180,ts=180/Math.PI;function Ii(){const i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(be[i&255]+be[i>>8&255]+be[i>>16&255]+be[i>>24&255]+"-"+be[t&255]+be[t>>8&255]+"-"+be[t>>16&15|64]+be[t>>24&255]+"-"+be[e&63|128]+be[e>>8&255]+"-"+be[e>>16&255]+be[e>>24&255]+be[n&255]+be[n>>8&255]+be[n>>16&255]+be[n>>24&255]).toLowerCase()}function $t(i,t,e){return Math.max(t,Math.min(e,i))}function to(i,t){return(i%t+t)%t}function wh(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function Rh(i,t,e){return i!==t?(e-i)/(t-i):0}function qi(i,t,e){return(1-e)*i+e*t}function Ch(i,t,e,n){return qi(i,t,1-Math.exp(-e*n))}function Ph(i,t=1){return t-Math.abs(to(i,t*2)-t)}function Dh(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function Lh(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function Ih(i,t){return i+Math.floor(Math.random()*(t-i+1))}function Uh(i,t){return i+Math.random()*(t-i)}function Nh(i){return i*(.5-Math.random())}function Fh(i){i!==void 0&&(Ao=i);let t=Ao+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Oh(i){return i*bi}function Bh(i){return i*ts}function zh(i){return(i&i-1)===0&&i!==0}function kh(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Hh(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Vh(i,t,e,n,s){const r=Math.cos,a=Math.sin,o=r(e/2),c=a(e/2),l=r((t+n)/2),u=a((t+n)/2),f=r((t-n)/2),d=a((t-n)/2),p=r((n-t)/2),g=a((n-t)/2);switch(s){case"XYX":i.set(o*u,c*f,c*d,o*l);break;case"YZY":i.set(c*d,o*u,c*f,o*l);break;case"ZXZ":i.set(c*f,c*d,o*u,o*l);break;case"XZX":i.set(o*u,c*g,c*p,o*l);break;case"YXY":i.set(c*p,o*u,c*g,o*l);break;case"ZYZ":i.set(c*g,c*p,o*u,o*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function xi(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function we(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const tc={DEG2RAD:bi,RAD2DEG:ts,generateUUID:Ii,clamp:$t,euclideanModulo:to,mapLinear:wh,inverseLerp:Rh,lerp:qi,damp:Ch,pingpong:Ph,smoothstep:Dh,smootherstep:Lh,randInt:Ih,randFloat:Uh,randFloatSpread:Nh,seededRandom:Fh,degToRad:Oh,radToDeg:Bh,isPowerOfTwo:zh,ceilPowerOfTwo:kh,floorPowerOfTwo:Hh,setQuaternionFromProperEuler:Vh,normalize:we,denormalize:xi};class Ot{constructor(t=0,e=0){Ot.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=$t(this.x,t.x,e.x),this.y=$t(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=$t(this.x,t,e),this.y=$t(this.y,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar($t(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos($t(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*n-a*s+t.x,this.y=r*s+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Zn{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,a,o){let c=n[s+0],l=n[s+1],u=n[s+2],f=n[s+3];const d=r[a+0],p=r[a+1],g=r[a+2],v=r[a+3];if(o===0){t[e+0]=c,t[e+1]=l,t[e+2]=u,t[e+3]=f;return}if(o===1){t[e+0]=d,t[e+1]=p,t[e+2]=g,t[e+3]=v;return}if(f!==v||c!==d||l!==p||u!==g){let m=1-o;const h=c*d+l*p+u*g+f*v,T=h>=0?1:-1,b=1-h*h;if(b>Number.EPSILON){const R=Math.sqrt(b),w=Math.atan2(R,h*T);m=Math.sin(m*w)/R,o=Math.sin(o*w)/R}const E=o*T;if(c=c*m+d*E,l=l*m+p*E,u=u*m+g*E,f=f*m+v*E,m===1-o){const R=1/Math.sqrt(c*c+l*l+u*u+f*f);c*=R,l*=R,u*=R,f*=R}}t[e]=c,t[e+1]=l,t[e+2]=u,t[e+3]=f}static multiplyQuaternionsFlat(t,e,n,s,r,a){const o=n[s],c=n[s+1],l=n[s+2],u=n[s+3],f=r[a],d=r[a+1],p=r[a+2],g=r[a+3];return t[e]=o*g+u*f+c*p-l*d,t[e+1]=c*g+u*d+l*f-o*p,t[e+2]=l*g+u*p+o*d-c*f,t[e+3]=u*g-o*f-c*d-l*p,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,s=t._y,r=t._z,a=t._order,o=Math.cos,c=Math.sin,l=o(n/2),u=o(s/2),f=o(r/2),d=c(n/2),p=c(s/2),g=c(r/2);switch(a){case"XYZ":this._x=d*u*f+l*p*g,this._y=l*p*f-d*u*g,this._z=l*u*g+d*p*f,this._w=l*u*f-d*p*g;break;case"YXZ":this._x=d*u*f+l*p*g,this._y=l*p*f-d*u*g,this._z=l*u*g-d*p*f,this._w=l*u*f+d*p*g;break;case"ZXY":this._x=d*u*f-l*p*g,this._y=l*p*f+d*u*g,this._z=l*u*g+d*p*f,this._w=l*u*f-d*p*g;break;case"ZYX":this._x=d*u*f-l*p*g,this._y=l*p*f+d*u*g,this._z=l*u*g-d*p*f,this._w=l*u*f+d*p*g;break;case"YZX":this._x=d*u*f+l*p*g,this._y=l*p*f+d*u*g,this._z=l*u*g-d*p*f,this._w=l*u*f-d*p*g;break;case"XZY":this._x=d*u*f-l*p*g,this._y=l*p*f-d*u*g,this._z=l*u*g+d*p*f,this._w=l*u*f+d*p*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],s=e[4],r=e[8],a=e[1],o=e[5],c=e[9],l=e[2],u=e[6],f=e[10],d=n+o+f;if(d>0){const p=.5/Math.sqrt(d+1);this._w=.25/p,this._x=(u-c)*p,this._y=(r-l)*p,this._z=(a-s)*p}else if(n>o&&n>f){const p=2*Math.sqrt(1+n-o-f);this._w=(u-c)/p,this._x=.25*p,this._y=(s+a)/p,this._z=(r+l)/p}else if(o>f){const p=2*Math.sqrt(1+o-n-f);this._w=(r-l)/p,this._x=(s+a)/p,this._y=.25*p,this._z=(c+u)/p}else{const p=2*Math.sqrt(1+f-n-o);this._w=(a-s)/p,this._x=(r+l)/p,this._y=(c+u)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs($t(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,s=t._y,r=t._z,a=t._w,o=e._x,c=e._y,l=e._z,u=e._w;return this._x=n*u+a*o+s*l-r*c,this._y=s*u+a*c+r*o-n*l,this._z=r*u+a*l+n*c-s*o,this._w=a*u-n*o-s*c-r*l,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);const n=this._x,s=this._y,r=this._z,a=this._w;let o=a*t._w+n*t._x+s*t._y+r*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=n,this._y=s,this._z=r,this;const c=1-o*o;if(c<=Number.EPSILON){const p=1-e;return this._w=p*a+e*this._w,this._x=p*n+e*this._x,this._y=p*s+e*this._y,this._z=p*r+e*this._z,this.normalize(),this}const l=Math.sqrt(c),u=Math.atan2(l,o),f=Math.sin((1-e)*u)/l,d=Math.sin(e*u)/l;return this._w=a*f+this._w*d,this._x=n*f+this._x*d,this._y=s*f+this._y*d,this._z=r*f+this._z*d,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(t),s*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class I{constructor(t=0,e=0,n=0){I.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(wo.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(wo.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,s=this.z,r=t.elements,a=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*a,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*a,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*a,this}applyQuaternion(t){const e=this.x,n=this.y,s=this.z,r=t.x,a=t.y,o=t.z,c=t.w,l=2*(a*s-o*n),u=2*(o*e-r*s),f=2*(r*n-a*e);return this.x=e+c*l+a*f-o*u,this.y=n+c*u+o*l-r*f,this.z=s+c*f+r*u-a*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=$t(this.x,t.x,e.x),this.y=$t(this.y,t.y,e.y),this.z=$t(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=$t(this.x,t,e),this.y=$t(this.y,t,e),this.z=$t(this.z,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar($t(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,s=t.y,r=t.z,a=e.x,o=e.y,c=e.z;return this.x=s*c-r*o,this.y=r*a-n*c,this.z=n*o-s*a,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return cr.copy(this).projectOnVector(t),this.sub(cr)}reflect(t){return this.sub(cr.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos($t(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const cr=new I,wo=new Zn;class Wt{constructor(t,e,n,s,r,a,o,c,l){Wt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,a,o,c,l)}set(t,e,n,s,r,a,o,c,l){const u=this.elements;return u[0]=t,u[1]=s,u[2]=o,u[3]=e,u[4]=r,u[5]=c,u[6]=n,u[7]=a,u[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,s=e.elements,r=this.elements,a=n[0],o=n[3],c=n[6],l=n[1],u=n[4],f=n[7],d=n[2],p=n[5],g=n[8],v=s[0],m=s[3],h=s[6],T=s[1],b=s[4],E=s[7],R=s[2],w=s[5],C=s[8];return r[0]=a*v+o*T+c*R,r[3]=a*m+o*b+c*w,r[6]=a*h+o*E+c*C,r[1]=l*v+u*T+f*R,r[4]=l*m+u*b+f*w,r[7]=l*h+u*E+f*C,r[2]=d*v+p*T+g*R,r[5]=d*m+p*b+g*w,r[8]=d*h+p*E+g*C,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],u=t[8];return e*a*u-e*o*l-n*r*u+n*o*c+s*r*l-s*a*c}invert(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],u=t[8],f=u*a-o*l,d=o*c-u*r,p=l*r-a*c,g=e*f+n*d+s*p;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/g;return t[0]=f*v,t[1]=(s*l-u*n)*v,t[2]=(o*n-s*a)*v,t[3]=d*v,t[4]=(u*e-s*c)*v,t[5]=(s*r-o*e)*v,t[6]=p*v,t[7]=(n*c-l*e)*v,t[8]=(a*e-n*r)*v,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,a,o){const c=Math.cos(r),l=Math.sin(r);return this.set(n*c,n*l,-n*(c*a+l*o)+a+t,-s*l,s*c,-s*(-l*a+c*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(hr.makeScale(t,e)),this}rotate(t){return this.premultiply(hr.makeRotation(-t)),this}translate(t,e){return this.premultiply(hr.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const hr=new Wt;function ec(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function Zs(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Gh(){const i=Zs("canvas");return i.style.display="block",i}const Ro={};function es(i){i in Ro||(Ro[i]=!0,console.warn(i))}function Wh(i,t,e){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(t,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}const Co=new Wt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Po=new Wt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Xh(){const i={enabled:!0,workingColorSpace:Pi,spaces:{},convert:function(s,r,a){return this.enabled===!1||r===a||!r||!a||(this.spaces[r].transfer===se&&(s.r=xn(s.r),s.g=xn(s.g),s.b=xn(s.b)),this.spaces[r].primaries!==this.spaces[a].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===se&&(s.r=Ti(s.r),s.g=Ti(s.g),s.b=Ti(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===Cn?js:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,a){return s.copy(this.spaces[r].toXYZ).multiply(this.spaces[a].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(s,r){return es("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(s,r)},toWorkingColorSpace:function(s,r){return es("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(s,r)}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[Pi]:{primaries:t,whitePoint:n,transfer:js,toXYZ:Co,fromXYZ:Po,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:Ve},outputColorSpaceConfig:{drawingBufferColorSpace:Ve}},[Ve]:{primaries:t,whitePoint:n,transfer:se,toXYZ:Co,fromXYZ:Po,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:Ve}}}),i}const Jt=Xh();function xn(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Ti(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let si;class Yh{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{si===void 0&&(si=Zs("canvas")),si.width=t.width,si.height=t.height;const s=si.getContext("2d");t instanceof ImageData?s.putImageData(t,0,0):s.drawImage(t,0,0,t.width,t.height),n=si}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=Zs("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=xn(r[a]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(xn(e[n]/255)*255):e[n]=xn(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let qh=0;class eo{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:qh++}),this.uuid=Ii(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):e instanceof VideoFrame?t.set(e.displayHeight,e.displayWidth,0):e!==null?t.set(e.width,e.height,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(ur(s[a].image)):r.push(ur(s[a]))}else r=ur(s);n.url=r}return e||(t.images[this.uuid]=n),n}}function ur(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Yh.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let jh=0;const dr=new I;class Ue extends Jn{constructor(t=Ue.DEFAULT_IMAGE,e=Ue.DEFAULT_MAPPING,n=Yn,s=Yn,r=sn,a=qn,o=Je,c=an,l=Ue.DEFAULT_ANISOTROPY,u=Cn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:jh++}),this.uuid=Ii(),this.name="",this.source=new eo(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new Ot(0,0),this.repeat=new Ot(1,1),this.center=new Ot(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Wt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(dr).x}get height(){return this.source.getSize(dr).y}get depth(){return this.source.getSize(dr).z}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const e in t){const n=t[e];if(n===void 0){console.warn(`THREE.Texture.setValues(): parameter '${e}' has value of undefined.`);continue}const s=this[e];if(s===void 0){console.warn(`THREE.Texture.setValues(): property '${e}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Gl)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case ra:t.x=t.x-Math.floor(t.x);break;case Yn:t.x=t.x<0?0:1;break;case aa:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case ra:t.y=t.y-Math.floor(t.y);break;case Yn:t.y=t.y<0?0:1;break;case aa:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}Ue.DEFAULT_IMAGE=null;Ue.DEFAULT_MAPPING=Gl;Ue.DEFAULT_ANISOTROPY=1;class fe{constructor(t=0,e=0,n=0,s=1){fe.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,s=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*s+a[12]*r,this.y=a[1]*e+a[5]*n+a[9]*s+a[13]*r,this.z=a[2]*e+a[6]*n+a[10]*s+a[14]*r,this.w=a[3]*e+a[7]*n+a[11]*s+a[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r;const c=t.elements,l=c[0],u=c[4],f=c[8],d=c[1],p=c[5],g=c[9],v=c[2],m=c[6],h=c[10];if(Math.abs(u-d)<.01&&Math.abs(f-v)<.01&&Math.abs(g-m)<.01){if(Math.abs(u+d)<.1&&Math.abs(f+v)<.1&&Math.abs(g+m)<.1&&Math.abs(l+p+h-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const b=(l+1)/2,E=(p+1)/2,R=(h+1)/2,w=(u+d)/4,C=(f+v)/4,L=(g+m)/4;return b>E&&b>R?b<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(b),s=w/n,r=C/n):E>R?E<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(E),n=w/s,r=L/s):R<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(R),n=C/r,s=L/r),this.set(n,s,r,e),this}let T=Math.sqrt((m-g)*(m-g)+(f-v)*(f-v)+(d-u)*(d-u));return Math.abs(T)<.001&&(T=1),this.x=(m-g)/T,this.y=(f-v)/T,this.z=(d-u)/T,this.w=Math.acos((l+p+h-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=$t(this.x,t.x,e.x),this.y=$t(this.y,t.y,e.y),this.z=$t(this.z,t.z,e.z),this.w=$t(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=$t(this.x,t,e),this.y=$t(this.y,t,e),this.z=$t(this.z,t,e),this.w=$t(this.w,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar($t(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class $h extends Jn{constructor(t=1,e=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:sn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=n.depth,this.scissor=new fe(0,0,t,e),this.scissorTest=!1,this.viewport=new fe(0,0,t,e);const s={width:t,height:e,depth:n.depth},r=new Ue(s);this.textures=[];const a=n.count;for(let o=0;o<a;o++)this.textures[o]=r.clone(),this.textures[o].isRenderTargetTexture=!0,this.textures[o].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(t={}){const e={minFilter:sn,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),t!==null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=n,this.textures[s].isArrayTexture=this.textures[s].image.depth>1;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,n=t.textures.length;e<n;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;const s=Object.assign({},t.textures[e].image);this.textures[e].source=new eo(s)}return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Kn extends $h{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class nc extends Ue{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Qe,this.minFilter=Qe,this.wrapR=Yn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class Zh extends Ue{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Qe,this.minFilter=Qe,this.wrapR=Yn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class as{constructor(t=new I(1/0,1/0,1/0),e=new I(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(je.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(je.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=je.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,je):je.fromBufferAttribute(r,a),je.applyMatrix4(t.matrixWorld),this.expandByPoint(je);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),fs.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),fs.copy(n.boundingBox)),fs.applyMatrix4(t.matrixWorld),this.union(fs)}const s=t.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,je),je.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Oi),ps.subVectors(this.max,Oi),ri.subVectors(t.a,Oi),ai.subVectors(t.b,Oi),oi.subVectors(t.c,Oi),Sn.subVectors(ai,ri),En.subVectors(oi,ai),On.subVectors(ri,oi);let e=[0,-Sn.z,Sn.y,0,-En.z,En.y,0,-On.z,On.y,Sn.z,0,-Sn.x,En.z,0,-En.x,On.z,0,-On.x,-Sn.y,Sn.x,0,-En.y,En.x,0,-On.y,On.x,0];return!fr(e,ri,ai,oi,ps)||(e=[1,0,0,0,1,0,0,0,1],!fr(e,ri,ai,oi,ps))?!1:(ms.crossVectors(Sn,En),e=[ms.x,ms.y,ms.z],fr(e,ri,ai,oi,ps))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,je).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(je).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(cn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),cn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),cn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),cn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),cn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),cn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),cn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),cn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(cn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const cn=[new I,new I,new I,new I,new I,new I,new I,new I],je=new I,fs=new as,ri=new I,ai=new I,oi=new I,Sn=new I,En=new I,On=new I,Oi=new I,ps=new I,ms=new I,Bn=new I;function fr(i,t,e,n,s){for(let r=0,a=i.length-3;r<=a;r+=3){Bn.fromArray(i,r);const o=s.x*Math.abs(Bn.x)+s.y*Math.abs(Bn.y)+s.z*Math.abs(Bn.z),c=t.dot(Bn),l=e.dot(Bn),u=n.dot(Bn);if(Math.max(-Math.max(c,l,u),Math.min(c,l,u))>o)return!1}return!0}const Kh=new as,Bi=new I,pr=new I;class os{constructor(t=new I,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):Kh.setFromPoints(t).getCenter(n);let s=0;for(let r=0,a=t.length;r<a;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Bi.subVectors(t,this.center);const e=Bi.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(Bi,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(pr.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Bi.copy(t.center).add(pr)),this.expandByPoint(Bi.copy(t.center).sub(pr))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}const hn=new I,mr=new I,gs=new I,yn=new I,gr=new I,_s=new I,_r=new I;class ls{constructor(t=new I,e=new I(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,hn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=hn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(hn.copy(this.origin).addScaledVector(this.direction,e),hn.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){mr.copy(t).add(e).multiplyScalar(.5),gs.copy(e).sub(t).normalize(),yn.copy(this.origin).sub(mr);const r=t.distanceTo(e)*.5,a=-this.direction.dot(gs),o=yn.dot(this.direction),c=-yn.dot(gs),l=yn.lengthSq(),u=Math.abs(1-a*a);let f,d,p,g;if(u>0)if(f=a*c-o,d=a*o-c,g=r*u,f>=0)if(d>=-g)if(d<=g){const v=1/u;f*=v,d*=v,p=f*(f+a*d+2*o)+d*(a*f+d+2*c)+l}else d=r,f=Math.max(0,-(a*d+o)),p=-f*f+d*(d+2*c)+l;else d=-r,f=Math.max(0,-(a*d+o)),p=-f*f+d*(d+2*c)+l;else d<=-g?(f=Math.max(0,-(-a*r+o)),d=f>0?-r:Math.min(Math.max(-r,-c),r),p=-f*f+d*(d+2*c)+l):d<=g?(f=0,d=Math.min(Math.max(-r,-c),r),p=d*(d+2*c)+l):(f=Math.max(0,-(a*r+o)),d=f>0?r:Math.min(Math.max(-r,-c),r),p=-f*f+d*(d+2*c)+l);else d=a>0?-r:r,f=Math.max(0,-(a*d+o)),p=-f*f+d*(d+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,f),s&&s.copy(mr).addScaledVector(gs,d),p}intersectSphere(t,e){hn.subVectors(t.center,this.origin);const n=hn.dot(this.direction),s=hn.dot(hn)-n*n,r=t.radius*t.radius;if(s>r)return null;const a=Math.sqrt(r-s),o=n-a,c=n+a;return c<0?null:o<0?this.at(c,e):this.at(o,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,a,o,c;const l=1/this.direction.x,u=1/this.direction.y,f=1/this.direction.z,d=this.origin;return l>=0?(n=(t.min.x-d.x)*l,s=(t.max.x-d.x)*l):(n=(t.max.x-d.x)*l,s=(t.min.x-d.x)*l),u>=0?(r=(t.min.y-d.y)*u,a=(t.max.y-d.y)*u):(r=(t.max.y-d.y)*u,a=(t.min.y-d.y)*u),n>a||r>s||((r>n||isNaN(n))&&(n=r),(a<s||isNaN(s))&&(s=a),f>=0?(o=(t.min.z-d.z)*f,c=(t.max.z-d.z)*f):(o=(t.max.z-d.z)*f,c=(t.min.z-d.z)*f),n>c||o>s)||((o>n||n!==n)&&(n=o),(c<s||s!==s)&&(s=c),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,hn)!==null}intersectTriangle(t,e,n,s,r){gr.subVectors(e,t),_s.subVectors(n,t),_r.crossVectors(gr,_s);let a=this.direction.dot(_r),o;if(a>0){if(s)return null;o=1}else if(a<0)o=-1,a=-a;else return null;yn.subVectors(this.origin,t);const c=o*this.direction.dot(_s.crossVectors(yn,_s));if(c<0)return null;const l=o*this.direction.dot(gr.cross(yn));if(l<0||c+l>a)return null;const u=-o*yn.dot(_r);return u<0?null:this.at(u/a,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class ce{constructor(t,e,n,s,r,a,o,c,l,u,f,d,p,g,v,m){ce.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,a,o,c,l,u,f,d,p,g,v,m)}set(t,e,n,s,r,a,o,c,l,u,f,d,p,g,v,m){const h=this.elements;return h[0]=t,h[4]=e,h[8]=n,h[12]=s,h[1]=r,h[5]=a,h[9]=o,h[13]=c,h[2]=l,h[6]=u,h[10]=f,h[14]=d,h[3]=p,h[7]=g,h[11]=v,h[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new ce().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){const e=this.elements,n=t.elements,s=1/li.setFromMatrixColumn(t,0).length(),r=1/li.setFromMatrixColumn(t,1).length(),a=1/li.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,s=t.y,r=t.z,a=Math.cos(n),o=Math.sin(n),c=Math.cos(s),l=Math.sin(s),u=Math.cos(r),f=Math.sin(r);if(t.order==="XYZ"){const d=a*u,p=a*f,g=o*u,v=o*f;e[0]=c*u,e[4]=-c*f,e[8]=l,e[1]=p+g*l,e[5]=d-v*l,e[9]=-o*c,e[2]=v-d*l,e[6]=g+p*l,e[10]=a*c}else if(t.order==="YXZ"){const d=c*u,p=c*f,g=l*u,v=l*f;e[0]=d+v*o,e[4]=g*o-p,e[8]=a*l,e[1]=a*f,e[5]=a*u,e[9]=-o,e[2]=p*o-g,e[6]=v+d*o,e[10]=a*c}else if(t.order==="ZXY"){const d=c*u,p=c*f,g=l*u,v=l*f;e[0]=d-v*o,e[4]=-a*f,e[8]=g+p*o,e[1]=p+g*o,e[5]=a*u,e[9]=v-d*o,e[2]=-a*l,e[6]=o,e[10]=a*c}else if(t.order==="ZYX"){const d=a*u,p=a*f,g=o*u,v=o*f;e[0]=c*u,e[4]=g*l-p,e[8]=d*l+v,e[1]=c*f,e[5]=v*l+d,e[9]=p*l-g,e[2]=-l,e[6]=o*c,e[10]=a*c}else if(t.order==="YZX"){const d=a*c,p=a*l,g=o*c,v=o*l;e[0]=c*u,e[4]=v-d*f,e[8]=g*f+p,e[1]=f,e[5]=a*u,e[9]=-o*u,e[2]=-l*u,e[6]=p*f+g,e[10]=d-v*f}else if(t.order==="XZY"){const d=a*c,p=a*l,g=o*c,v=o*l;e[0]=c*u,e[4]=-f,e[8]=l*u,e[1]=d*f+v,e[5]=a*u,e[9]=p*f-g,e[2]=g*f-p,e[6]=o*u,e[10]=v*f+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Jh,t,Qh)}lookAt(t,e,n){const s=this.elements;return Oe.subVectors(t,e),Oe.lengthSq()===0&&(Oe.z=1),Oe.normalize(),bn.crossVectors(n,Oe),bn.lengthSq()===0&&(Math.abs(n.z)===1?Oe.x+=1e-4:Oe.z+=1e-4,Oe.normalize(),bn.crossVectors(n,Oe)),bn.normalize(),vs.crossVectors(Oe,bn),s[0]=bn.x,s[4]=vs.x,s[8]=Oe.x,s[1]=bn.y,s[5]=vs.y,s[9]=Oe.y,s[2]=bn.z,s[6]=vs.z,s[10]=Oe.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,s=e.elements,r=this.elements,a=n[0],o=n[4],c=n[8],l=n[12],u=n[1],f=n[5],d=n[9],p=n[13],g=n[2],v=n[6],m=n[10],h=n[14],T=n[3],b=n[7],E=n[11],R=n[15],w=s[0],C=s[4],L=s[8],S=s[12],M=s[1],P=s[5],F=s[9],k=s[13],j=s[2],W=s[6],Y=s[10],K=s[14],H=s[3],st=s[7],V=s[11],at=s[15];return r[0]=a*w+o*M+c*j+l*H,r[4]=a*C+o*P+c*W+l*st,r[8]=a*L+o*F+c*Y+l*V,r[12]=a*S+o*k+c*K+l*at,r[1]=u*w+f*M+d*j+p*H,r[5]=u*C+f*P+d*W+p*st,r[9]=u*L+f*F+d*Y+p*V,r[13]=u*S+f*k+d*K+p*at,r[2]=g*w+v*M+m*j+h*H,r[6]=g*C+v*P+m*W+h*st,r[10]=g*L+v*F+m*Y+h*V,r[14]=g*S+v*k+m*K+h*at,r[3]=T*w+b*M+E*j+R*H,r[7]=T*C+b*P+E*W+R*st,r[11]=T*L+b*F+E*Y+R*V,r[15]=T*S+b*k+E*K+R*at,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],a=t[1],o=t[5],c=t[9],l=t[13],u=t[2],f=t[6],d=t[10],p=t[14],g=t[3],v=t[7],m=t[11],h=t[15];return g*(+r*c*f-s*l*f-r*o*d+n*l*d+s*o*p-n*c*p)+v*(+e*c*p-e*l*d+r*a*d-s*a*p+s*l*u-r*c*u)+m*(+e*l*f-e*o*p-r*a*f+n*a*p+r*o*u-n*l*u)+h*(-s*o*u-e*c*f+e*o*d+s*a*f-n*a*d+n*c*u)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],c=t[6],l=t[7],u=t[8],f=t[9],d=t[10],p=t[11],g=t[12],v=t[13],m=t[14],h=t[15],T=f*m*l-v*d*l+v*c*p-o*m*p-f*c*h+o*d*h,b=g*d*l-u*m*l-g*c*p+a*m*p+u*c*h-a*d*h,E=u*v*l-g*f*l+g*o*p-a*v*p-u*o*h+a*f*h,R=g*f*c-u*v*c-g*o*d+a*v*d+u*o*m-a*f*m,w=e*T+n*b+s*E+r*R;if(w===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const C=1/w;return t[0]=T*C,t[1]=(v*d*r-f*m*r-v*s*p+n*m*p+f*s*h-n*d*h)*C,t[2]=(o*m*r-v*c*r+v*s*l-n*m*l-o*s*h+n*c*h)*C,t[3]=(f*c*r-o*d*r-f*s*l+n*d*l+o*s*p-n*c*p)*C,t[4]=b*C,t[5]=(u*m*r-g*d*r+g*s*p-e*m*p-u*s*h+e*d*h)*C,t[6]=(g*c*r-a*m*r-g*s*l+e*m*l+a*s*h-e*c*h)*C,t[7]=(a*d*r-u*c*r+u*s*l-e*d*l-a*s*p+e*c*p)*C,t[8]=E*C,t[9]=(g*f*r-u*v*r-g*n*p+e*v*p+u*n*h-e*f*h)*C,t[10]=(a*v*r-g*o*r+g*n*l-e*v*l-a*n*h+e*o*h)*C,t[11]=(u*o*r-a*f*r-u*n*l+e*f*l+a*n*p-e*o*p)*C,t[12]=R*C,t[13]=(u*v*s-g*f*s+g*n*d-e*v*d-u*n*m+e*f*m)*C,t[14]=(g*o*s-a*v*s-g*n*c+e*v*c+a*n*m-e*o*m)*C,t[15]=(a*f*s-u*o*s+u*n*c-e*f*c-a*n*d+e*o*d)*C,this}scale(t){const e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),s=Math.sin(e),r=1-n,a=t.x,o=t.y,c=t.z,l=r*a,u=r*o;return this.set(l*a+n,l*o-s*c,l*c+s*o,0,l*o+s*c,u*o+n,u*c-s*a,0,l*c-s*o,u*c+s*a,r*c*c+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,a){return this.set(1,n,r,0,t,1,a,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){const s=this.elements,r=e._x,a=e._y,o=e._z,c=e._w,l=r+r,u=a+a,f=o+o,d=r*l,p=r*u,g=r*f,v=a*u,m=a*f,h=o*f,T=c*l,b=c*u,E=c*f,R=n.x,w=n.y,C=n.z;return s[0]=(1-(v+h))*R,s[1]=(p+E)*R,s[2]=(g-b)*R,s[3]=0,s[4]=(p-E)*w,s[5]=(1-(d+h))*w,s[6]=(m+T)*w,s[7]=0,s[8]=(g+b)*C,s[9]=(m-T)*C,s[10]=(1-(d+v))*C,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){const s=this.elements;let r=li.set(s[0],s[1],s[2]).length();const a=li.set(s[4],s[5],s[6]).length(),o=li.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],$e.copy(this);const l=1/r,u=1/a,f=1/o;return $e.elements[0]*=l,$e.elements[1]*=l,$e.elements[2]*=l,$e.elements[4]*=u,$e.elements[5]*=u,$e.elements[6]*=u,$e.elements[8]*=f,$e.elements[9]*=f,$e.elements[10]*=f,e.setFromRotationMatrix($e),n.x=r,n.y=a,n.z=o,this}makePerspective(t,e,n,s,r,a,o=rn,c=!1){const l=this.elements,u=2*r/(e-t),f=2*r/(n-s),d=(e+t)/(e-t),p=(n+s)/(n-s);let g,v;if(c)g=r/(a-r),v=a*r/(a-r);else if(o===rn)g=-(a+r)/(a-r),v=-2*a*r/(a-r);else if(o===$s)g=-a/(a-r),v=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=u,l[4]=0,l[8]=d,l[12]=0,l[1]=0,l[5]=f,l[9]=p,l[13]=0,l[2]=0,l[6]=0,l[10]=g,l[14]=v,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,s,r,a,o=rn,c=!1){const l=this.elements,u=2/(e-t),f=2/(n-s),d=-(e+t)/(e-t),p=-(n+s)/(n-s);let g,v;if(c)g=1/(a-r),v=a/(a-r);else if(o===rn)g=-2/(a-r),v=-(a+r)/(a-r);else if(o===$s)g=-1/(a-r),v=-r/(a-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=u,l[4]=0,l[8]=0,l[12]=d,l[1]=0,l[5]=f,l[9]=0,l[13]=p,l[2]=0,l[6]=0,l[10]=g,l[14]=v,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}}const li=new I,$e=new ce,Jh=new I(0,0,0),Qh=new I(1,1,1),bn=new I,vs=new I,Oe=new I,Do=new ce,Lo=new Zn;class on{constructor(t=0,e=0,n=0,s=on.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const s=t.elements,r=s[0],a=s[4],o=s[8],c=s[1],l=s[5],u=s[9],f=s[2],d=s[6],p=s[10];switch(e){case"XYZ":this._y=Math.asin($t(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-u,p),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(d,l),this._z=0);break;case"YXZ":this._x=Math.asin(-$t(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-f,r),this._z=0);break;case"ZXY":this._x=Math.asin($t(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-f,p),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-$t(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(d,p),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin($t(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-u,l),this._y=Math.atan2(-f,r)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-$t(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,l),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-u,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Do.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Do,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Lo.setFromEuler(this),this.setFromQuaternion(Lo,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}on.DEFAULT_ORDER="XYZ";class no{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let tu=0;const Io=new I,ci=new Zn,un=new ce,xs=new I,zi=new I,eu=new I,nu=new Zn,Uo=new I(1,0,0),No=new I(0,1,0),Fo=new I(0,0,1),Oo={type:"added"},iu={type:"removed"},hi={type:"childadded",child:null},vr={type:"childremoved",child:null};class ve extends Jn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:tu++}),this.uuid=Ii(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=ve.DEFAULT_UP.clone();const t=new I,e=new on,n=new Zn,s=new I(1,1,1);function r(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new ce},normalMatrix:{value:new Wt}}),this.matrix=new ce,this.matrixWorld=new ce,this.matrixAutoUpdate=ve.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=ve.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new no,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return ci.setFromAxisAngle(t,e),this.quaternion.multiply(ci),this}rotateOnWorldAxis(t,e){return ci.setFromAxisAngle(t,e),this.quaternion.premultiply(ci),this}rotateX(t){return this.rotateOnAxis(Uo,t)}rotateY(t){return this.rotateOnAxis(No,t)}rotateZ(t){return this.rotateOnAxis(Fo,t)}translateOnAxis(t,e){return Io.copy(t).applyQuaternion(this.quaternion),this.position.add(Io.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(Uo,t)}translateY(t){return this.translateOnAxis(No,t)}translateZ(t){return this.translateOnAxis(Fo,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(un.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?xs.copy(t):xs.set(t,e,n);const s=this.parent;this.updateWorldMatrix(!0,!1),zi.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?un.lookAt(zi,xs,this.up):un.lookAt(xs,zi,this.up),this.quaternion.setFromRotationMatrix(un),s&&(un.extractRotation(s.matrixWorld),ci.setFromRotationMatrix(un),this.quaternion.premultiply(ci.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(Oo),hi.child=t,this.dispatchEvent(hi),hi.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(iu),vr.child=t,this.dispatchEvent(vr),vr.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),un.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),un.multiply(t.parent.matrixWorld)),t.applyMatrix4(un),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(Oo),hi.child=t,this.dispatchEvent(hi),hi.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){const a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(zi,t,eu),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(zi,nu,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){const n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(o=>({...o})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(t),s.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const c=o.shapes;if(Array.isArray(c))for(let l=0,u=c.length;l<u;l++){const f=c[l];r(t.shapes,f)}else r(t.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(r(t.materials,this.material[c]));s.material=o}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){const c=this.animations[o];s.animations.push(r(t.animations,c))}}if(e){const o=a(t.geometries),c=a(t.materials),l=a(t.textures),u=a(t.images),f=a(t.shapes),d=a(t.skeletons),p=a(t.animations),g=a(t.nodes);o.length>0&&(n.geometries=o),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),u.length>0&&(n.images=u),f.length>0&&(n.shapes=f),d.length>0&&(n.skeletons=d),p.length>0&&(n.animations=p),g.length>0&&(n.nodes=g)}return n.object=s,n;function a(o){const c=[];for(const l in o){const u=o[l];delete u.metadata,c.push(u)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const s=t.children[n];this.add(s.clone())}return this}}ve.DEFAULT_UP=new I(0,1,0);ve.DEFAULT_MATRIX_AUTO_UPDATE=!0;ve.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Ze=new I,dn=new I,xr=new I,fn=new I,ui=new I,di=new I,Bo=new I,Mr=new I,Sr=new I,Er=new I,yr=new fe,br=new fe,Tr=new fe;class We{constructor(t=new I,e=new I,n=new I){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),Ze.subVectors(t,e),s.cross(Ze);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){Ze.subVectors(s,e),dn.subVectors(n,e),xr.subVectors(t,e);const a=Ze.dot(Ze),o=Ze.dot(dn),c=Ze.dot(xr),l=dn.dot(dn),u=dn.dot(xr),f=a*l-o*o;if(f===0)return r.set(0,0,0),null;const d=1/f,p=(l*c-o*u)*d,g=(a*u-o*c)*d;return r.set(1-p-g,g,p)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,fn)===null?!1:fn.x>=0&&fn.y>=0&&fn.x+fn.y<=1}static getInterpolation(t,e,n,s,r,a,o,c){return this.getBarycoord(t,e,n,s,fn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,fn.x),c.addScaledVector(a,fn.y),c.addScaledVector(o,fn.z),c)}static getInterpolatedAttribute(t,e,n,s,r,a){return yr.setScalar(0),br.setScalar(0),Tr.setScalar(0),yr.fromBufferAttribute(t,e),br.fromBufferAttribute(t,n),Tr.fromBufferAttribute(t,s),a.setScalar(0),a.addScaledVector(yr,r.x),a.addScaledVector(br,r.y),a.addScaledVector(Tr,r.z),a}static isFrontFacing(t,e,n,s){return Ze.subVectors(n,e),dn.subVectors(t,e),Ze.cross(dn).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Ze.subVectors(this.c,this.b),dn.subVectors(this.a,this.b),Ze.cross(dn).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return We.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return We.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,s,r){return We.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return We.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return We.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,s=this.b,r=this.c;let a,o;ui.subVectors(s,n),di.subVectors(r,n),Mr.subVectors(t,n);const c=ui.dot(Mr),l=di.dot(Mr);if(c<=0&&l<=0)return e.copy(n);Sr.subVectors(t,s);const u=ui.dot(Sr),f=di.dot(Sr);if(u>=0&&f<=u)return e.copy(s);const d=c*f-u*l;if(d<=0&&c>=0&&u<=0)return a=c/(c-u),e.copy(n).addScaledVector(ui,a);Er.subVectors(t,r);const p=ui.dot(Er),g=di.dot(Er);if(g>=0&&p<=g)return e.copy(r);const v=p*l-c*g;if(v<=0&&l>=0&&g<=0)return o=l/(l-g),e.copy(n).addScaledVector(di,o);const m=u*g-p*f;if(m<=0&&f-u>=0&&p-g>=0)return Bo.subVectors(r,s),o=(f-u)/(f-u+(p-g)),e.copy(s).addScaledVector(Bo,o);const h=1/(m+v+d);return a=v*h,o=d*h,e.copy(n).addScaledVector(ui,a).addScaledVector(di,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const ic={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Tn={h:0,s:0,l:0},Ms={h:0,s:0,l:0};function Ar(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}class jt{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Ve){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Jt.colorSpaceToWorking(this,e),this}setRGB(t,e,n,s=Jt.workingColorSpace){return this.r=t,this.g=e,this.b=n,Jt.colorSpaceToWorking(this,s),this}setHSL(t,e,n,s=Jt.workingColorSpace){if(t=to(t,1),e=$t(e,0,1),n=$t(n,0,1),e===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+e):n+e-n*e,a=2*n-r;this.r=Ar(a,r,t+1/3),this.g=Ar(a,r,t),this.b=Ar(a,r,t-1/3)}return Jt.colorSpaceToWorking(this,s),this}setStyle(t,e=Ve){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r;const a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){const r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Ve){const n=ic[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=xn(t.r),this.g=xn(t.g),this.b=xn(t.b),this}copyLinearToSRGB(t){return this.r=Ti(t.r),this.g=Ti(t.g),this.b=Ti(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Ve){return Jt.workingToColorSpace(Te.copy(this),t),Math.round($t(Te.r*255,0,255))*65536+Math.round($t(Te.g*255,0,255))*256+Math.round($t(Te.b*255,0,255))}getHexString(t=Ve){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Jt.workingColorSpace){Jt.workingToColorSpace(Te.copy(this),e);const n=Te.r,s=Te.g,r=Te.b,a=Math.max(n,s,r),o=Math.min(n,s,r);let c,l;const u=(o+a)/2;if(o===a)c=0,l=0;else{const f=a-o;switch(l=u<=.5?f/(a+o):f/(2-a-o),a){case n:c=(s-r)/f+(s<r?6:0);break;case s:c=(r-n)/f+2;break;case r:c=(n-s)/f+4;break}c/=6}return t.h=c,t.s=l,t.l=u,t}getRGB(t,e=Jt.workingColorSpace){return Jt.workingToColorSpace(Te.copy(this),e),t.r=Te.r,t.g=Te.g,t.b=Te.b,t}getStyle(t=Ve){Jt.workingToColorSpace(Te.copy(this),t);const e=Te.r,n=Te.g,s=Te.b;return t!==Ve?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(Tn),this.setHSL(Tn.h+t,Tn.s+e,Tn.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Tn),t.getHSL(Ms);const n=qi(Tn.h,Ms.h,e),s=qi(Tn.s,Ms.s,e),r=qi(Tn.l,Ms.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Te=new jt;jt.NAMES=ic;let su=0;class Qn extends Jn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:su++}),this.uuid=Ii(),this.name="",this.type="Material",this.blending=yi,this.side=Ln,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=jr,this.blendDst=$r,this.blendEquation=Wn,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new jt(0,0,0),this.blendAlpha=0,this.depthFunc=wi,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=yo,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=ii,this.stencilZFail=ii,this.stencilZPass=ii,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}const s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==yi&&(n.blending=this.blending),this.side!==Ln&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==jr&&(n.blendSrc=this.blendSrc),this.blendDst!==$r&&(n.blendDst=this.blendDst),this.blendEquation!==Wn&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==wi&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==yo&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==ii&&(n.stencilFail=this.stencilFail),this.stencilZFail!==ii&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==ii&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){const a=[];for(const o in r){const c=r[o];delete c.metadata,a.push(c)}return a}if(e){const r=s(t.textures),a=s(t.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}class Ks extends Qn{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new jt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new on,this.combine=Vl,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const ge=new I,Ss=new Ot;let ru=0;class qe{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:ru++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=bo,this.updateRanges=[],this.gpuType=vn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Ss.fromBufferAttribute(this,e),Ss.applyMatrix3(t),this.setXY(e,Ss.x,Ss.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)ge.fromBufferAttribute(this,e),ge.applyMatrix3(t),this.setXYZ(e,ge.x,ge.y,ge.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)ge.fromBufferAttribute(this,e),ge.applyMatrix4(t),this.setXYZ(e,ge.x,ge.y,ge.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)ge.fromBufferAttribute(this,e),ge.applyNormalMatrix(t),this.setXYZ(e,ge.x,ge.y,ge.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)ge.fromBufferAttribute(this,e),ge.transformDirection(t),this.setXYZ(e,ge.x,ge.y,ge.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=xi(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=we(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=xi(e,this.array)),e}setX(t,e){return this.normalized&&(e=we(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=xi(e,this.array)),e}setY(t,e){return this.normalized&&(e=we(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=xi(e,this.array)),e}setZ(t,e){return this.normalized&&(e=we(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=xi(e,this.array)),e}setW(t,e){return this.normalized&&(e=we(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=we(e,this.array),n=we(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=we(e,this.array),n=we(n,this.array),s=we(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=we(e,this.array),n=we(n,this.array),s=we(s,this.array),r=we(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==bo&&(t.usage=this.usage),t}}class sc extends qe{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class rc extends qe{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class me extends qe{constructor(t,e,n){super(new Float32Array(t),e,n)}}let au=0;const He=new ce,wr=new ve,fi=new I,Be=new as,ki=new as,Ee=new I;class Pe extends Jn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:au++}),this.uuid=Ii(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(ec(t)?rc:sc)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Wt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return He.makeRotationFromQuaternion(t),this.applyMatrix4(He),this}rotateX(t){return He.makeRotationX(t),this.applyMatrix4(He),this}rotateY(t){return He.makeRotationY(t),this.applyMatrix4(He),this}rotateZ(t){return He.makeRotationZ(t),this.applyMatrix4(He),this}translate(t,e,n){return He.makeTranslation(t,e,n),this.applyMatrix4(He),this}scale(t,e,n){return He.makeScale(t,e,n),this.applyMatrix4(He),this}lookAt(t){return wr.lookAt(t),wr.updateMatrix(),this.applyMatrix4(wr.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(fi).negate(),this.translate(fi.x,fi.y,fi.z),this}setFromPoints(t){const e=this.getAttribute("position");if(e===void 0){const n=[];for(let s=0,r=t.length;s<r;s++){const a=t[s];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new me(n,3))}else{const n=Math.min(t.length,e.count);for(let s=0;s<n;s++){const r=t[s];e.setXYZ(s,r.x,r.y,r.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new as);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new I(-1/0,-1/0,-1/0),new I(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){const r=e[n];Be.setFromBufferAttribute(r),this.morphTargetsRelative?(Ee.addVectors(this.boundingBox.min,Be.min),this.boundingBox.expandByPoint(Ee),Ee.addVectors(this.boundingBox.max,Be.max),this.boundingBox.expandByPoint(Ee)):(this.boundingBox.expandByPoint(Be.min),this.boundingBox.expandByPoint(Be.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new os);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new I,1/0);return}if(t){const n=this.boundingSphere.center;if(Be.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){const o=e[r];ki.setFromBufferAttribute(o),this.morphTargetsRelative?(Ee.addVectors(Be.min,ki.min),Be.expandByPoint(Ee),Ee.addVectors(Be.max,ki.max),Be.expandByPoint(Ee)):(Be.expandByPoint(ki.min),Be.expandByPoint(ki.max))}Be.getCenter(n);let s=0;for(let r=0,a=t.count;r<a;r++)Ee.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(Ee));if(e)for(let r=0,a=e.length;r<a;r++){const o=e[r],c=this.morphTargetsRelative;for(let l=0,u=o.count;l<u;l++)Ee.fromBufferAttribute(o,l),c&&(fi.fromBufferAttribute(t,l),Ee.add(fi)),s=Math.max(s,n.distanceToSquared(Ee))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=e.position,s=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new qe(new Float32Array(4*n.count),4));const a=this.getAttribute("tangent"),o=[],c=[];for(let L=0;L<n.count;L++)o[L]=new I,c[L]=new I;const l=new I,u=new I,f=new I,d=new Ot,p=new Ot,g=new Ot,v=new I,m=new I;function h(L,S,M){l.fromBufferAttribute(n,L),u.fromBufferAttribute(n,S),f.fromBufferAttribute(n,M),d.fromBufferAttribute(r,L),p.fromBufferAttribute(r,S),g.fromBufferAttribute(r,M),u.sub(l),f.sub(l),p.sub(d),g.sub(d);const P=1/(p.x*g.y-g.x*p.y);isFinite(P)&&(v.copy(u).multiplyScalar(g.y).addScaledVector(f,-p.y).multiplyScalar(P),m.copy(f).multiplyScalar(p.x).addScaledVector(u,-g.x).multiplyScalar(P),o[L].add(v),o[S].add(v),o[M].add(v),c[L].add(m),c[S].add(m),c[M].add(m))}let T=this.groups;T.length===0&&(T=[{start:0,count:t.count}]);for(let L=0,S=T.length;L<S;++L){const M=T[L],P=M.start,F=M.count;for(let k=P,j=P+F;k<j;k+=3)h(t.getX(k+0),t.getX(k+1),t.getX(k+2))}const b=new I,E=new I,R=new I,w=new I;function C(L){R.fromBufferAttribute(s,L),w.copy(R);const S=o[L];b.copy(S),b.sub(R.multiplyScalar(R.dot(S))).normalize(),E.crossVectors(w,S);const P=E.dot(c[L])<0?-1:1;a.setXYZW(L,b.x,b.y,b.z,P)}for(let L=0,S=T.length;L<S;++L){const M=T[L],P=M.start,F=M.count;for(let k=P,j=P+F;k<j;k+=3)C(t.getX(k+0)),C(t.getX(k+1)),C(t.getX(k+2))}}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new qe(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let d=0,p=n.count;d<p;d++)n.setXYZ(d,0,0,0);const s=new I,r=new I,a=new I,o=new I,c=new I,l=new I,u=new I,f=new I;if(t)for(let d=0,p=t.count;d<p;d+=3){const g=t.getX(d+0),v=t.getX(d+1),m=t.getX(d+2);s.fromBufferAttribute(e,g),r.fromBufferAttribute(e,v),a.fromBufferAttribute(e,m),u.subVectors(a,r),f.subVectors(s,r),u.cross(f),o.fromBufferAttribute(n,g),c.fromBufferAttribute(n,v),l.fromBufferAttribute(n,m),o.add(u),c.add(u),l.add(u),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(v,c.x,c.y,c.z),n.setXYZ(m,l.x,l.y,l.z)}else for(let d=0,p=e.count;d<p;d+=3)s.fromBufferAttribute(e,d+0),r.fromBufferAttribute(e,d+1),a.fromBufferAttribute(e,d+2),u.subVectors(a,r),f.subVectors(s,r),u.cross(f),n.setXYZ(d+0,u.x,u.y,u.z),n.setXYZ(d+1,u.x,u.y,u.z),n.setXYZ(d+2,u.x,u.y,u.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Ee.fromBufferAttribute(t,e),Ee.normalize(),t.setXYZ(e,Ee.x,Ee.y,Ee.z)}toNonIndexed(){function t(o,c){const l=o.array,u=o.itemSize,f=o.normalized,d=new l.constructor(c.length*u);let p=0,g=0;for(let v=0,m=c.length;v<m;v++){o.isInterleavedBufferAttribute?p=c[v]*o.data.stride+o.offset:p=c[v]*u;for(let h=0;h<u;h++)d[g++]=l[p++]}return new qe(d,u,f)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new Pe,n=this.index.array,s=this.attributes;for(const o in s){const c=s[o],l=t(c,n);e.setAttribute(o,l)}const r=this.morphAttributes;for(const o in r){const c=[],l=r[o];for(let u=0,f=l.length;u<f;u++){const d=l[u],p=t(d,n);c.push(p)}e.morphAttributes[o]=c}e.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,c=a.length;o<c;o++){const l=a[o];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const c in n){const l=n[c];t.data.attributes[c]=l.toJSON(t.data)}const s={};let r=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],u=[];for(let f=0,d=l.length;f<d;f++){const p=l[f];u.push(p.toJSON(t.data))}u.length>0&&(s[c]=u,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(t.data.boundingSphere=o.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone());const s=t.attributes;for(const l in s){const u=s[l];this.setAttribute(l,u.clone(e))}const r=t.morphAttributes;for(const l in r){const u=[],f=r[l];for(let d=0,p=f.length;d<p;d++)u.push(f[d].clone(e));this.morphAttributes[l]=u}this.morphTargetsRelative=t.morphTargetsRelative;const a=t.groups;for(let l=0,u=a.length;l<u;l++){const f=a[l];this.addGroup(f.start,f.count,f.materialIndex)}const o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());const c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const zo=new ce,zn=new ls,Es=new os,ko=new I,ys=new I,bs=new I,Ts=new I,Rr=new I,As=new I,Ho=new I,ws=new I;class Xe extends ve{constructor(t=new Pe,e=new Ks){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){const n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(s,t);const o=this.morphTargetInfluences;if(r&&o){As.set(0,0,0);for(let c=0,l=r.length;c<l;c++){const u=o[c],f=r[c];u!==0&&(Rr.fromBufferAttribute(f,t),a?As.addScaledVector(Rr,u):As.addScaledVector(Rr.sub(e),u))}e.add(As)}return e}raycast(t,e){const n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Es.copy(n.boundingSphere),Es.applyMatrix4(r),zn.copy(t.ray).recast(t.near),!(Es.containsPoint(zn.origin)===!1&&(zn.intersectSphere(Es,ko)===null||zn.origin.distanceToSquared(ko)>(t.far-t.near)**2))&&(zo.copy(r).invert(),zn.copy(t.ray).applyMatrix4(zo),!(n.boundingBox!==null&&zn.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,zn)))}_computeIntersections(t,e,n){let s;const r=this.geometry,a=this.material,o=r.index,c=r.attributes.position,l=r.attributes.uv,u=r.attributes.uv1,f=r.attributes.normal,d=r.groups,p=r.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,v=d.length;g<v;g++){const m=d[g],h=a[m.materialIndex],T=Math.max(m.start,p.start),b=Math.min(o.count,Math.min(m.start+m.count,p.start+p.count));for(let E=T,R=b;E<R;E+=3){const w=o.getX(E),C=o.getX(E+1),L=o.getX(E+2);s=Rs(this,h,t,n,l,u,f,w,C,L),s&&(s.faceIndex=Math.floor(E/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{const g=Math.max(0,p.start),v=Math.min(o.count,p.start+p.count);for(let m=g,h=v;m<h;m+=3){const T=o.getX(m),b=o.getX(m+1),E=o.getX(m+2);s=Rs(this,a,t,n,l,u,f,T,b,E),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}else if(c!==void 0)if(Array.isArray(a))for(let g=0,v=d.length;g<v;g++){const m=d[g],h=a[m.materialIndex],T=Math.max(m.start,p.start),b=Math.min(c.count,Math.min(m.start+m.count,p.start+p.count));for(let E=T,R=b;E<R;E+=3){const w=E,C=E+1,L=E+2;s=Rs(this,h,t,n,l,u,f,w,C,L),s&&(s.faceIndex=Math.floor(E/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{const g=Math.max(0,p.start),v=Math.min(c.count,p.start+p.count);for(let m=g,h=v;m<h;m+=3){const T=m,b=m+1,E=m+2;s=Rs(this,a,t,n,l,u,f,T,b,E),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}}}function ou(i,t,e,n,s,r,a,o){let c;if(t.side===Ie?c=n.intersectTriangle(a,r,s,!0,o):c=n.intersectTriangle(s,r,a,t.side===Ln,o),c===null)return null;ws.copy(o),ws.applyMatrix4(i.matrixWorld);const l=e.ray.origin.distanceTo(ws);return l<e.near||l>e.far?null:{distance:l,point:ws.clone(),object:i}}function Rs(i,t,e,n,s,r,a,o,c,l){i.getVertexPosition(o,ys),i.getVertexPosition(c,bs),i.getVertexPosition(l,Ts);const u=ou(i,t,e,n,ys,bs,Ts,Ho);if(u){const f=new I;We.getBarycoord(Ho,ys,bs,Ts,f),s&&(u.uv=We.getInterpolatedAttribute(s,o,c,l,f,new Ot)),r&&(u.uv1=We.getInterpolatedAttribute(r,o,c,l,f,new Ot)),a&&(u.normal=We.getInterpolatedAttribute(a,o,c,l,f,new I),u.normal.dot(n.direction)>0&&u.normal.multiplyScalar(-1));const d={a:o,b:c,c:l,normal:new I,materialIndex:0};We.getNormal(ys,bs,Ts,d.normal),u.face=d,u.barycoord=f}return u}class Ui extends Pe{constructor(t=1,e=1,n=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:a};const o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);const c=[],l=[],u=[],f=[];let d=0,p=0;g("z","y","x",-1,-1,n,e,t,a,r,0),g("z","y","x",1,-1,n,e,-t,a,r,1),g("x","z","y",1,1,t,n,e,s,a,2),g("x","z","y",1,-1,t,n,-e,s,a,3),g("x","y","z",1,-1,t,e,n,s,r,4),g("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(c),this.setAttribute("position",new me(l,3)),this.setAttribute("normal",new me(u,3)),this.setAttribute("uv",new me(f,2));function g(v,m,h,T,b,E,R,w,C,L,S){const M=E/C,P=R/L,F=E/2,k=R/2,j=w/2,W=C+1,Y=L+1;let K=0,H=0;const st=new I;for(let V=0;V<Y;V++){const at=V*P-k;for(let Et=0;Et<W;Et++){const ht=Et*M-F;st[v]=ht*T,st[m]=at*b,st[h]=j,l.push(st.x,st.y,st.z),st[v]=0,st[m]=0,st[h]=w>0?1:-1,u.push(st.x,st.y,st.z),f.push(Et/C),f.push(1-V/L),K+=1}}for(let V=0;V<L;V++)for(let at=0;at<C;at++){const Et=d+at+W*V,ht=d+at+W*(V+1),It=d+(at+1)+W*(V+1),Dt=d+(at+1)+W*V;c.push(Et,ht,Dt),c.push(ht,It,Dt),H+=6}o.addGroup(p,H,S),p+=H,d+=K}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Ui(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function Di(i){const t={};for(const e in i){t[e]={};for(const n in i[e]){const s=i[e][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone():Array.isArray(s)?t[e][n]=s.slice():t[e][n]=s}}return t}function Re(i){const t={};for(let e=0;e<i.length;e++){const n=Di(i[e]);for(const s in n)t[s]=n[s]}return t}function lu(i){const t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function ac(i){const t=i.getRenderTarget();return t===null?i.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Jt.workingColorSpace}const cu={clone:Di,merge:Re};var hu=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,uu=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class In extends Qn{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=hu,this.fragmentShader=uu,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Di(t.uniforms),this.uniformsGroups=lu(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const s in this.uniforms){const a=this.uniforms[s].value;a&&a.isTexture?e.uniforms[s]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[s]={type:"m4",value:a.toArray()}:e.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}}class oc extends ve{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ce,this.projectionMatrix=new ce,this.projectionMatrixInverse=new ce,this.coordinateSystem=rn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const An=new I,Vo=new Ot,Go=new Ot;class Ge extends oc{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=ts*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(bi*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return ts*2*Math.atan(Math.tan(bi*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){An.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(An.x,An.y).multiplyScalar(-t/An.z),An.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(An.x,An.y).multiplyScalar(-t/An.z)}getViewSize(t,e){return this.getViewBounds(t,Vo,Go),e.subVectors(Go,Vo)}setViewOffset(t,e,n,s,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(bi*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s;const a=this.view;if(this.view!==null&&this.view.enabled){const c=a.fullWidth,l=a.fullHeight;r+=a.offsetX*s/c,e-=a.offsetY*n/l,s*=a.width/c,n*=a.height/l}const o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}const pi=-90,mi=1;class du extends ve{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new Ge(pi,mi,t,e);s.layers=this.layers,this.add(s);const r=new Ge(pi,mi,t,e);r.layers=this.layers,this.add(r);const a=new Ge(pi,mi,t,e);a.layers=this.layers,this.add(a);const o=new Ge(pi,mi,t,e);o.layers=this.layers,this.add(o);const c=new Ge(pi,mi,t,e);c.layers=this.layers,this.add(c);const l=new Ge(pi,mi,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,s,r,a,o,c]=e;for(const l of e)this.remove(l);if(t===rn)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===$s)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[r,a,o,c,l,u]=this.children,f=t.getRenderTarget(),d=t.getActiveCubeFace(),p=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;const v=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,s),t.render(e,r),t.setRenderTarget(n,1,s),t.render(e,a),t.setRenderTarget(n,2,s),t.render(e,o),t.setRenderTarget(n,3,s),t.render(e,c),t.setRenderTarget(n,4,s),t.render(e,l),n.texture.generateMipmaps=v,t.setRenderTarget(n,5,s),t.render(e,u),t.setRenderTarget(f,d,p),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class lc extends Ue{constructor(t=[],e=Ri,n,s,r,a,o,c,l,u){super(t,e,n,s,r,a,o,c,l,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class fu extends Kn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];this.texture=new lc(s),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Ui(5,5,5),r=new In({name:"CubemapFromEquirect",uniforms:Di(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ie,blending:Pn});r.uniforms.tEquirect.value=e;const a=new Xe(s,r),o=e.minFilter;return e.minFilter===qn&&(e.minFilter=sn),new du(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e=!0,n=!0,s=!0){const r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,s);t.setRenderTarget(r)}}class Xi extends ve{constructor(){super(),this.isGroup=!0,this.type="Group"}}const pu={type:"move"};class Cr{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Xi,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Xi,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new I,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new I),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Xi,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new I,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new I),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,a=null;const o=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){a=!0;for(const v of t.hand.values()){const m=e.getJointPose(v,n),h=this._getHandJoint(l,v);m!==null&&(h.matrix.fromArray(m.transform.matrix),h.matrix.decompose(h.position,h.rotation,h.scale),h.matrixWorldNeedsUpdate=!0,h.jointRadius=m.radius),h.visible=m!==null}const u=l.joints["index-finger-tip"],f=l.joints["thumb-tip"],d=u.position.distanceTo(f.position),p=.02,g=.005;l.inputState.pinching&&d>p+g?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&d<=p-g&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(pu)))}return o!==null&&(o.visible=s!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new Xi;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}class mu extends ve{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new on,this.environmentIntensity=1,this.environmentRotation=new on,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}}const Pr=new I,gu=new I,_u=new Wt;class Rn{constructor(t=new I(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const s=Pr.subVectors(n,e).cross(gu.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){const n=t.delta(Pr),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||_u.getNormalMatrix(t),s=this.coplanarPoint(Pr).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const kn=new os,vu=new Ot(.5,.5),Cs=new I;class io{constructor(t=new Rn,e=new Rn,n=new Rn,s=new Rn,r=new Rn,a=new Rn){this.planes=[t,e,n,s,r,a]}set(t,e,n,s,r,a){const o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=rn,n=!1){const s=this.planes,r=t.elements,a=r[0],o=r[1],c=r[2],l=r[3],u=r[4],f=r[5],d=r[6],p=r[7],g=r[8],v=r[9],m=r[10],h=r[11],T=r[12],b=r[13],E=r[14],R=r[15];if(s[0].setComponents(l-a,p-u,h-g,R-T).normalize(),s[1].setComponents(l+a,p+u,h+g,R+T).normalize(),s[2].setComponents(l+o,p+f,h+v,R+b).normalize(),s[3].setComponents(l-o,p-f,h-v,R-b).normalize(),n)s[4].setComponents(c,d,m,E).normalize(),s[5].setComponents(l-c,p-d,h-m,R-E).normalize();else if(s[4].setComponents(l-c,p-d,h-m,R-E).normalize(),e===rn)s[5].setComponents(l+c,p+d,h+m,R+E).normalize();else if(e===$s)s[5].setComponents(c,d,m,E).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),kn.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),kn.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(kn)}intersectsSprite(t){kn.center.set(0,0,0);const e=vu.distanceTo(t.center);return kn.radius=.7071067811865476+e,kn.applyMatrix4(t.matrixWorld),this.intersectsSphere(kn)}intersectsSphere(t){const e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const s=e[n];if(Cs.x=s.normal.x>0?t.max.x:t.min.x,Cs.y=s.normal.y>0?t.max.y:t.min.y,Cs.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(Cs)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class ir extends Qn{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new jt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const Js=new I,Qs=new I,Wo=new ce,Hi=new ls,Ps=new os,Dr=new I,Xo=new I;class xu extends ve{constructor(t=new Pe,e=new ir){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[0];for(let s=1,r=e.count;s<r;s++)Js.fromBufferAttribute(e,s-1),Qs.fromBufferAttribute(e,s),n[s]=n[s-1],n[s]+=Js.distanceTo(Qs);t.setAttribute("lineDistance",new me(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){const n=this.geometry,s=this.matrixWorld,r=t.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ps.copy(n.boundingSphere),Ps.applyMatrix4(s),Ps.radius+=r,t.ray.intersectsSphere(Ps)===!1)return;Wo.copy(s).invert(),Hi.copy(t.ray).applyMatrix4(Wo);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=this.isLineSegments?2:1,u=n.index,d=n.attributes.position;if(u!==null){const p=Math.max(0,a.start),g=Math.min(u.count,a.start+a.count);for(let v=p,m=g-1;v<m;v+=l){const h=u.getX(v),T=u.getX(v+1),b=Ds(this,t,Hi,c,h,T,v);b&&e.push(b)}if(this.isLineLoop){const v=u.getX(g-1),m=u.getX(p),h=Ds(this,t,Hi,c,v,m,g-1);h&&e.push(h)}}else{const p=Math.max(0,a.start),g=Math.min(d.count,a.start+a.count);for(let v=p,m=g-1;v<m;v+=l){const h=Ds(this,t,Hi,c,v,v+1,v);h&&e.push(h)}if(this.isLineLoop){const v=Ds(this,t,Hi,c,g-1,p,g-1);v&&e.push(v)}}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function Ds(i,t,e,n,s,r,a){const o=i.geometry.attributes.position;if(Js.fromBufferAttribute(o,s),Qs.fromBufferAttribute(o,r),e.distanceSqToSegment(Js,Qs,Dr,Xo)>n)return;Dr.applyMatrix4(i.matrixWorld);const l=t.ray.origin.distanceTo(Dr);if(!(l<t.near||l>t.far))return{distance:l,point:Xo.clone().applyMatrix4(i.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:i}}const Yo=new I,qo=new I;class so extends xu{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[];for(let s=0,r=e.count;s<r;s+=2)Yo.fromBufferAttribute(e,s),qo.fromBufferAttribute(e,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Yo.distanceTo(qo);t.setAttribute("lineDistance",new me(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class cc extends Qn{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new jt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const jo=new ce,Na=new ls,Ls=new os,Is=new I;class Mu extends ve{constructor(t=new Pe,e=new cc){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){const n=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ls.copy(n.boundingSphere),Ls.applyMatrix4(s),Ls.radius+=r,t.ray.intersectsSphere(Ls)===!1)return;jo.copy(s).invert(),Na.copy(t.ray).applyMatrix4(jo);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=n.index,f=n.attributes.position;if(l!==null){const d=Math.max(0,a.start),p=Math.min(l.count,a.start+a.count);for(let g=d,v=p;g<v;g++){const m=l.getX(g);Is.fromBufferAttribute(f,m),$o(Is,m,c,s,t,e,this)}}else{const d=Math.max(0,a.start),p=Math.min(f.count,a.start+a.count);for(let g=d,v=p;g<v;g++)Is.fromBufferAttribute(f,g),$o(Is,g,c,s,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function $o(i,t,e,n,s,r,a){const o=Na.distanceSqToPoint(i);if(o<e){const c=new I;Na.closestPointToPoint(i,c),c.applyMatrix4(n);const l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;r.push({distance:l,distanceToRay:Math.sqrt(o),point:c,index:t,face:null,faceIndex:null,barycoord:null,object:a})}}class hc extends Ue{constructor(t,e,n=$n,s,r,a,o=Qe,c=Qe,l,u=Ji,f=1){if(u!==Ji&&u!==Qi)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const d={width:t,height:e,depth:f};super(d,s,r,a,o,c,u,n,l),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new eo(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}}class uc extends Ue{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class Ai extends Pe{constructor(t=1,e=1,n=1,s=32,r=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:c};const l=this;s=Math.floor(s),r=Math.floor(r);const u=[],f=[],d=[],p=[];let g=0;const v=[],m=n/2;let h=0;T(),a===!1&&(t>0&&b(!0),e>0&&b(!1)),this.setIndex(u),this.setAttribute("position",new me(f,3)),this.setAttribute("normal",new me(d,3)),this.setAttribute("uv",new me(p,2));function T(){const E=new I,R=new I;let w=0;const C=(e-t)/n;for(let L=0;L<=r;L++){const S=[],M=L/r,P=M*(e-t)+t;for(let F=0;F<=s;F++){const k=F/s,j=k*c+o,W=Math.sin(j),Y=Math.cos(j);R.x=P*W,R.y=-M*n+m,R.z=P*Y,f.push(R.x,R.y,R.z),E.set(W,C,Y).normalize(),d.push(E.x,E.y,E.z),p.push(k,1-M),S.push(g++)}v.push(S)}for(let L=0;L<s;L++)for(let S=0;S<r;S++){const M=v[S][L],P=v[S+1][L],F=v[S+1][L+1],k=v[S][L+1];(t>0||S!==0)&&(u.push(M,P,k),w+=3),(e>0||S!==r-1)&&(u.push(P,F,k),w+=3)}l.addGroup(h,w,0),h+=w}function b(E){const R=g,w=new Ot,C=new I;let L=0;const S=E===!0?t:e,M=E===!0?1:-1;for(let F=1;F<=s;F++)f.push(0,m*M,0),d.push(0,M,0),p.push(.5,.5),g++;const P=g;for(let F=0;F<=s;F++){const j=F/s*c+o,W=Math.cos(j),Y=Math.sin(j);C.x=S*Y,C.y=m*M,C.z=S*W,f.push(C.x,C.y,C.z),d.push(0,M,0),w.x=W*.5+.5,w.y=Y*.5*M+.5,p.push(w.x,w.y),g++}for(let F=0;F<s;F++){const k=R+F,j=P+F;E===!0?u.push(j,j+1,k):u.push(j+1,j,k),L+=3}l.addGroup(h,L,E===!0?1:2),h+=L}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Ai(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}const Us=new I,Ns=new I,Lr=new I,Fs=new We;class dc extends Pe{constructor(t=null,e=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:t,thresholdAngle:e},t!==null){const s=Math.pow(10,4),r=Math.cos(bi*e),a=t.getIndex(),o=t.getAttribute("position"),c=a?a.count:o.count,l=[0,0,0],u=["a","b","c"],f=new Array(3),d={},p=[];for(let g=0;g<c;g+=3){a?(l[0]=a.getX(g),l[1]=a.getX(g+1),l[2]=a.getX(g+2)):(l[0]=g,l[1]=g+1,l[2]=g+2);const{a:v,b:m,c:h}=Fs;if(v.fromBufferAttribute(o,l[0]),m.fromBufferAttribute(o,l[1]),h.fromBufferAttribute(o,l[2]),Fs.getNormal(Lr),f[0]=`${Math.round(v.x*s)},${Math.round(v.y*s)},${Math.round(v.z*s)}`,f[1]=`${Math.round(m.x*s)},${Math.round(m.y*s)},${Math.round(m.z*s)}`,f[2]=`${Math.round(h.x*s)},${Math.round(h.y*s)},${Math.round(h.z*s)}`,!(f[0]===f[1]||f[1]===f[2]||f[2]===f[0]))for(let T=0;T<3;T++){const b=(T+1)%3,E=f[T],R=f[b],w=Fs[u[T]],C=Fs[u[b]],L=`${E}_${R}`,S=`${R}_${E}`;S in d&&d[S]?(Lr.dot(d[S].normal)<=r&&(p.push(w.x,w.y,w.z),p.push(C.x,C.y,C.z)),d[S]=null):L in d||(d[L]={index0:l[T],index1:l[b],normal:Lr.clone()})}}for(const g in d)if(d[g]){const{index0:v,index1:m}=d[g];Us.fromBufferAttribute(o,v),Ns.fromBufferAttribute(o,m),p.push(Us.x,Us.y,Us.z),p.push(Ns.x,Ns.y,Ns.z)}this.setAttribute("position",new me(p,3))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}}class sr extends Pe{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};const r=t/2,a=e/2,o=Math.floor(n),c=Math.floor(s),l=o+1,u=c+1,f=t/o,d=e/c,p=[],g=[],v=[],m=[];for(let h=0;h<u;h++){const T=h*d-a;for(let b=0;b<l;b++){const E=b*f-r;g.push(E,-T,0),v.push(0,0,1),m.push(b/o),m.push(1-h/c)}}for(let h=0;h<c;h++)for(let T=0;T<o;T++){const b=T+l*h,E=T+l*(h+1),R=T+1+l*(h+1),w=T+1+l*h;p.push(b,E,w),p.push(E,R,w)}this.setIndex(p),this.setAttribute("position",new me(g,3)),this.setAttribute("normal",new me(v,3)),this.setAttribute("uv",new me(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new sr(t.width,t.height,t.widthSegments,t.heightSegments)}}class tr extends Pe{constructor(t=1,e=32,n=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const c=Math.min(a+o,Math.PI);let l=0;const u=[],f=new I,d=new I,p=[],g=[],v=[],m=[];for(let h=0;h<=n;h++){const T=[],b=h/n;let E=0;h===0&&a===0?E=.5/e:h===n&&c===Math.PI&&(E=-.5/e);for(let R=0;R<=e;R++){const w=R/e;f.x=-t*Math.cos(s+w*r)*Math.sin(a+b*o),f.y=t*Math.cos(a+b*o),f.z=t*Math.sin(s+w*r)*Math.sin(a+b*o),g.push(f.x,f.y,f.z),d.copy(f).normalize(),v.push(d.x,d.y,d.z),m.push(w+E,1-b),T.push(l++)}u.push(T)}for(let h=0;h<n;h++)for(let T=0;T<e;T++){const b=u[h][T+1],E=u[h][T],R=u[h+1][T],w=u[h+1][T+1];(h!==0||a>0)&&p.push(b,E,w),(h!==n-1||c<Math.PI)&&p.push(E,R,w)}this.setIndex(p),this.setAttribute("position",new me(g,3)),this.setAttribute("normal",new me(v,3)),this.setAttribute("uv",new me(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new tr(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class ro extends Pe{constructor(t=1,e=.4,n=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:s,arc:r},n=Math.floor(n),s=Math.floor(s);const a=[],o=[],c=[],l=[],u=new I,f=new I,d=new I;for(let p=0;p<=n;p++)for(let g=0;g<=s;g++){const v=g/s*r,m=p/n*Math.PI*2;f.x=(t+e*Math.cos(m))*Math.cos(v),f.y=(t+e*Math.cos(m))*Math.sin(v),f.z=e*Math.sin(m),o.push(f.x,f.y,f.z),u.x=t*Math.cos(v),u.y=t*Math.sin(v),d.subVectors(f,u).normalize(),c.push(d.x,d.y,d.z),l.push(g/s),l.push(p/n)}for(let p=1;p<=n;p++)for(let g=1;g<=s;g++){const v=(s+1)*p+g-1,m=(s+1)*(p-1)+g-1,h=(s+1)*(p-1)+g,T=(s+1)*p+g;a.push(v,m,T),a.push(m,h,T)}this.setIndex(a),this.setAttribute("position",new me(o,3)),this.setAttribute("normal",new me(c,3)),this.setAttribute("uv",new me(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ro(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}}class Su extends Qn{constructor(t){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new jt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new jt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Jl,this.normalScale=new Ot(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new on,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class Eu extends Qn{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=_h,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class yu extends Qn{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class fc extends ve{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new jt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}}class bu extends fc{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(ve.DEFAULT_UP),this.updateMatrix(),this.groundColor=new jt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}}const Ir=new ce,Zo=new I,Ko=new I;class Tu{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ot(512,512),this.mapType=an,this.map=null,this.mapPass=null,this.matrix=new ce,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new io,this._frameExtents=new Ot(1,1),this._viewportCount=1,this._viewports=[new fe(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera,n=this.matrix;Zo.setFromMatrixPosition(t.matrixWorld),e.position.copy(Zo),Ko.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Ko),e.updateMatrixWorld(),Ir.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Ir,e.coordinateSystem,e.reversedDepth),e.reversedDepth?n.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Ir)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}class pc extends oc{constructor(t=-1,e=1,n=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=n-t,a=n+t,o=s+e,c=s-e;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,a=r+l*this.view.width,o-=u*this.view.offsetY,c=o-u*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,c,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}class Au extends Tu{constructor(){super(new pc(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class wu extends fc{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(ve.DEFAULT_UP),this.updateMatrix(),this.target=new ve,this.shadow=new Au}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}class Ru extends Ge{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}}const Jo=new ce;class Cu{constructor(t,e,n=0,s=1/0){this.ray=new ls(t,e),this.near=n,this.far=s,this.camera=null,this.layers=new no,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}setFromXRController(t){return Jo.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Jo),this}intersectObject(t,e=!0,n=[]){return Fa(t,this,n,e),n.sort(Qo),n}intersectObjects(t,e=!0,n=[]){for(let s=0,r=t.length;s<r;s++)Fa(t[s],this,n,e);return n.sort(Qo),n}}function Qo(i,t){return i.distance-t.distance}function Fa(i,t,e,n){let s=!0;if(i.layers.test(t.layers)&&i.raycast(t,e)===!1&&(s=!1),s===!0&&n===!0){const r=i.children;for(let a=0,o=r.length;a<o;a++)Fa(r[a],t,e,!0)}}class tl{constructor(t=1,e=0,n=0){this.radius=t,this.phi=e,this.theta=n}set(t,e,n){return this.radius=t,this.phi=e,this.theta=n,this}copy(t){return this.radius=t.radius,this.phi=t.phi,this.theta=t.theta,this}makeSafe(){return this.phi=$t(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(t){return this.setFromCartesianCoords(t.x,t.y,t.z)}setFromCartesianCoords(t,e,n){return this.radius=Math.sqrt(t*t+e*e+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(t,n),this.phi=Math.acos($t(e/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}class Pu extends so{constructor(t=10,e=10,n=4473924,s=8947848){n=new jt(n),s=new jt(s);const r=e/2,a=t/e,o=t/2,c=[],l=[];for(let d=0,p=0,g=-o;d<=e;d++,g+=a){c.push(-o,0,g,o,0,g),c.push(g,0,-o,g,0,o);const v=d===r?n:s;v.toArray(l,p),p+=3,v.toArray(l,p),p+=3,v.toArray(l,p),p+=3,v.toArray(l,p),p+=3}const u=new Pe;u.setAttribute("position",new me(c,3)),u.setAttribute("color",new me(l,3));const f=new ir({vertexColors:!0,toneMapped:!1});super(u,f),this.type="GridHelper"}dispose(){this.geometry.dispose(),this.material.dispose()}}class Du extends Jn{constructor(t,e=null){super(),this.object=t,this.domElement=e,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(t){if(t===void 0){console.warn("THREE.Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=t}disconnect(){}dispose(){}update(){}}function el(i,t,e,n){const s=Lu(n);switch(e){case jl:return i*t;case Zl:return i*t/s.components*s.byteLength;case Ka:return i*t/s.components*s.byteLength;case Kl:return i*t*2/s.components*s.byteLength;case Ja:return i*t*2/s.components*s.byteLength;case $l:return i*t*3/s.components*s.byteLength;case Je:return i*t*4/s.components*s.byteLength;case Qa:return i*t*4/s.components*s.byteLength;case Vs:case Gs:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case Ws:case Xs:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case la:case ha:return Math.max(i,16)*Math.max(t,8)/4;case oa:case ca:return Math.max(i,8)*Math.max(t,8)/2;case ua:case da:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case fa:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case pa:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case ma:return Math.floor((i+4)/5)*Math.floor((t+3)/4)*16;case ga:return Math.floor((i+4)/5)*Math.floor((t+4)/5)*16;case _a:return Math.floor((i+5)/6)*Math.floor((t+4)/5)*16;case va:return Math.floor((i+5)/6)*Math.floor((t+5)/6)*16;case xa:return Math.floor((i+7)/8)*Math.floor((t+4)/5)*16;case Ma:return Math.floor((i+7)/8)*Math.floor((t+5)/6)*16;case Sa:return Math.floor((i+7)/8)*Math.floor((t+7)/8)*16;case Ea:return Math.floor((i+9)/10)*Math.floor((t+4)/5)*16;case ya:return Math.floor((i+9)/10)*Math.floor((t+5)/6)*16;case ba:return Math.floor((i+9)/10)*Math.floor((t+7)/8)*16;case Ta:return Math.floor((i+9)/10)*Math.floor((t+9)/10)*16;case Aa:return Math.floor((i+11)/12)*Math.floor((t+9)/10)*16;case wa:return Math.floor((i+11)/12)*Math.floor((t+11)/12)*16;case Ra:case Ca:case Pa:return Math.ceil(i/4)*Math.ceil(t/4)*16;case Da:case La:return Math.ceil(i/4)*Math.ceil(t/4)*8;case Ia:case Ua:return Math.ceil(i/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function Lu(i){switch(i){case an:case Wl:return{byteLength:1,components:1};case Zi:case Xl:case rs:return{byteLength:2,components:1};case $a:case Za:return{byteLength:2,components:4};case $n:case ja:case vn:return{byteLength:4,components:1};case Yl:case ql:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:qa}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=qa);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function mc(){let i=null,t=!1,e=null,n=null;function s(r,a){e(r,a),n=i.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function Iu(i){const t=new WeakMap;function e(o,c){const l=o.array,u=o.usage,f=l.byteLength,d=i.createBuffer();i.bindBuffer(c,d),i.bufferData(c,l,u),o.onUploadCallback();let p;if(l instanceof Float32Array)p=i.FLOAT;else if(typeof Float16Array<"u"&&l instanceof Float16Array)p=i.HALF_FLOAT;else if(l instanceof Uint16Array)o.isFloat16BufferAttribute?p=i.HALF_FLOAT:p=i.UNSIGNED_SHORT;else if(l instanceof Int16Array)p=i.SHORT;else if(l instanceof Uint32Array)p=i.UNSIGNED_INT;else if(l instanceof Int32Array)p=i.INT;else if(l instanceof Int8Array)p=i.BYTE;else if(l instanceof Uint8Array)p=i.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)p=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:d,type:p,bytesPerElement:l.BYTES_PER_ELEMENT,version:o.version,size:f}}function n(o,c,l){const u=c.array,f=c.updateRanges;if(i.bindBuffer(l,o),f.length===0)i.bufferSubData(l,0,u);else{f.sort((p,g)=>p.start-g.start);let d=0;for(let p=1;p<f.length;p++){const g=f[d],v=f[p];v.start<=g.start+g.count+1?g.count=Math.max(g.count,v.start+v.count-g.start):(++d,f[d]=v)}f.length=d+1;for(let p=0,g=f.length;p<g;p++){const v=f[p];i.bufferSubData(l,v.start*u.BYTES_PER_ELEMENT,u,v.start,v.count)}c.clearUpdateRanges()}c.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),t.get(o)}function r(o){o.isInterleavedBufferAttribute&&(o=o.data);const c=t.get(o);c&&(i.deleteBuffer(c.buffer),t.delete(o))}function a(o,c){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const u=t.get(o);(!u||u.version<o.version)&&t.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const l=t.get(o);if(l===void 0)t.set(o,e(o,c));else if(l.version<o.version){if(l.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(l.buffer,o,c),l.version=o.version}}return{get:s,remove:r,update:a}}var Uu=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Nu=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Fu=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Ou=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Bu=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,zu=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,ku=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Hu=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Vu=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Gu=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Wu=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Xu=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Yu=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,qu=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,ju=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,$u=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Zu=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Ku=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Ju=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Qu=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,td=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,ed=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,nd=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,id=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,sd=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,rd=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,ad=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,od=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,ld=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,cd=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,hd="gl_FragColor = linearToOutputTexel( gl_FragColor );",ud=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,dd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,fd=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,pd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,md=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,gd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,_d=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,vd=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,xd=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Md=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Sd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Ed=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,yd=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,bd=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Td=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Ad=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,wd=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Rd=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Cd=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Pd=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Dd=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Ld=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Id=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Ud=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Nd=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Fd=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Od=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Bd=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,zd=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,kd=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Hd=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Vd=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Gd=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Wd=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Xd=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Yd=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,qd=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,jd=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,$d=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Zd=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Kd=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Jd=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Qd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,tf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,ef=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,nf=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,sf=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,rf=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,af=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,of=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,lf=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,cf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,hf=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,uf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,df=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,ff=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,pf=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,mf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,gf=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,_f=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,vf=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,xf=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Mf=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Sf=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Ef=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,yf=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,bf=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Tf=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Af=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,wf=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Rf=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Cf=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Pf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Df=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Lf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,If=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Uf=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Nf=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ff=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Of=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Bf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,zf=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,kf=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Hf=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Vf=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Gf=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Wf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Xf=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Yf=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,qf=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,jf=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,$f=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Zf=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Kf=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Jf=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Qf=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,tp=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,ep=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,np=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ip=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,sp=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,rp=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ap=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,op=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,lp=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,cp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,hp=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,up=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,dp=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,fp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Yt={alphahash_fragment:Uu,alphahash_pars_fragment:Nu,alphamap_fragment:Fu,alphamap_pars_fragment:Ou,alphatest_fragment:Bu,alphatest_pars_fragment:zu,aomap_fragment:ku,aomap_pars_fragment:Hu,batching_pars_vertex:Vu,batching_vertex:Gu,begin_vertex:Wu,beginnormal_vertex:Xu,bsdfs:Yu,iridescence_fragment:qu,bumpmap_pars_fragment:ju,clipping_planes_fragment:$u,clipping_planes_pars_fragment:Zu,clipping_planes_pars_vertex:Ku,clipping_planes_vertex:Ju,color_fragment:Qu,color_pars_fragment:td,color_pars_vertex:ed,color_vertex:nd,common:id,cube_uv_reflection_fragment:sd,defaultnormal_vertex:rd,displacementmap_pars_vertex:ad,displacementmap_vertex:od,emissivemap_fragment:ld,emissivemap_pars_fragment:cd,colorspace_fragment:hd,colorspace_pars_fragment:ud,envmap_fragment:dd,envmap_common_pars_fragment:fd,envmap_pars_fragment:pd,envmap_pars_vertex:md,envmap_physical_pars_fragment:Ad,envmap_vertex:gd,fog_vertex:_d,fog_pars_vertex:vd,fog_fragment:xd,fog_pars_fragment:Md,gradientmap_pars_fragment:Sd,lightmap_pars_fragment:Ed,lights_lambert_fragment:yd,lights_lambert_pars_fragment:bd,lights_pars_begin:Td,lights_toon_fragment:wd,lights_toon_pars_fragment:Rd,lights_phong_fragment:Cd,lights_phong_pars_fragment:Pd,lights_physical_fragment:Dd,lights_physical_pars_fragment:Ld,lights_fragment_begin:Id,lights_fragment_maps:Ud,lights_fragment_end:Nd,logdepthbuf_fragment:Fd,logdepthbuf_pars_fragment:Od,logdepthbuf_pars_vertex:Bd,logdepthbuf_vertex:zd,map_fragment:kd,map_pars_fragment:Hd,map_particle_fragment:Vd,map_particle_pars_fragment:Gd,metalnessmap_fragment:Wd,metalnessmap_pars_fragment:Xd,morphinstance_vertex:Yd,morphcolor_vertex:qd,morphnormal_vertex:jd,morphtarget_pars_vertex:$d,morphtarget_vertex:Zd,normal_fragment_begin:Kd,normal_fragment_maps:Jd,normal_pars_fragment:Qd,normal_pars_vertex:tf,normal_vertex:ef,normalmap_pars_fragment:nf,clearcoat_normal_fragment_begin:sf,clearcoat_normal_fragment_maps:rf,clearcoat_pars_fragment:af,iridescence_pars_fragment:of,opaque_fragment:lf,packing:cf,premultiplied_alpha_fragment:hf,project_vertex:uf,dithering_fragment:df,dithering_pars_fragment:ff,roughnessmap_fragment:pf,roughnessmap_pars_fragment:mf,shadowmap_pars_fragment:gf,shadowmap_pars_vertex:_f,shadowmap_vertex:vf,shadowmask_pars_fragment:xf,skinbase_vertex:Mf,skinning_pars_vertex:Sf,skinning_vertex:Ef,skinnormal_vertex:yf,specularmap_fragment:bf,specularmap_pars_fragment:Tf,tonemapping_fragment:Af,tonemapping_pars_fragment:wf,transmission_fragment:Rf,transmission_pars_fragment:Cf,uv_pars_fragment:Pf,uv_pars_vertex:Df,uv_vertex:Lf,worldpos_vertex:If,background_vert:Uf,background_frag:Nf,backgroundCube_vert:Ff,backgroundCube_frag:Of,cube_vert:Bf,cube_frag:zf,depth_vert:kf,depth_frag:Hf,distanceRGBA_vert:Vf,distanceRGBA_frag:Gf,equirect_vert:Wf,equirect_frag:Xf,linedashed_vert:Yf,linedashed_frag:qf,meshbasic_vert:jf,meshbasic_frag:$f,meshlambert_vert:Zf,meshlambert_frag:Kf,meshmatcap_vert:Jf,meshmatcap_frag:Qf,meshnormal_vert:tp,meshnormal_frag:ep,meshphong_vert:np,meshphong_frag:ip,meshphysical_vert:sp,meshphysical_frag:rp,meshtoon_vert:ap,meshtoon_frag:op,points_vert:lp,points_frag:cp,shadow_vert:hp,shadow_frag:up,sprite_vert:dp,sprite_frag:fp},ot={common:{diffuse:{value:new jt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Wt},alphaMap:{value:null},alphaMapTransform:{value:new Wt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Wt}},envmap:{envMap:{value:null},envMapRotation:{value:new Wt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Wt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Wt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Wt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Wt},normalScale:{value:new Ot(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Wt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Wt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Wt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Wt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new jt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new jt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Wt},alphaTest:{value:0},uvTransform:{value:new Wt}},sprite:{diffuse:{value:new jt(16777215)},opacity:{value:1},center:{value:new Ot(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Wt},alphaMap:{value:null},alphaMapTransform:{value:new Wt},alphaTest:{value:0}}},nn={basic:{uniforms:Re([ot.common,ot.specularmap,ot.envmap,ot.aomap,ot.lightmap,ot.fog]),vertexShader:Yt.meshbasic_vert,fragmentShader:Yt.meshbasic_frag},lambert:{uniforms:Re([ot.common,ot.specularmap,ot.envmap,ot.aomap,ot.lightmap,ot.emissivemap,ot.bumpmap,ot.normalmap,ot.displacementmap,ot.fog,ot.lights,{emissive:{value:new jt(0)}}]),vertexShader:Yt.meshlambert_vert,fragmentShader:Yt.meshlambert_frag},phong:{uniforms:Re([ot.common,ot.specularmap,ot.envmap,ot.aomap,ot.lightmap,ot.emissivemap,ot.bumpmap,ot.normalmap,ot.displacementmap,ot.fog,ot.lights,{emissive:{value:new jt(0)},specular:{value:new jt(1118481)},shininess:{value:30}}]),vertexShader:Yt.meshphong_vert,fragmentShader:Yt.meshphong_frag},standard:{uniforms:Re([ot.common,ot.envmap,ot.aomap,ot.lightmap,ot.emissivemap,ot.bumpmap,ot.normalmap,ot.displacementmap,ot.roughnessmap,ot.metalnessmap,ot.fog,ot.lights,{emissive:{value:new jt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Yt.meshphysical_vert,fragmentShader:Yt.meshphysical_frag},toon:{uniforms:Re([ot.common,ot.aomap,ot.lightmap,ot.emissivemap,ot.bumpmap,ot.normalmap,ot.displacementmap,ot.gradientmap,ot.fog,ot.lights,{emissive:{value:new jt(0)}}]),vertexShader:Yt.meshtoon_vert,fragmentShader:Yt.meshtoon_frag},matcap:{uniforms:Re([ot.common,ot.bumpmap,ot.normalmap,ot.displacementmap,ot.fog,{matcap:{value:null}}]),vertexShader:Yt.meshmatcap_vert,fragmentShader:Yt.meshmatcap_frag},points:{uniforms:Re([ot.points,ot.fog]),vertexShader:Yt.points_vert,fragmentShader:Yt.points_frag},dashed:{uniforms:Re([ot.common,ot.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Yt.linedashed_vert,fragmentShader:Yt.linedashed_frag},depth:{uniforms:Re([ot.common,ot.displacementmap]),vertexShader:Yt.depth_vert,fragmentShader:Yt.depth_frag},normal:{uniforms:Re([ot.common,ot.bumpmap,ot.normalmap,ot.displacementmap,{opacity:{value:1}}]),vertexShader:Yt.meshnormal_vert,fragmentShader:Yt.meshnormal_frag},sprite:{uniforms:Re([ot.sprite,ot.fog]),vertexShader:Yt.sprite_vert,fragmentShader:Yt.sprite_frag},background:{uniforms:{uvTransform:{value:new Wt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Yt.background_vert,fragmentShader:Yt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Wt}},vertexShader:Yt.backgroundCube_vert,fragmentShader:Yt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Yt.cube_vert,fragmentShader:Yt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Yt.equirect_vert,fragmentShader:Yt.equirect_frag},distanceRGBA:{uniforms:Re([ot.common,ot.displacementmap,{referencePosition:{value:new I},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Yt.distanceRGBA_vert,fragmentShader:Yt.distanceRGBA_frag},shadow:{uniforms:Re([ot.lights,ot.fog,{color:{value:new jt(0)},opacity:{value:1}}]),vertexShader:Yt.shadow_vert,fragmentShader:Yt.shadow_frag}};nn.physical={uniforms:Re([nn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Wt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Wt},clearcoatNormalScale:{value:new Ot(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Wt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Wt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Wt},sheen:{value:0},sheenColor:{value:new jt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Wt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Wt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Wt},transmissionSamplerSize:{value:new Ot},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Wt},attenuationDistance:{value:0},attenuationColor:{value:new jt(0)},specularColor:{value:new jt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Wt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Wt},anisotropyVector:{value:new Ot},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Wt}}]),vertexShader:Yt.meshphysical_vert,fragmentShader:Yt.meshphysical_frag};const Os={r:0,b:0,g:0},Hn=new on,pp=new ce;function mp(i,t,e,n,s,r,a){const o=new jt(0);let c=r===!0?0:1,l,u,f=null,d=0,p=null;function g(b){let E=b.isScene===!0?b.background:null;return E&&E.isTexture&&(E=(b.backgroundBlurriness>0?e:t).get(E)),E}function v(b){let E=!1;const R=g(b);R===null?h(o,c):R&&R.isColor&&(h(R,1),E=!0);const w=i.xr.getEnvironmentBlendMode();w==="additive"?n.buffers.color.setClear(0,0,0,1,a):w==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(i.autoClear||E)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(b,E){const R=g(E);R&&(R.isCubeTexture||R.mapping===nr)?(u===void 0&&(u=new Xe(new Ui(1,1,1),new In({name:"BackgroundCubeMaterial",uniforms:Di(nn.backgroundCube.uniforms),vertexShader:nn.backgroundCube.vertexShader,fragmentShader:nn.backgroundCube.fragmentShader,side:Ie,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),u.geometry.deleteAttribute("normal"),u.geometry.deleteAttribute("uv"),u.onBeforeRender=function(w,C,L){this.matrixWorld.copyPosition(L.matrixWorld)},Object.defineProperty(u.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(u)),Hn.copy(E.backgroundRotation),Hn.x*=-1,Hn.y*=-1,Hn.z*=-1,R.isCubeTexture&&R.isRenderTargetTexture===!1&&(Hn.y*=-1,Hn.z*=-1),u.material.uniforms.envMap.value=R,u.material.uniforms.flipEnvMap.value=R.isCubeTexture&&R.isRenderTargetTexture===!1?-1:1,u.material.uniforms.backgroundBlurriness.value=E.backgroundBlurriness,u.material.uniforms.backgroundIntensity.value=E.backgroundIntensity,u.material.uniforms.backgroundRotation.value.setFromMatrix4(pp.makeRotationFromEuler(Hn)),u.material.toneMapped=Jt.getTransfer(R.colorSpace)!==se,(f!==R||d!==R.version||p!==i.toneMapping)&&(u.material.needsUpdate=!0,f=R,d=R.version,p=i.toneMapping),u.layers.enableAll(),b.unshift(u,u.geometry,u.material,0,0,null)):R&&R.isTexture&&(l===void 0&&(l=new Xe(new sr(2,2),new In({name:"BackgroundMaterial",uniforms:Di(nn.background.uniforms),vertexShader:nn.background.vertexShader,fragmentShader:nn.background.fragmentShader,side:Ln,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(l)),l.material.uniforms.t2D.value=R,l.material.uniforms.backgroundIntensity.value=E.backgroundIntensity,l.material.toneMapped=Jt.getTransfer(R.colorSpace)!==se,R.matrixAutoUpdate===!0&&R.updateMatrix(),l.material.uniforms.uvTransform.value.copy(R.matrix),(f!==R||d!==R.version||p!==i.toneMapping)&&(l.material.needsUpdate=!0,f=R,d=R.version,p=i.toneMapping),l.layers.enableAll(),b.unshift(l,l.geometry,l.material,0,0,null))}function h(b,E){b.getRGB(Os,ac(i)),n.buffers.color.setClear(Os.r,Os.g,Os.b,E,a)}function T(){u!==void 0&&(u.geometry.dispose(),u.material.dispose(),u=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return o},setClearColor:function(b,E=1){o.set(b),c=E,h(o,c)},getClearAlpha:function(){return c},setClearAlpha:function(b){c=b,h(o,c)},render:v,addToRenderList:m,dispose:T}}function gp(i,t){const e=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=d(null);let r=s,a=!1;function o(M,P,F,k,j){let W=!1;const Y=f(k,F,P);r!==Y&&(r=Y,l(r.object)),W=p(M,k,F,j),W&&g(M,k,F,j),j!==null&&t.update(j,i.ELEMENT_ARRAY_BUFFER),(W||a)&&(a=!1,E(M,P,F,k),j!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get(j).buffer))}function c(){return i.createVertexArray()}function l(M){return i.bindVertexArray(M)}function u(M){return i.deleteVertexArray(M)}function f(M,P,F){const k=F.wireframe===!0;let j=n[M.id];j===void 0&&(j={},n[M.id]=j);let W=j[P.id];W===void 0&&(W={},j[P.id]=W);let Y=W[k];return Y===void 0&&(Y=d(c()),W[k]=Y),Y}function d(M){const P=[],F=[],k=[];for(let j=0;j<e;j++)P[j]=0,F[j]=0,k[j]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:P,enabledAttributes:F,attributeDivisors:k,object:M,attributes:{},index:null}}function p(M,P,F,k){const j=r.attributes,W=P.attributes;let Y=0;const K=F.getAttributes();for(const H in K)if(K[H].location>=0){const V=j[H];let at=W[H];if(at===void 0&&(H==="instanceMatrix"&&M.instanceMatrix&&(at=M.instanceMatrix),H==="instanceColor"&&M.instanceColor&&(at=M.instanceColor)),V===void 0||V.attribute!==at||at&&V.data!==at.data)return!0;Y++}return r.attributesNum!==Y||r.index!==k}function g(M,P,F,k){const j={},W=P.attributes;let Y=0;const K=F.getAttributes();for(const H in K)if(K[H].location>=0){let V=W[H];V===void 0&&(H==="instanceMatrix"&&M.instanceMatrix&&(V=M.instanceMatrix),H==="instanceColor"&&M.instanceColor&&(V=M.instanceColor));const at={};at.attribute=V,V&&V.data&&(at.data=V.data),j[H]=at,Y++}r.attributes=j,r.attributesNum=Y,r.index=k}function v(){const M=r.newAttributes;for(let P=0,F=M.length;P<F;P++)M[P]=0}function m(M){h(M,0)}function h(M,P){const F=r.newAttributes,k=r.enabledAttributes,j=r.attributeDivisors;F[M]=1,k[M]===0&&(i.enableVertexAttribArray(M),k[M]=1),j[M]!==P&&(i.vertexAttribDivisor(M,P),j[M]=P)}function T(){const M=r.newAttributes,P=r.enabledAttributes;for(let F=0,k=P.length;F<k;F++)P[F]!==M[F]&&(i.disableVertexAttribArray(F),P[F]=0)}function b(M,P,F,k,j,W,Y){Y===!0?i.vertexAttribIPointer(M,P,F,j,W):i.vertexAttribPointer(M,P,F,k,j,W)}function E(M,P,F,k){v();const j=k.attributes,W=F.getAttributes(),Y=P.defaultAttributeValues;for(const K in W){const H=W[K];if(H.location>=0){let st=j[K];if(st===void 0&&(K==="instanceMatrix"&&M.instanceMatrix&&(st=M.instanceMatrix),K==="instanceColor"&&M.instanceColor&&(st=M.instanceColor)),st!==void 0){const V=st.normalized,at=st.itemSize,Et=t.get(st);if(Et===void 0)continue;const ht=Et.buffer,It=Et.type,Dt=Et.bytesPerElement,G=It===i.INT||It===i.UNSIGNED_INT||st.gpuType===ja;if(st.isInterleavedBufferAttribute){const $=st.data,dt=$.stride,Ut=st.offset;if($.isInstancedInterleavedBuffer){for(let yt=0;yt<H.locationSize;yt++)h(H.location+yt,$.meshPerAttribute);M.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=$.meshPerAttribute*$.count)}else for(let yt=0;yt<H.locationSize;yt++)m(H.location+yt);i.bindBuffer(i.ARRAY_BUFFER,ht);for(let yt=0;yt<H.locationSize;yt++)b(H.location+yt,at/H.locationSize,It,V,dt*Dt,(Ut+at/H.locationSize*yt)*Dt,G)}else{if(st.isInstancedBufferAttribute){for(let $=0;$<H.locationSize;$++)h(H.location+$,st.meshPerAttribute);M.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=st.meshPerAttribute*st.count)}else for(let $=0;$<H.locationSize;$++)m(H.location+$);i.bindBuffer(i.ARRAY_BUFFER,ht);for(let $=0;$<H.locationSize;$++)b(H.location+$,at/H.locationSize,It,V,at*Dt,at/H.locationSize*$*Dt,G)}}else if(Y!==void 0){const V=Y[K];if(V!==void 0)switch(V.length){case 2:i.vertexAttrib2fv(H.location,V);break;case 3:i.vertexAttrib3fv(H.location,V);break;case 4:i.vertexAttrib4fv(H.location,V);break;default:i.vertexAttrib1fv(H.location,V)}}}}T()}function R(){L();for(const M in n){const P=n[M];for(const F in P){const k=P[F];for(const j in k)u(k[j].object),delete k[j];delete P[F]}delete n[M]}}function w(M){if(n[M.id]===void 0)return;const P=n[M.id];for(const F in P){const k=P[F];for(const j in k)u(k[j].object),delete k[j];delete P[F]}delete n[M.id]}function C(M){for(const P in n){const F=n[P];if(F[M.id]===void 0)continue;const k=F[M.id];for(const j in k)u(k[j].object),delete k[j];delete F[M.id]}}function L(){S(),a=!0,r!==s&&(r=s,l(r.object))}function S(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:L,resetDefaultState:S,dispose:R,releaseStatesOfGeometry:w,releaseStatesOfProgram:C,initAttributes:v,enableAttribute:m,disableUnusedAttributes:T}}function _p(i,t,e){let n;function s(l){n=l}function r(l,u){i.drawArrays(n,l,u),e.update(u,n,1)}function a(l,u,f){f!==0&&(i.drawArraysInstanced(n,l,u,f),e.update(u,n,f))}function o(l,u,f){if(f===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,u,0,f);let p=0;for(let g=0;g<f;g++)p+=u[g];e.update(p,n,1)}function c(l,u,f,d){if(f===0)return;const p=t.get("WEBGL_multi_draw");if(p===null)for(let g=0;g<l.length;g++)a(l[g],u[g],d[g]);else{p.multiDrawArraysInstancedWEBGL(n,l,0,u,0,d,0,f);let g=0;for(let v=0;v<f;v++)g+=u[v]*d[v];e.update(g,n,1)}}this.setMode=s,this.render=r,this.renderInstances=a,this.renderMultiDraw=o,this.renderMultiDrawInstances=c}function vp(i,t,e,n){let s;function r(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){const C=t.get("EXT_texture_filter_anisotropic");s=i.getParameter(C.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function a(C){return!(C!==Je&&n.convert(C)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(C){const L=C===rs&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(C!==an&&n.convert(C)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&C!==vn&&!L)}function c(C){if(C==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";C="mediump"}return C==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=e.precision!==void 0?e.precision:"highp";const u=c(l);u!==l&&(console.warn("THREE.WebGLRenderer:",l,"not supported, using",u,"instead."),l=u);const f=e.logarithmicDepthBuffer===!0,d=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),p=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),h=i.getParameter(i.MAX_VERTEX_ATTRIBS),T=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),b=i.getParameter(i.MAX_VARYING_VECTORS),E=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),R=g>0,w=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:c,textureFormatReadable:a,textureTypeReadable:o,precision:l,logarithmicDepthBuffer:f,reversedDepthBuffer:d,maxTextures:p,maxVertexTextures:g,maxTextureSize:v,maxCubemapSize:m,maxAttributes:h,maxVertexUniforms:T,maxVaryings:b,maxFragmentUniforms:E,vertexTextures:R,maxSamples:w}}function xp(i){const t=this;let e=null,n=0,s=!1,r=!1;const a=new Rn,o=new Wt,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(f,d){const p=f.length!==0||d||n!==0||s;return s=d,n=f.length,p},this.beginShadows=function(){r=!0,u(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(f,d){e=u(f,d,0)},this.setState=function(f,d,p){const g=f.clippingPlanes,v=f.clipIntersection,m=f.clipShadows,h=i.get(f);if(!s||g===null||g.length===0||r&&!m)r?u(null):l();else{const T=r?0:n,b=T*4;let E=h.clippingState||null;c.value=E,E=u(g,d,b,p);for(let R=0;R!==b;++R)E[R]=e[R];h.clippingState=E,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=T}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function u(f,d,p,g){const v=f!==null?f.length:0;let m=null;if(v!==0){if(m=c.value,g!==!0||m===null){const h=p+v*4,T=d.matrixWorldInverse;o.getNormalMatrix(T),(m===null||m.length<h)&&(m=new Float32Array(h));for(let b=0,E=p;b!==v;++b,E+=4)a.copy(f[b]).applyMatrix4(T,o),a.normal.toArray(m,E),m[E+3]=a.constant}c.value=m,c.needsUpdate=!0}return t.numPlanes=v,t.numIntersection=0,m}}function Mp(i){let t=new WeakMap;function e(a,o){return o===ia?a.mapping=Ri:o===sa&&(a.mapping=Ci),a}function n(a){if(a&&a.isTexture){const o=a.mapping;if(o===ia||o===sa)if(t.has(a)){const c=t.get(a).texture;return e(c,a.mapping)}else{const c=a.image;if(c&&c.height>0){const l=new fu(c.height);return l.fromEquirectangularTexture(i,a),t.set(a,l),a.addEventListener("dispose",s),e(l.texture,a.mapping)}else return null}}return a}function s(a){const o=a.target;o.removeEventListener("dispose",s);const c=t.get(o);c!==void 0&&(t.delete(o),c.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}const Si=4,nl=[.125,.215,.35,.446,.526,.582],Xn=20,Ur=new pc,il=new jt;let Nr=null,Fr=0,Or=0,Br=!1;const Gn=(1+Math.sqrt(5))/2,gi=1/Gn,sl=[new I(-Gn,gi,0),new I(Gn,gi,0),new I(-gi,0,Gn),new I(gi,0,Gn),new I(0,Gn,-gi),new I(0,Gn,gi),new I(-1,1,-1),new I(1,1,-1),new I(-1,1,1),new I(1,1,1)],Sp=new I;class rl{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,s=100,r={}){const{size:a=256,position:o=Sp}=r;Nr=this._renderer.getRenderTarget(),Fr=this._renderer.getActiveCubeFace(),Or=this._renderer.getActiveMipmapLevel(),Br=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);const c=this._allocateTargets();return c.depthBuffer=!0,this._sceneToCubeUV(t,n,s,c,o),e>0&&this._blur(c,0,0,e),this._applyPMREM(c),this._cleanup(c),c}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=ll(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=ol(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Nr,Fr,Or),this._renderer.xr.enabled=Br,t.scissorTest=!1,Bs(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Ri||t.mapping===Ci?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Nr=this._renderer.getRenderTarget(),Fr=this._renderer.getActiveCubeFace(),Or=this._renderer.getActiveMipmapLevel(),Br=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:sn,minFilter:sn,generateMipmaps:!1,type:rs,format:Je,colorSpace:Pi,depthBuffer:!1},s=al(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=al(t,e,n);const{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Ep(r)),this._blurMaterial=yp(r,t,e)}return s}_compileMaterial(t){const e=new Xe(this._lodPlanes[0],t);this._renderer.compile(e,Ur)}_sceneToCubeUV(t,e,n,s,r){const c=new Ge(90,1,e,n),l=[1,-1,1,1,1,1],u=[1,1,1,-1,-1,-1],f=this._renderer,d=f.autoClear,p=f.toneMapping;f.getClearColor(il),f.toneMapping=Dn,f.autoClear=!1,f.state.buffers.depth.getReversed()&&(f.setRenderTarget(s),f.clearDepth(),f.setRenderTarget(null));const v=new Ks({name:"PMREM.Background",side:Ie,depthWrite:!1,depthTest:!1}),m=new Xe(new Ui,v);let h=!1;const T=t.background;T?T.isColor&&(v.color.copy(T),t.background=null,h=!0):(v.color.copy(il),h=!0);for(let b=0;b<6;b++){const E=b%3;E===0?(c.up.set(0,l[b],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x+u[b],r.y,r.z)):E===1?(c.up.set(0,0,l[b]),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y+u[b],r.z)):(c.up.set(0,l[b],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y,r.z+u[b]));const R=this._cubeSize;Bs(s,E*R,b>2?R:0,R,R),f.setRenderTarget(s),h&&f.render(m,c),f.render(t,c)}m.geometry.dispose(),m.material.dispose(),f.toneMapping=p,f.autoClear=d,t.background=T}_textureToCubeUV(t,e){const n=this._renderer,s=t.mapping===Ri||t.mapping===Ci;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=ll()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=ol());const r=s?this._cubemapMaterial:this._equirectMaterial,a=new Xe(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=t;const c=this._cubeSize;Bs(e,0,0,3*c,2*c),n.setRenderTarget(e),n.render(a,Ur)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;const s=this._lodPlanes.length;for(let r=1;r<s;r++){const a=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),o=sl[(s-r-1)%sl.length];this._blur(t,r-1,r,a,o)}e.autoClear=n}_blur(t,e,n,s,r){const a=this._pingPongRenderTarget;this._halfBlur(t,a,e,n,s,"latitudinal",r),this._halfBlur(a,t,n,n,s,"longitudinal",r)}_halfBlur(t,e,n,s,r,a,o){const c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const u=3,f=new Xe(this._lodPlanes[s],l),d=l.uniforms,p=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*p):2*Math.PI/(2*Xn-1),v=r/g,m=isFinite(r)?1+Math.floor(u*v):Xn;m>Xn&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Xn}`);const h=[];let T=0;for(let C=0;C<Xn;++C){const L=C/v,S=Math.exp(-L*L/2);h.push(S),C===0?T+=S:C<m&&(T+=2*S)}for(let C=0;C<h.length;C++)h[C]=h[C]/T;d.envMap.value=t.texture,d.samples.value=m,d.weights.value=h,d.latitudinal.value=a==="latitudinal",o&&(d.poleAxis.value=o);const{_lodMax:b}=this;d.dTheta.value=g,d.mipInt.value=b-n;const E=this._sizeLods[s],R=3*E*(s>b-Si?s-b+Si:0),w=4*(this._cubeSize-E);Bs(e,R,w,3*E,2*E),c.setRenderTarget(e),c.render(f,Ur)}}function Ep(i){const t=[],e=[],n=[];let s=i;const r=i-Si+1+nl.length;for(let a=0;a<r;a++){const o=Math.pow(2,s);e.push(o);let c=1/o;a>i-Si?c=nl[a-i+Si-1]:a===0&&(c=0),n.push(c);const l=1/(o-2),u=-l,f=1+l,d=[u,u,f,u,f,f,u,u,f,f,u,f],p=6,g=6,v=3,m=2,h=1,T=new Float32Array(v*g*p),b=new Float32Array(m*g*p),E=new Float32Array(h*g*p);for(let w=0;w<p;w++){const C=w%3*2/3-1,L=w>2?0:-1,S=[C,L,0,C+2/3,L,0,C+2/3,L+1,0,C,L,0,C+2/3,L+1,0,C,L+1,0];T.set(S,v*g*w),b.set(d,m*g*w);const M=[w,w,w,w,w,w];E.set(M,h*g*w)}const R=new Pe;R.setAttribute("position",new qe(T,v)),R.setAttribute("uv",new qe(b,m)),R.setAttribute("faceIndex",new qe(E,h)),t.push(R),s>Si&&s--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function al(i,t,e){const n=new Kn(i,t,e);return n.texture.mapping=nr,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Bs(i,t,e,n,s){i.viewport.set(t,e,n,s),i.scissor.set(t,e,n,s)}function yp(i,t,e){const n=new Float32Array(Xn),s=new I(0,1,0);return new In({name:"SphericalGaussianBlur",defines:{n:Xn,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:ao(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Pn,depthTest:!1,depthWrite:!1})}function ol(){return new In({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:ao(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Pn,depthTest:!1,depthWrite:!1})}function ll(){return new In({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:ao(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Pn,depthTest:!1,depthWrite:!1})}function ao(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function bp(i){let t=new WeakMap,e=null;function n(o){if(o&&o.isTexture){const c=o.mapping,l=c===ia||c===sa,u=c===Ri||c===Ci;if(l||u){let f=t.get(o);const d=f!==void 0?f.texture.pmremVersion:0;if(o.isRenderTargetTexture&&o.pmremVersion!==d)return e===null&&(e=new rl(i)),f=l?e.fromEquirectangular(o,f):e.fromCubemap(o,f),f.texture.pmremVersion=o.pmremVersion,t.set(o,f),f.texture;if(f!==void 0)return f.texture;{const p=o.image;return l&&p&&p.height>0||u&&p&&s(p)?(e===null&&(e=new rl(i)),f=l?e.fromEquirectangular(o):e.fromCubemap(o),f.texture.pmremVersion=o.pmremVersion,t.set(o,f),o.addEventListener("dispose",r),f.texture):null}}}return o}function s(o){let c=0;const l=6;for(let u=0;u<l;u++)o[u]!==void 0&&c++;return c===l}function r(o){const c=o.target;c.removeEventListener("dispose",r);const l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:a}}function Tp(i){const t={};function e(n){if(t[n]!==void 0)return t[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){const s=e(n);return s===null&&es("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function Ap(i,t,e,n){const s={},r=new WeakMap;function a(f){const d=f.target;d.index!==null&&t.remove(d.index);for(const g in d.attributes)t.remove(d.attributes[g]);d.removeEventListener("dispose",a),delete s[d.id];const p=r.get(d);p&&(t.remove(p),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,e.memory.geometries--}function o(f,d){return s[d.id]===!0||(d.addEventListener("dispose",a),s[d.id]=!0,e.memory.geometries++),d}function c(f){const d=f.attributes;for(const p in d)t.update(d[p],i.ARRAY_BUFFER)}function l(f){const d=[],p=f.index,g=f.attributes.position;let v=0;if(p!==null){const T=p.array;v=p.version;for(let b=0,E=T.length;b<E;b+=3){const R=T[b+0],w=T[b+1],C=T[b+2];d.push(R,w,w,C,C,R)}}else if(g!==void 0){const T=g.array;v=g.version;for(let b=0,E=T.length/3-1;b<E;b+=3){const R=b+0,w=b+1,C=b+2;d.push(R,w,w,C,C,R)}}else return;const m=new(ec(d)?rc:sc)(d,1);m.version=v;const h=r.get(f);h&&t.remove(h),r.set(f,m)}function u(f){const d=r.get(f);if(d){const p=f.index;p!==null&&d.version<p.version&&l(f)}else l(f);return r.get(f)}return{get:o,update:c,getWireframeAttribute:u}}function wp(i,t,e){let n;function s(d){n=d}let r,a;function o(d){r=d.type,a=d.bytesPerElement}function c(d,p){i.drawElements(n,p,r,d*a),e.update(p,n,1)}function l(d,p,g){g!==0&&(i.drawElementsInstanced(n,p,r,d*a,g),e.update(p,n,g))}function u(d,p,g){if(g===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,p,0,r,d,0,g);let m=0;for(let h=0;h<g;h++)m+=p[h];e.update(m,n,1)}function f(d,p,g,v){if(g===0)return;const m=t.get("WEBGL_multi_draw");if(m===null)for(let h=0;h<d.length;h++)l(d[h]/a,p[h],v[h]);else{m.multiDrawElementsInstancedWEBGL(n,p,0,r,d,0,v,0,g);let h=0;for(let T=0;T<g;T++)h+=p[T]*v[T];e.update(h,n,1)}}this.setMode=s,this.setIndex=o,this.render=c,this.renderInstances=l,this.renderMultiDraw=u,this.renderMultiDrawInstances=f}function Rp(i){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(e.calls++,a){case i.TRIANGLES:e.triangles+=o*(r/3);break;case i.LINES:e.lines+=o*(r/2);break;case i.LINE_STRIP:e.lines+=o*(r-1);break;case i.LINE_LOOP:e.lines+=o*r;break;case i.POINTS:e.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function Cp(i,t,e){const n=new WeakMap,s=new fe;function r(a,o,c){const l=a.morphTargetInfluences,u=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,f=u!==void 0?u.length:0;let d=n.get(o);if(d===void 0||d.count!==f){let M=function(){L.dispose(),n.delete(o),o.removeEventListener("dispose",M)};var p=M;d!==void 0&&d.texture.dispose();const g=o.morphAttributes.position!==void 0,v=o.morphAttributes.normal!==void 0,m=o.morphAttributes.color!==void 0,h=o.morphAttributes.position||[],T=o.morphAttributes.normal||[],b=o.morphAttributes.color||[];let E=0;g===!0&&(E=1),v===!0&&(E=2),m===!0&&(E=3);let R=o.attributes.position.count*E,w=1;R>t.maxTextureSize&&(w=Math.ceil(R/t.maxTextureSize),R=t.maxTextureSize);const C=new Float32Array(R*w*4*f),L=new nc(C,R,w,f);L.type=vn,L.needsUpdate=!0;const S=E*4;for(let P=0;P<f;P++){const F=h[P],k=T[P],j=b[P],W=R*w*4*P;for(let Y=0;Y<F.count;Y++){const K=Y*S;g===!0&&(s.fromBufferAttribute(F,Y),C[W+K+0]=s.x,C[W+K+1]=s.y,C[W+K+2]=s.z,C[W+K+3]=0),v===!0&&(s.fromBufferAttribute(k,Y),C[W+K+4]=s.x,C[W+K+5]=s.y,C[W+K+6]=s.z,C[W+K+7]=0),m===!0&&(s.fromBufferAttribute(j,Y),C[W+K+8]=s.x,C[W+K+9]=s.y,C[W+K+10]=s.z,C[W+K+11]=j.itemSize===4?s.w:1)}}d={count:f,texture:L,size:new Ot(R,w)},n.set(o,d),o.addEventListener("dispose",M)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)c.getUniforms().setValue(i,"morphTexture",a.morphTexture,e);else{let g=0;for(let m=0;m<l.length;m++)g+=l[m];const v=o.morphTargetsRelative?1:1-g;c.getUniforms().setValue(i,"morphTargetBaseInfluence",v),c.getUniforms().setValue(i,"morphTargetInfluences",l)}c.getUniforms().setValue(i,"morphTargetsTexture",d.texture,e),c.getUniforms().setValue(i,"morphTargetsTextureSize",d.size)}return{update:r}}function Pp(i,t,e,n){let s=new WeakMap;function r(c){const l=n.render.frame,u=c.geometry,f=t.get(c,u);if(s.get(f)!==l&&(t.update(f),s.set(f,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",o)===!1&&c.addEventListener("dispose",o),s.get(c)!==l&&(e.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,i.ARRAY_BUFFER),s.set(c,l))),c.isSkinnedMesh){const d=c.skeleton;s.get(d)!==l&&(d.update(),s.set(d,l))}return f}function a(){s=new WeakMap}function o(c){const l=c.target;l.removeEventListener("dispose",o),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:r,dispose:a}}const gc=new Ue,cl=new hc(1,1),_c=new nc,vc=new Zh,xc=new lc,hl=[],ul=[],dl=new Float32Array(16),fl=new Float32Array(9),pl=new Float32Array(4);function Ni(i,t,e){const n=i[0];if(n<=0||n>0)return i;const s=t*e;let r=hl[s];if(r===void 0&&(r=new Float32Array(s),hl[s]=r),t!==0){n.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,i[a].toArray(r,o)}return r}function xe(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function Me(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function rr(i,t){let e=ul[t];e===void 0&&(e=new Int32Array(t),ul[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function Dp(i,t){const e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function Lp(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(xe(e,t))return;i.uniform2fv(this.addr,t),Me(e,t)}}function Ip(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(xe(e,t))return;i.uniform3fv(this.addr,t),Me(e,t)}}function Up(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(xe(e,t))return;i.uniform4fv(this.addr,t),Me(e,t)}}function Np(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(xe(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),Me(e,t)}else{if(xe(e,n))return;pl.set(n),i.uniformMatrix2fv(this.addr,!1,pl),Me(e,n)}}function Fp(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(xe(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),Me(e,t)}else{if(xe(e,n))return;fl.set(n),i.uniformMatrix3fv(this.addr,!1,fl),Me(e,n)}}function Op(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(xe(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),Me(e,t)}else{if(xe(e,n))return;dl.set(n),i.uniformMatrix4fv(this.addr,!1,dl),Me(e,n)}}function Bp(i,t){const e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function zp(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(xe(e,t))return;i.uniform2iv(this.addr,t),Me(e,t)}}function kp(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(xe(e,t))return;i.uniform3iv(this.addr,t),Me(e,t)}}function Hp(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(xe(e,t))return;i.uniform4iv(this.addr,t),Me(e,t)}}function Vp(i,t){const e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function Gp(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(xe(e,t))return;i.uniform2uiv(this.addr,t),Me(e,t)}}function Wp(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(xe(e,t))return;i.uniform3uiv(this.addr,t),Me(e,t)}}function Xp(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(xe(e,t))return;i.uniform4uiv(this.addr,t),Me(e,t)}}function Yp(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(cl.compareFunction=Ql,r=cl):r=gc,e.setTexture2D(t||r,s)}function qp(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||vc,s)}function jp(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTextureCube(t||xc,s)}function $p(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||_c,s)}function Zp(i){switch(i){case 5126:return Dp;case 35664:return Lp;case 35665:return Ip;case 35666:return Up;case 35674:return Np;case 35675:return Fp;case 35676:return Op;case 5124:case 35670:return Bp;case 35667:case 35671:return zp;case 35668:case 35672:return kp;case 35669:case 35673:return Hp;case 5125:return Vp;case 36294:return Gp;case 36295:return Wp;case 36296:return Xp;case 35678:case 36198:case 36298:case 36306:case 35682:return Yp;case 35679:case 36299:case 36307:return qp;case 35680:case 36300:case 36308:case 36293:return jp;case 36289:case 36303:case 36311:case 36292:return $p}}function Kp(i,t){i.uniform1fv(this.addr,t)}function Jp(i,t){const e=Ni(t,this.size,2);i.uniform2fv(this.addr,e)}function Qp(i,t){const e=Ni(t,this.size,3);i.uniform3fv(this.addr,e)}function tm(i,t){const e=Ni(t,this.size,4);i.uniform4fv(this.addr,e)}function em(i,t){const e=Ni(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function nm(i,t){const e=Ni(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function im(i,t){const e=Ni(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function sm(i,t){i.uniform1iv(this.addr,t)}function rm(i,t){i.uniform2iv(this.addr,t)}function am(i,t){i.uniform3iv(this.addr,t)}function om(i,t){i.uniform4iv(this.addr,t)}function lm(i,t){i.uniform1uiv(this.addr,t)}function cm(i,t){i.uniform2uiv(this.addr,t)}function hm(i,t){i.uniform3uiv(this.addr,t)}function um(i,t){i.uniform4uiv(this.addr,t)}function dm(i,t,e){const n=this.cache,s=t.length,r=rr(e,s);xe(n,r)||(i.uniform1iv(this.addr,r),Me(n,r));for(let a=0;a!==s;++a)e.setTexture2D(t[a]||gc,r[a])}function fm(i,t,e){const n=this.cache,s=t.length,r=rr(e,s);xe(n,r)||(i.uniform1iv(this.addr,r),Me(n,r));for(let a=0;a!==s;++a)e.setTexture3D(t[a]||vc,r[a])}function pm(i,t,e){const n=this.cache,s=t.length,r=rr(e,s);xe(n,r)||(i.uniform1iv(this.addr,r),Me(n,r));for(let a=0;a!==s;++a)e.setTextureCube(t[a]||xc,r[a])}function mm(i,t,e){const n=this.cache,s=t.length,r=rr(e,s);xe(n,r)||(i.uniform1iv(this.addr,r),Me(n,r));for(let a=0;a!==s;++a)e.setTexture2DArray(t[a]||_c,r[a])}function gm(i){switch(i){case 5126:return Kp;case 35664:return Jp;case 35665:return Qp;case 35666:return tm;case 35674:return em;case 35675:return nm;case 35676:return im;case 5124:case 35670:return sm;case 35667:case 35671:return rm;case 35668:case 35672:return am;case 35669:case 35673:return om;case 5125:return lm;case 36294:return cm;case 36295:return hm;case 36296:return um;case 35678:case 36198:case 36298:case 36306:case 35682:return dm;case 35679:case 36299:case 36307:return fm;case 35680:case 36300:case 36308:case 36293:return pm;case 36289:case 36303:case 36311:case 36292:return mm}}class _m{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Zp(e.type)}}class vm{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=gm(e.type)}}class xm{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const s=this.seq;for(let r=0,a=s.length;r!==a;++r){const o=s[r];o.setValue(t,e[o.id],n)}}}const zr=/(\w+)(\])?(\[|\.)?/g;function ml(i,t){i.seq.push(t),i.map[t.id]=t}function Mm(i,t,e){const n=i.name,s=n.length;for(zr.lastIndex=0;;){const r=zr.exec(n),a=zr.lastIndex;let o=r[1];const c=r[2]==="]",l=r[3];if(c&&(o=o|0),l===void 0||l==="["&&a+2===s){ml(e,l===void 0?new _m(o,i,t):new vm(o,i,t));break}else{let f=e.map[o];f===void 0&&(f=new xm(o),ml(e,f)),e=f}}}class Ys{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){const r=t.getActiveUniform(e,s),a=t.getUniformLocation(e,r.name);Mm(r,a,this)}}setValue(t,e,n,s){const r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){const s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,a=e.length;r!==a;++r){const o=e[r],c=n[o.id];c.needsUpdate!==!1&&o.setValue(t,c.value,s)}}static seqWithValue(t,e){const n=[];for(let s=0,r=t.length;s!==r;++s){const a=t[s];a.id in e&&n.push(a)}return n}}function gl(i,t,e){const n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}const Sm=37297;let Em=0;function ym(i,t){const e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=s;a<r;a++){const o=a+1;n.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return n.join(`
`)}const _l=new Wt;function bm(i){Jt._getMatrix(_l,Jt.workingColorSpace,i);const t=`mat3( ${_l.elements.map(e=>e.toFixed(4))} )`;switch(Jt.getTransfer(i)){case js:return[t,"LinearTransferOETF"];case se:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[t,"LinearTransferOETF"]}}function vl(i,t,e){const n=i.getShaderParameter(t,i.COMPILE_STATUS),r=(i.getShaderInfoLog(t)||"").trim();if(n&&r==="")return"";const a=/ERROR: 0:(\d+)/.exec(r);if(a){const o=parseInt(a[1]);return e.toUpperCase()+`

`+r+`

`+ym(i.getShaderSource(t),o)}else return r}function Tm(i,t){const e=bm(t);return[`vec4 ${i}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function Am(i,t){let e;switch(t){case ch:e="Linear";break;case hh:e="Reinhard";break;case uh:e="Cineon";break;case dh:e="ACESFilmic";break;case ph:e="AgX";break;case mh:e="Neutral";break;case fh:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const zs=new I;function wm(){Jt.getLuminanceCoefficients(zs);const i=zs.x.toFixed(4),t=zs.y.toFixed(4),e=zs.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Rm(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Yi).join(`
`)}function Cm(i){const t=[];for(const e in i){const n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function Pm(i,t){const e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const r=i.getActiveAttrib(t,s),a=r.name;let o=1;r.type===i.FLOAT_MAT2&&(o=2),r.type===i.FLOAT_MAT3&&(o=3),r.type===i.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:i.getAttribLocation(t,a),locationSize:o}}return e}function Yi(i){return i!==""}function xl(i,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Ml(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const Dm=/^[ \t]*#include +<([\w\d./]+)>/gm;function Oa(i){return i.replace(Dm,Im)}const Lm=new Map;function Im(i,t){let e=Yt[t];if(e===void 0){const n=Lm.get(t);if(n!==void 0)e=Yt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Oa(e)}const Um=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Sl(i){return i.replace(Um,Nm)}function Nm(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function El(i){let t=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function Fm(i){let t="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Hl?t="SHADOWMAP_TYPE_PCF":i.shadowMapType===Vc?t="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===mn&&(t="SHADOWMAP_TYPE_VSM"),t}function Om(i){let t="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Ri:case Ci:t="ENVMAP_TYPE_CUBE";break;case nr:t="ENVMAP_TYPE_CUBE_UV";break}return t}function Bm(i){let t="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case Ci:t="ENVMAP_MODE_REFRACTION";break}return t}function zm(i){let t="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case Vl:t="ENVMAP_BLENDING_MULTIPLY";break;case oh:t="ENVMAP_BLENDING_MIX";break;case lh:t="ENVMAP_BLENDING_ADD";break}return t}function km(i){const t=i.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function Hm(i,t,e,n){const s=i.getContext(),r=e.defines;let a=e.vertexShader,o=e.fragmentShader;const c=Fm(e),l=Om(e),u=Bm(e),f=zm(e),d=km(e),p=Rm(e),g=Cm(r),v=s.createProgram();let m,h,T=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(Yi).join(`
`),m.length>0&&(m+=`
`),h=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(Yi).join(`
`),h.length>0&&(h+=`
`)):(m=[El(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+u:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Yi).join(`
`),h=[El(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+u:"",e.envMap?"#define "+f:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Dn?"#define TONE_MAPPING":"",e.toneMapping!==Dn?Yt.tonemapping_pars_fragment:"",e.toneMapping!==Dn?Am("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Yt.colorspace_pars_fragment,Tm("linearToOutputTexel",e.outputColorSpace),wm(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Yi).join(`
`)),a=Oa(a),a=xl(a,e),a=Ml(a,e),o=Oa(o),o=xl(o,e),o=Ml(o,e),a=Sl(a),o=Sl(o),e.isRawShaderMaterial!==!0&&(T=`#version 300 es
`,m=[p,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,h=["#define varying in",e.glslVersion===To?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===To?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+h);const b=T+m+a,E=T+h+o,R=gl(s,s.VERTEX_SHADER,b),w=gl(s,s.FRAGMENT_SHADER,E);s.attachShader(v,R),s.attachShader(v,w),e.index0AttributeName!==void 0?s.bindAttribLocation(v,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(v,0,"position"),s.linkProgram(v);function C(P){if(i.debug.checkShaderErrors){const F=s.getProgramInfoLog(v)||"",k=s.getShaderInfoLog(R)||"",j=s.getShaderInfoLog(w)||"",W=F.trim(),Y=k.trim(),K=j.trim();let H=!0,st=!0;if(s.getProgramParameter(v,s.LINK_STATUS)===!1)if(H=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,v,R,w);else{const V=vl(s,R,"vertex"),at=vl(s,w,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(v,s.VALIDATE_STATUS)+`

Material Name: `+P.name+`
Material Type: `+P.type+`

Program Info Log: `+W+`
`+V+`
`+at)}else W!==""?console.warn("THREE.WebGLProgram: Program Info Log:",W):(Y===""||K==="")&&(st=!1);st&&(P.diagnostics={runnable:H,programLog:W,vertexShader:{log:Y,prefix:m},fragmentShader:{log:K,prefix:h}})}s.deleteShader(R),s.deleteShader(w),L=new Ys(s,v),S=Pm(s,v)}let L;this.getUniforms=function(){return L===void 0&&C(this),L};let S;this.getAttributes=function(){return S===void 0&&C(this),S};let M=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return M===!1&&(M=s.getProgramParameter(v,Sm)),M},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(v),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Em++,this.cacheKey=t,this.usedTimes=1,this.program=v,this.vertexShader=R,this.fragmentShader=w,this}let Vm=0;class Gm{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const e=t.vertexShader,n=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(n),a=this._getShaderCacheForMaterial(t);return a.has(s)===!1&&(a.add(s),s.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new Wm(t),e.set(t,n)),n}}class Wm{constructor(t){this.id=Vm++,this.code=t,this.usedTimes=0}}function Xm(i,t,e,n,s,r,a){const o=new no,c=new Gm,l=new Set,u=[],f=s.logarithmicDepthBuffer,d=s.vertexTextures;let p=s.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(S){return l.add(S),S===0?"uv":`uv${S}`}function m(S,M,P,F,k){const j=F.fog,W=k.geometry,Y=S.isMeshStandardMaterial?F.environment:null,K=(S.isMeshStandardMaterial?e:t).get(S.envMap||Y),H=K&&K.mapping===nr?K.image.height:null,st=g[S.type];S.precision!==null&&(p=s.getMaxPrecision(S.precision),p!==S.precision&&console.warn("THREE.WebGLProgram.getParameters:",S.precision,"not supported, using",p,"instead."));const V=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,at=V!==void 0?V.length:0;let Et=0;W.morphAttributes.position!==void 0&&(Et=1),W.morphAttributes.normal!==void 0&&(Et=2),W.morphAttributes.color!==void 0&&(Et=3);let ht,It,Dt,G;if(st){const te=nn[st];ht=te.vertexShader,It=te.fragmentShader}else ht=S.vertexShader,It=S.fragmentShader,c.update(S),Dt=c.getVertexShaderID(S),G=c.getFragmentShaderID(S);const $=i.getRenderTarget(),dt=i.state.buffers.depth.getReversed(),Ut=k.isInstancedMesh===!0,yt=k.isBatchedMesh===!0,Xt=!!S.map,Se=!!S.matcap,A=!!K,Ct=!!S.aoMap,gt=!!S.lightMap,pt=!!S.bumpMap,ft=!!S.normalMap,Qt=!!S.displacementMap,_t=!!S.emissiveMap,Bt=!!S.metalnessMap,pe=!!S.roughnessMap,kt=S.anisotropy>0,y=S.clearcoat>0,_=S.dispersion>0,O=S.iridescence>0,q=S.sheen>0,J=S.transmission>0,X=kt&&!!S.anisotropyMap,wt=y&&!!S.clearcoatMap,it=y&&!!S.clearcoatNormalMap,bt=y&&!!S.clearcoatRoughnessMap,Tt=O&&!!S.iridescenceMap,et=O&&!!S.iridescenceThicknessMap,ut=q&&!!S.sheenColorMap,Nt=q&&!!S.sheenRoughnessMap,At=!!S.specularMap,lt=!!S.specularColorMap,Ht=!!S.specularIntensityMap,D=J&&!!S.transmissionMap,nt=J&&!!S.thicknessMap,rt=!!S.gradientMap,vt=!!S.alphaMap,Q=S.alphaTest>0,Z=!!S.alphaHash,St=!!S.extensions;let zt=Dn;S.toneMapped&&($===null||$.isXRRenderTarget===!0)&&(zt=i.toneMapping);const oe={shaderID:st,shaderType:S.type,shaderName:S.name,vertexShader:ht,fragmentShader:It,defines:S.defines,customVertexShaderID:Dt,customFragmentShaderID:G,isRawShaderMaterial:S.isRawShaderMaterial===!0,glslVersion:S.glslVersion,precision:p,batching:yt,batchingColor:yt&&k._colorsTexture!==null,instancing:Ut,instancingColor:Ut&&k.instanceColor!==null,instancingMorph:Ut&&k.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:$===null?i.outputColorSpace:$.isXRRenderTarget===!0?$.texture.colorSpace:Pi,alphaToCoverage:!!S.alphaToCoverage,map:Xt,matcap:Se,envMap:A,envMapMode:A&&K.mapping,envMapCubeUVHeight:H,aoMap:Ct,lightMap:gt,bumpMap:pt,normalMap:ft,displacementMap:d&&Qt,emissiveMap:_t,normalMapObjectSpace:ft&&S.normalMapType===xh,normalMapTangentSpace:ft&&S.normalMapType===Jl,metalnessMap:Bt,roughnessMap:pe,anisotropy:kt,anisotropyMap:X,clearcoat:y,clearcoatMap:wt,clearcoatNormalMap:it,clearcoatRoughnessMap:bt,dispersion:_,iridescence:O,iridescenceMap:Tt,iridescenceThicknessMap:et,sheen:q,sheenColorMap:ut,sheenRoughnessMap:Nt,specularMap:At,specularColorMap:lt,specularIntensityMap:Ht,transmission:J,transmissionMap:D,thicknessMap:nt,gradientMap:rt,opaque:S.transparent===!1&&S.blending===yi&&S.alphaToCoverage===!1,alphaMap:vt,alphaTest:Q,alphaHash:Z,combine:S.combine,mapUv:Xt&&v(S.map.channel),aoMapUv:Ct&&v(S.aoMap.channel),lightMapUv:gt&&v(S.lightMap.channel),bumpMapUv:pt&&v(S.bumpMap.channel),normalMapUv:ft&&v(S.normalMap.channel),displacementMapUv:Qt&&v(S.displacementMap.channel),emissiveMapUv:_t&&v(S.emissiveMap.channel),metalnessMapUv:Bt&&v(S.metalnessMap.channel),roughnessMapUv:pe&&v(S.roughnessMap.channel),anisotropyMapUv:X&&v(S.anisotropyMap.channel),clearcoatMapUv:wt&&v(S.clearcoatMap.channel),clearcoatNormalMapUv:it&&v(S.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:bt&&v(S.clearcoatRoughnessMap.channel),iridescenceMapUv:Tt&&v(S.iridescenceMap.channel),iridescenceThicknessMapUv:et&&v(S.iridescenceThicknessMap.channel),sheenColorMapUv:ut&&v(S.sheenColorMap.channel),sheenRoughnessMapUv:Nt&&v(S.sheenRoughnessMap.channel),specularMapUv:At&&v(S.specularMap.channel),specularColorMapUv:lt&&v(S.specularColorMap.channel),specularIntensityMapUv:Ht&&v(S.specularIntensityMap.channel),transmissionMapUv:D&&v(S.transmissionMap.channel),thicknessMapUv:nt&&v(S.thicknessMap.channel),alphaMapUv:vt&&v(S.alphaMap.channel),vertexTangents:!!W.attributes.tangent&&(ft||kt),vertexColors:S.vertexColors,vertexAlphas:S.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,pointsUvs:k.isPoints===!0&&!!W.attributes.uv&&(Xt||vt),fog:!!j,useFog:S.fog===!0,fogExp2:!!j&&j.isFogExp2,flatShading:S.flatShading===!0&&S.wireframe===!1,sizeAttenuation:S.sizeAttenuation===!0,logarithmicDepthBuffer:f,reversedDepthBuffer:dt,skinning:k.isSkinnedMesh===!0,morphTargets:W.morphAttributes.position!==void 0,morphNormals:W.morphAttributes.normal!==void 0,morphColors:W.morphAttributes.color!==void 0,morphTargetsCount:at,morphTextureStride:Et,numDirLights:M.directional.length,numPointLights:M.point.length,numSpotLights:M.spot.length,numSpotLightMaps:M.spotLightMap.length,numRectAreaLights:M.rectArea.length,numHemiLights:M.hemi.length,numDirLightShadows:M.directionalShadowMap.length,numPointLightShadows:M.pointShadowMap.length,numSpotLightShadows:M.spotShadowMap.length,numSpotLightShadowsWithMaps:M.numSpotLightShadowsWithMaps,numLightProbes:M.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:S.dithering,shadowMapEnabled:i.shadowMap.enabled&&P.length>0,shadowMapType:i.shadowMap.type,toneMapping:zt,decodeVideoTexture:Xt&&S.map.isVideoTexture===!0&&Jt.getTransfer(S.map.colorSpace)===se,decodeVideoTextureEmissive:_t&&S.emissiveMap.isVideoTexture===!0&&Jt.getTransfer(S.emissiveMap.colorSpace)===se,premultipliedAlpha:S.premultipliedAlpha,doubleSided:S.side===_n,flipSided:S.side===Ie,useDepthPacking:S.depthPacking>=0,depthPacking:S.depthPacking||0,index0AttributeName:S.index0AttributeName,extensionClipCullDistance:St&&S.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(St&&S.extensions.multiDraw===!0||yt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:S.customProgramCacheKey()};return oe.vertexUv1s=l.has(1),oe.vertexUv2s=l.has(2),oe.vertexUv3s=l.has(3),l.clear(),oe}function h(S){const M=[];if(S.shaderID?M.push(S.shaderID):(M.push(S.customVertexShaderID),M.push(S.customFragmentShaderID)),S.defines!==void 0)for(const P in S.defines)M.push(P),M.push(S.defines[P]);return S.isRawShaderMaterial===!1&&(T(M,S),b(M,S),M.push(i.outputColorSpace)),M.push(S.customProgramCacheKey),M.join()}function T(S,M){S.push(M.precision),S.push(M.outputColorSpace),S.push(M.envMapMode),S.push(M.envMapCubeUVHeight),S.push(M.mapUv),S.push(M.alphaMapUv),S.push(M.lightMapUv),S.push(M.aoMapUv),S.push(M.bumpMapUv),S.push(M.normalMapUv),S.push(M.displacementMapUv),S.push(M.emissiveMapUv),S.push(M.metalnessMapUv),S.push(M.roughnessMapUv),S.push(M.anisotropyMapUv),S.push(M.clearcoatMapUv),S.push(M.clearcoatNormalMapUv),S.push(M.clearcoatRoughnessMapUv),S.push(M.iridescenceMapUv),S.push(M.iridescenceThicknessMapUv),S.push(M.sheenColorMapUv),S.push(M.sheenRoughnessMapUv),S.push(M.specularMapUv),S.push(M.specularColorMapUv),S.push(M.specularIntensityMapUv),S.push(M.transmissionMapUv),S.push(M.thicknessMapUv),S.push(M.combine),S.push(M.fogExp2),S.push(M.sizeAttenuation),S.push(M.morphTargetsCount),S.push(M.morphAttributeCount),S.push(M.numDirLights),S.push(M.numPointLights),S.push(M.numSpotLights),S.push(M.numSpotLightMaps),S.push(M.numHemiLights),S.push(M.numRectAreaLights),S.push(M.numDirLightShadows),S.push(M.numPointLightShadows),S.push(M.numSpotLightShadows),S.push(M.numSpotLightShadowsWithMaps),S.push(M.numLightProbes),S.push(M.shadowMapType),S.push(M.toneMapping),S.push(M.numClippingPlanes),S.push(M.numClipIntersection),S.push(M.depthPacking)}function b(S,M){o.disableAll(),M.supportsVertexTextures&&o.enable(0),M.instancing&&o.enable(1),M.instancingColor&&o.enable(2),M.instancingMorph&&o.enable(3),M.matcap&&o.enable(4),M.envMap&&o.enable(5),M.normalMapObjectSpace&&o.enable(6),M.normalMapTangentSpace&&o.enable(7),M.clearcoat&&o.enable(8),M.iridescence&&o.enable(9),M.alphaTest&&o.enable(10),M.vertexColors&&o.enable(11),M.vertexAlphas&&o.enable(12),M.vertexUv1s&&o.enable(13),M.vertexUv2s&&o.enable(14),M.vertexUv3s&&o.enable(15),M.vertexTangents&&o.enable(16),M.anisotropy&&o.enable(17),M.alphaHash&&o.enable(18),M.batching&&o.enable(19),M.dispersion&&o.enable(20),M.batchingColor&&o.enable(21),M.gradientMap&&o.enable(22),S.push(o.mask),o.disableAll(),M.fog&&o.enable(0),M.useFog&&o.enable(1),M.flatShading&&o.enable(2),M.logarithmicDepthBuffer&&o.enable(3),M.reversedDepthBuffer&&o.enable(4),M.skinning&&o.enable(5),M.morphTargets&&o.enable(6),M.morphNormals&&o.enable(7),M.morphColors&&o.enable(8),M.premultipliedAlpha&&o.enable(9),M.shadowMapEnabled&&o.enable(10),M.doubleSided&&o.enable(11),M.flipSided&&o.enable(12),M.useDepthPacking&&o.enable(13),M.dithering&&o.enable(14),M.transmission&&o.enable(15),M.sheen&&o.enable(16),M.opaque&&o.enable(17),M.pointsUvs&&o.enable(18),M.decodeVideoTexture&&o.enable(19),M.decodeVideoTextureEmissive&&o.enable(20),M.alphaToCoverage&&o.enable(21),S.push(o.mask)}function E(S){const M=g[S.type];let P;if(M){const F=nn[M];P=cu.clone(F.uniforms)}else P=S.uniforms;return P}function R(S,M){let P;for(let F=0,k=u.length;F<k;F++){const j=u[F];if(j.cacheKey===M){P=j,++P.usedTimes;break}}return P===void 0&&(P=new Hm(i,M,S,r),u.push(P)),P}function w(S){if(--S.usedTimes===0){const M=u.indexOf(S);u[M]=u[u.length-1],u.pop(),S.destroy()}}function C(S){c.remove(S)}function L(){c.dispose()}return{getParameters:m,getProgramCacheKey:h,getUniforms:E,acquireProgram:R,releaseProgram:w,releaseShaderCache:C,programs:u,dispose:L}}function Ym(){let i=new WeakMap;function t(a){return i.has(a)}function e(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function s(a,o,c){i.get(a)[o]=c}function r(){i=new WeakMap}return{has:t,get:e,remove:n,update:s,dispose:r}}function qm(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.z!==t.z?i.z-t.z:i.id-t.id}function yl(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function bl(){const i=[];let t=0;const e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function a(f,d,p,g,v,m){let h=i[t];return h===void 0?(h={id:f.id,object:f,geometry:d,material:p,groupOrder:g,renderOrder:f.renderOrder,z:v,group:m},i[t]=h):(h.id=f.id,h.object=f,h.geometry=d,h.material=p,h.groupOrder=g,h.renderOrder=f.renderOrder,h.z=v,h.group=m),t++,h}function o(f,d,p,g,v,m){const h=a(f,d,p,g,v,m);p.transmission>0?n.push(h):p.transparent===!0?s.push(h):e.push(h)}function c(f,d,p,g,v,m){const h=a(f,d,p,g,v,m);p.transmission>0?n.unshift(h):p.transparent===!0?s.unshift(h):e.unshift(h)}function l(f,d){e.length>1&&e.sort(f||qm),n.length>1&&n.sort(d||yl),s.length>1&&s.sort(d||yl)}function u(){for(let f=t,d=i.length;f<d;f++){const p=i[f];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:o,unshift:c,finish:u,sort:l}}function jm(){let i=new WeakMap;function t(n,s){const r=i.get(n);let a;return r===void 0?(a=new bl,i.set(n,[a])):s>=r.length?(a=new bl,r.push(a)):a=r[s],a}function e(){i=new WeakMap}return{get:t,dispose:e}}function $m(){const i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new I,color:new jt};break;case"SpotLight":e={position:new I,direction:new I,color:new jt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new I,color:new jt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new I,skyColor:new jt,groundColor:new jt};break;case"RectAreaLight":e={color:new jt,position:new I,halfWidth:new I,halfHeight:new I};break}return i[t.id]=e,e}}}function Zm(){const i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ot};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ot};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ot,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}let Km=0;function Jm(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function Qm(i){const t=new $m,e=Zm(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new I);const s=new I,r=new ce,a=new ce;function o(l){let u=0,f=0,d=0;for(let S=0;S<9;S++)n.probe[S].set(0,0,0);let p=0,g=0,v=0,m=0,h=0,T=0,b=0,E=0,R=0,w=0,C=0;l.sort(Jm);for(let S=0,M=l.length;S<M;S++){const P=l[S],F=P.color,k=P.intensity,j=P.distance,W=P.shadow&&P.shadow.map?P.shadow.map.texture:null;if(P.isAmbientLight)u+=F.r*k,f+=F.g*k,d+=F.b*k;else if(P.isLightProbe){for(let Y=0;Y<9;Y++)n.probe[Y].addScaledVector(P.sh.coefficients[Y],k);C++}else if(P.isDirectionalLight){const Y=t.get(P);if(Y.color.copy(P.color).multiplyScalar(P.intensity),P.castShadow){const K=P.shadow,H=e.get(P);H.shadowIntensity=K.intensity,H.shadowBias=K.bias,H.shadowNormalBias=K.normalBias,H.shadowRadius=K.radius,H.shadowMapSize=K.mapSize,n.directionalShadow[p]=H,n.directionalShadowMap[p]=W,n.directionalShadowMatrix[p]=P.shadow.matrix,T++}n.directional[p]=Y,p++}else if(P.isSpotLight){const Y=t.get(P);Y.position.setFromMatrixPosition(P.matrixWorld),Y.color.copy(F).multiplyScalar(k),Y.distance=j,Y.coneCos=Math.cos(P.angle),Y.penumbraCos=Math.cos(P.angle*(1-P.penumbra)),Y.decay=P.decay,n.spot[v]=Y;const K=P.shadow;if(P.map&&(n.spotLightMap[R]=P.map,R++,K.updateMatrices(P),P.castShadow&&w++),n.spotLightMatrix[v]=K.matrix,P.castShadow){const H=e.get(P);H.shadowIntensity=K.intensity,H.shadowBias=K.bias,H.shadowNormalBias=K.normalBias,H.shadowRadius=K.radius,H.shadowMapSize=K.mapSize,n.spotShadow[v]=H,n.spotShadowMap[v]=W,E++}v++}else if(P.isRectAreaLight){const Y=t.get(P);Y.color.copy(F).multiplyScalar(k),Y.halfWidth.set(P.width*.5,0,0),Y.halfHeight.set(0,P.height*.5,0),n.rectArea[m]=Y,m++}else if(P.isPointLight){const Y=t.get(P);if(Y.color.copy(P.color).multiplyScalar(P.intensity),Y.distance=P.distance,Y.decay=P.decay,P.castShadow){const K=P.shadow,H=e.get(P);H.shadowIntensity=K.intensity,H.shadowBias=K.bias,H.shadowNormalBias=K.normalBias,H.shadowRadius=K.radius,H.shadowMapSize=K.mapSize,H.shadowCameraNear=K.camera.near,H.shadowCameraFar=K.camera.far,n.pointShadow[g]=H,n.pointShadowMap[g]=W,n.pointShadowMatrix[g]=P.shadow.matrix,b++}n.point[g]=Y,g++}else if(P.isHemisphereLight){const Y=t.get(P);Y.skyColor.copy(P.color).multiplyScalar(k),Y.groundColor.copy(P.groundColor).multiplyScalar(k),n.hemi[h]=Y,h++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=ot.LTC_FLOAT_1,n.rectAreaLTC2=ot.LTC_FLOAT_2):(n.rectAreaLTC1=ot.LTC_HALF_1,n.rectAreaLTC2=ot.LTC_HALF_2)),n.ambient[0]=u,n.ambient[1]=f,n.ambient[2]=d;const L=n.hash;(L.directionalLength!==p||L.pointLength!==g||L.spotLength!==v||L.rectAreaLength!==m||L.hemiLength!==h||L.numDirectionalShadows!==T||L.numPointShadows!==b||L.numSpotShadows!==E||L.numSpotMaps!==R||L.numLightProbes!==C)&&(n.directional.length=p,n.spot.length=v,n.rectArea.length=m,n.point.length=g,n.hemi.length=h,n.directionalShadow.length=T,n.directionalShadowMap.length=T,n.pointShadow.length=b,n.pointShadowMap.length=b,n.spotShadow.length=E,n.spotShadowMap.length=E,n.directionalShadowMatrix.length=T,n.pointShadowMatrix.length=b,n.spotLightMatrix.length=E+R-w,n.spotLightMap.length=R,n.numSpotLightShadowsWithMaps=w,n.numLightProbes=C,L.directionalLength=p,L.pointLength=g,L.spotLength=v,L.rectAreaLength=m,L.hemiLength=h,L.numDirectionalShadows=T,L.numPointShadows=b,L.numSpotShadows=E,L.numSpotMaps=R,L.numLightProbes=C,n.version=Km++)}function c(l,u){let f=0,d=0,p=0,g=0,v=0;const m=u.matrixWorldInverse;for(let h=0,T=l.length;h<T;h++){const b=l[h];if(b.isDirectionalLight){const E=n.directional[f];E.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),E.direction.sub(s),E.direction.transformDirection(m),f++}else if(b.isSpotLight){const E=n.spot[p];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(m),E.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),E.direction.sub(s),E.direction.transformDirection(m),p++}else if(b.isRectAreaLight){const E=n.rectArea[g];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(m),a.identity(),r.copy(b.matrixWorld),r.premultiply(m),a.extractRotation(r),E.halfWidth.set(b.width*.5,0,0),E.halfHeight.set(0,b.height*.5,0),E.halfWidth.applyMatrix4(a),E.halfHeight.applyMatrix4(a),g++}else if(b.isPointLight){const E=n.point[d];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(m),d++}else if(b.isHemisphereLight){const E=n.hemi[v];E.direction.setFromMatrixPosition(b.matrixWorld),E.direction.transformDirection(m),v++}}}return{setup:o,setupView:c,state:n}}function Tl(i){const t=new Qm(i),e=[],n=[];function s(u){l.camera=u,e.length=0,n.length=0}function r(u){e.push(u)}function a(u){n.push(u)}function o(){t.setup(e)}function c(u){t.setupView(e,u)}const l={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:s,state:l,setupLights:o,setupLightsView:c,pushLight:r,pushShadow:a}}function tg(i){let t=new WeakMap;function e(s,r=0){const a=t.get(s);let o;return a===void 0?(o=new Tl(i),t.set(s,[o])):r>=a.length?(o=new Tl(i),a.push(o)):o=a[r],o}function n(){t=new WeakMap}return{get:e,dispose:n}}const eg=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,ng=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function ig(i,t,e){let n=new io;const s=new Ot,r=new Ot,a=new fe,o=new Eu({depthPacking:vh}),c=new yu,l={},u=e.maxTextureSize,f={[Ln]:Ie,[Ie]:Ln,[_n]:_n},d=new In({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ot},radius:{value:4}},vertexShader:eg,fragmentShader:ng}),p=d.clone();p.defines.HORIZONTAL_PASS=1;const g=new Pe;g.setAttribute("position",new qe(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new Xe(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Hl;let h=this.type;this.render=function(w,C,L){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||w.length===0)return;const S=i.getRenderTarget(),M=i.getActiveCubeFace(),P=i.getActiveMipmapLevel(),F=i.state;F.setBlending(Pn),F.buffers.depth.getReversed()===!0?F.buffers.color.setClear(0,0,0,0):F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const k=h!==mn&&this.type===mn,j=h===mn&&this.type!==mn;for(let W=0,Y=w.length;W<Y;W++){const K=w[W],H=K.shadow;if(H===void 0){console.warn("THREE.WebGLShadowMap:",K,"has no shadow.");continue}if(H.autoUpdate===!1&&H.needsUpdate===!1)continue;s.copy(H.mapSize);const st=H.getFrameExtents();if(s.multiply(st),r.copy(H.mapSize),(s.x>u||s.y>u)&&(s.x>u&&(r.x=Math.floor(u/st.x),s.x=r.x*st.x,H.mapSize.x=r.x),s.y>u&&(r.y=Math.floor(u/st.y),s.y=r.y*st.y,H.mapSize.y=r.y)),H.map===null||k===!0||j===!0){const at=this.type!==mn?{minFilter:Qe,magFilter:Qe}:{};H.map!==null&&H.map.dispose(),H.map=new Kn(s.x,s.y,at),H.map.texture.name=K.name+".shadowMap",H.camera.updateProjectionMatrix()}i.setRenderTarget(H.map),i.clear();const V=H.getViewportCount();for(let at=0;at<V;at++){const Et=H.getViewport(at);a.set(r.x*Et.x,r.y*Et.y,r.x*Et.z,r.y*Et.w),F.viewport(a),H.updateMatrices(K,at),n=H.getFrustum(),E(C,L,H.camera,K,this.type)}H.isPointLightShadow!==!0&&this.type===mn&&T(H,L),H.needsUpdate=!1}h=this.type,m.needsUpdate=!1,i.setRenderTarget(S,M,P)};function T(w,C){const L=t.update(v);d.defines.VSM_SAMPLES!==w.blurSamples&&(d.defines.VSM_SAMPLES=w.blurSamples,p.defines.VSM_SAMPLES=w.blurSamples,d.needsUpdate=!0,p.needsUpdate=!0),w.mapPass===null&&(w.mapPass=new Kn(s.x,s.y)),d.uniforms.shadow_pass.value=w.map.texture,d.uniforms.resolution.value=w.mapSize,d.uniforms.radius.value=w.radius,i.setRenderTarget(w.mapPass),i.clear(),i.renderBufferDirect(C,null,L,d,v,null),p.uniforms.shadow_pass.value=w.mapPass.texture,p.uniforms.resolution.value=w.mapSize,p.uniforms.radius.value=w.radius,i.setRenderTarget(w.map),i.clear(),i.renderBufferDirect(C,null,L,p,v,null)}function b(w,C,L,S){let M=null;const P=L.isPointLight===!0?w.customDistanceMaterial:w.customDepthMaterial;if(P!==void 0)M=P;else if(M=L.isPointLight===!0?c:o,i.localClippingEnabled&&C.clipShadows===!0&&Array.isArray(C.clippingPlanes)&&C.clippingPlanes.length!==0||C.displacementMap&&C.displacementScale!==0||C.alphaMap&&C.alphaTest>0||C.map&&C.alphaTest>0||C.alphaToCoverage===!0){const F=M.uuid,k=C.uuid;let j=l[F];j===void 0&&(j={},l[F]=j);let W=j[k];W===void 0&&(W=M.clone(),j[k]=W,C.addEventListener("dispose",R)),M=W}if(M.visible=C.visible,M.wireframe=C.wireframe,S===mn?M.side=C.shadowSide!==null?C.shadowSide:C.side:M.side=C.shadowSide!==null?C.shadowSide:f[C.side],M.alphaMap=C.alphaMap,M.alphaTest=C.alphaToCoverage===!0?.5:C.alphaTest,M.map=C.map,M.clipShadows=C.clipShadows,M.clippingPlanes=C.clippingPlanes,M.clipIntersection=C.clipIntersection,M.displacementMap=C.displacementMap,M.displacementScale=C.displacementScale,M.displacementBias=C.displacementBias,M.wireframeLinewidth=C.wireframeLinewidth,M.linewidth=C.linewidth,L.isPointLight===!0&&M.isMeshDistanceMaterial===!0){const F=i.properties.get(M);F.light=L}return M}function E(w,C,L,S,M){if(w.visible===!1)return;if(w.layers.test(C.layers)&&(w.isMesh||w.isLine||w.isPoints)&&(w.castShadow||w.receiveShadow&&M===mn)&&(!w.frustumCulled||n.intersectsObject(w))){w.modelViewMatrix.multiplyMatrices(L.matrixWorldInverse,w.matrixWorld);const k=t.update(w),j=w.material;if(Array.isArray(j)){const W=k.groups;for(let Y=0,K=W.length;Y<K;Y++){const H=W[Y],st=j[H.materialIndex];if(st&&st.visible){const V=b(w,st,S,M);w.onBeforeShadow(i,w,C,L,k,V,H),i.renderBufferDirect(L,null,k,V,w,H),w.onAfterShadow(i,w,C,L,k,V,H)}}}else if(j.visible){const W=b(w,j,S,M);w.onBeforeShadow(i,w,C,L,k,W,null),i.renderBufferDirect(L,null,k,W,w,null),w.onAfterShadow(i,w,C,L,k,W,null)}}const F=w.children;for(let k=0,j=F.length;k<j;k++)E(F[k],C,L,S,M)}function R(w){w.target.removeEventListener("dispose",R);for(const L in l){const S=l[L],M=w.target.uuid;M in S&&(S[M].dispose(),delete S[M])}}}const sg={[Zr]:Kr,[Jr]:ea,[Qr]:na,[wi]:ta,[Kr]:Zr,[ea]:Jr,[na]:Qr,[ta]:wi};function rg(i,t){function e(){let D=!1;const nt=new fe;let rt=null;const vt=new fe(0,0,0,0);return{setMask:function(Q){rt!==Q&&!D&&(i.colorMask(Q,Q,Q,Q),rt=Q)},setLocked:function(Q){D=Q},setClear:function(Q,Z,St,zt,oe){oe===!0&&(Q*=zt,Z*=zt,St*=zt),nt.set(Q,Z,St,zt),vt.equals(nt)===!1&&(i.clearColor(Q,Z,St,zt),vt.copy(nt))},reset:function(){D=!1,rt=null,vt.set(-1,0,0,0)}}}function n(){let D=!1,nt=!1,rt=null,vt=null,Q=null;return{setReversed:function(Z){if(nt!==Z){const St=t.get("EXT_clip_control");Z?St.clipControlEXT(St.LOWER_LEFT_EXT,St.ZERO_TO_ONE_EXT):St.clipControlEXT(St.LOWER_LEFT_EXT,St.NEGATIVE_ONE_TO_ONE_EXT),nt=Z;const zt=Q;Q=null,this.setClear(zt)}},getReversed:function(){return nt},setTest:function(Z){Z?$(i.DEPTH_TEST):dt(i.DEPTH_TEST)},setMask:function(Z){rt!==Z&&!D&&(i.depthMask(Z),rt=Z)},setFunc:function(Z){if(nt&&(Z=sg[Z]),vt!==Z){switch(Z){case Zr:i.depthFunc(i.NEVER);break;case Kr:i.depthFunc(i.ALWAYS);break;case Jr:i.depthFunc(i.LESS);break;case wi:i.depthFunc(i.LEQUAL);break;case Qr:i.depthFunc(i.EQUAL);break;case ta:i.depthFunc(i.GEQUAL);break;case ea:i.depthFunc(i.GREATER);break;case na:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}vt=Z}},setLocked:function(Z){D=Z},setClear:function(Z){Q!==Z&&(nt&&(Z=1-Z),i.clearDepth(Z),Q=Z)},reset:function(){D=!1,rt=null,vt=null,Q=null,nt=!1}}}function s(){let D=!1,nt=null,rt=null,vt=null,Q=null,Z=null,St=null,zt=null,oe=null;return{setTest:function(te){D||(te?$(i.STENCIL_TEST):dt(i.STENCIL_TEST))},setMask:function(te){nt!==te&&!D&&(i.stencilMask(te),nt=te)},setFunc:function(te,ln,tn){(rt!==te||vt!==ln||Q!==tn)&&(i.stencilFunc(te,ln,tn),rt=te,vt=ln,Q=tn)},setOp:function(te,ln,tn){(Z!==te||St!==ln||zt!==tn)&&(i.stencilOp(te,ln,tn),Z=te,St=ln,zt=tn)},setLocked:function(te){D=te},setClear:function(te){oe!==te&&(i.clearStencil(te),oe=te)},reset:function(){D=!1,nt=null,rt=null,vt=null,Q=null,Z=null,St=null,zt=null,oe=null}}}const r=new e,a=new n,o=new s,c=new WeakMap,l=new WeakMap;let u={},f={},d=new WeakMap,p=[],g=null,v=!1,m=null,h=null,T=null,b=null,E=null,R=null,w=null,C=new jt(0,0,0),L=0,S=!1,M=null,P=null,F=null,k=null,j=null;const W=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let Y=!1,K=0;const H=i.getParameter(i.VERSION);H.indexOf("WebGL")!==-1?(K=parseFloat(/^WebGL (\d)/.exec(H)[1]),Y=K>=1):H.indexOf("OpenGL ES")!==-1&&(K=parseFloat(/^OpenGL ES (\d)/.exec(H)[1]),Y=K>=2);let st=null,V={};const at=i.getParameter(i.SCISSOR_BOX),Et=i.getParameter(i.VIEWPORT),ht=new fe().fromArray(at),It=new fe().fromArray(Et);function Dt(D,nt,rt,vt){const Q=new Uint8Array(4),Z=i.createTexture();i.bindTexture(D,Z),i.texParameteri(D,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(D,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let St=0;St<rt;St++)D===i.TEXTURE_3D||D===i.TEXTURE_2D_ARRAY?i.texImage3D(nt,0,i.RGBA,1,1,vt,0,i.RGBA,i.UNSIGNED_BYTE,Q):i.texImage2D(nt+St,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Q);return Z}const G={};G[i.TEXTURE_2D]=Dt(i.TEXTURE_2D,i.TEXTURE_2D,1),G[i.TEXTURE_CUBE_MAP]=Dt(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),G[i.TEXTURE_2D_ARRAY]=Dt(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),G[i.TEXTURE_3D]=Dt(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),a.setClear(1),o.setClear(0),$(i.DEPTH_TEST),a.setFunc(wi),pt(!1),ft(xo),$(i.CULL_FACE),Ct(Pn);function $(D){u[D]!==!0&&(i.enable(D),u[D]=!0)}function dt(D){u[D]!==!1&&(i.disable(D),u[D]=!1)}function Ut(D,nt){return f[D]!==nt?(i.bindFramebuffer(D,nt),f[D]=nt,D===i.DRAW_FRAMEBUFFER&&(f[i.FRAMEBUFFER]=nt),D===i.FRAMEBUFFER&&(f[i.DRAW_FRAMEBUFFER]=nt),!0):!1}function yt(D,nt){let rt=p,vt=!1;if(D){rt=d.get(nt),rt===void 0&&(rt=[],d.set(nt,rt));const Q=D.textures;if(rt.length!==Q.length||rt[0]!==i.COLOR_ATTACHMENT0){for(let Z=0,St=Q.length;Z<St;Z++)rt[Z]=i.COLOR_ATTACHMENT0+Z;rt.length=Q.length,vt=!0}}else rt[0]!==i.BACK&&(rt[0]=i.BACK,vt=!0);vt&&i.drawBuffers(rt)}function Xt(D){return g!==D?(i.useProgram(D),g=D,!0):!1}const Se={[Wn]:i.FUNC_ADD,[Wc]:i.FUNC_SUBTRACT,[Xc]:i.FUNC_REVERSE_SUBTRACT};Se[Yc]=i.MIN,Se[qc]=i.MAX;const A={[jc]:i.ZERO,[$c]:i.ONE,[Zc]:i.SRC_COLOR,[jr]:i.SRC_ALPHA,[nh]:i.SRC_ALPHA_SATURATE,[th]:i.DST_COLOR,[Jc]:i.DST_ALPHA,[Kc]:i.ONE_MINUS_SRC_COLOR,[$r]:i.ONE_MINUS_SRC_ALPHA,[eh]:i.ONE_MINUS_DST_COLOR,[Qc]:i.ONE_MINUS_DST_ALPHA,[ih]:i.CONSTANT_COLOR,[sh]:i.ONE_MINUS_CONSTANT_COLOR,[rh]:i.CONSTANT_ALPHA,[ah]:i.ONE_MINUS_CONSTANT_ALPHA};function Ct(D,nt,rt,vt,Q,Z,St,zt,oe,te){if(D===Pn){v===!0&&(dt(i.BLEND),v=!1);return}if(v===!1&&($(i.BLEND),v=!0),D!==Gc){if(D!==m||te!==S){if((h!==Wn||E!==Wn)&&(i.blendEquation(i.FUNC_ADD),h=Wn,E=Wn),te)switch(D){case yi:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Mo:i.blendFunc(i.ONE,i.ONE);break;case So:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Eo:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}else switch(D){case yi:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Mo:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case So:console.error("THREE.WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Eo:console.error("THREE.WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}T=null,b=null,R=null,w=null,C.set(0,0,0),L=0,m=D,S=te}return}Q=Q||nt,Z=Z||rt,St=St||vt,(nt!==h||Q!==E)&&(i.blendEquationSeparate(Se[nt],Se[Q]),h=nt,E=Q),(rt!==T||vt!==b||Z!==R||St!==w)&&(i.blendFuncSeparate(A[rt],A[vt],A[Z],A[St]),T=rt,b=vt,R=Z,w=St),(zt.equals(C)===!1||oe!==L)&&(i.blendColor(zt.r,zt.g,zt.b,oe),C.copy(zt),L=oe),m=D,S=!1}function gt(D,nt){D.side===_n?dt(i.CULL_FACE):$(i.CULL_FACE);let rt=D.side===Ie;nt&&(rt=!rt),pt(rt),D.blending===yi&&D.transparent===!1?Ct(Pn):Ct(D.blending,D.blendEquation,D.blendSrc,D.blendDst,D.blendEquationAlpha,D.blendSrcAlpha,D.blendDstAlpha,D.blendColor,D.blendAlpha,D.premultipliedAlpha),a.setFunc(D.depthFunc),a.setTest(D.depthTest),a.setMask(D.depthWrite),r.setMask(D.colorWrite);const vt=D.stencilWrite;o.setTest(vt),vt&&(o.setMask(D.stencilWriteMask),o.setFunc(D.stencilFunc,D.stencilRef,D.stencilFuncMask),o.setOp(D.stencilFail,D.stencilZFail,D.stencilZPass)),_t(D.polygonOffset,D.polygonOffsetFactor,D.polygonOffsetUnits),D.alphaToCoverage===!0?$(i.SAMPLE_ALPHA_TO_COVERAGE):dt(i.SAMPLE_ALPHA_TO_COVERAGE)}function pt(D){M!==D&&(D?i.frontFace(i.CW):i.frontFace(i.CCW),M=D)}function ft(D){D!==kc?($(i.CULL_FACE),D!==P&&(D===xo?i.cullFace(i.BACK):D===Hc?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):dt(i.CULL_FACE),P=D}function Qt(D){D!==F&&(Y&&i.lineWidth(D),F=D)}function _t(D,nt,rt){D?($(i.POLYGON_OFFSET_FILL),(k!==nt||j!==rt)&&(i.polygonOffset(nt,rt),k=nt,j=rt)):dt(i.POLYGON_OFFSET_FILL)}function Bt(D){D?$(i.SCISSOR_TEST):dt(i.SCISSOR_TEST)}function pe(D){D===void 0&&(D=i.TEXTURE0+W-1),st!==D&&(i.activeTexture(D),st=D)}function kt(D,nt,rt){rt===void 0&&(st===null?rt=i.TEXTURE0+W-1:rt=st);let vt=V[rt];vt===void 0&&(vt={type:void 0,texture:void 0},V[rt]=vt),(vt.type!==D||vt.texture!==nt)&&(st!==rt&&(i.activeTexture(rt),st=rt),i.bindTexture(D,nt||G[D]),vt.type=D,vt.texture=nt)}function y(){const D=V[st];D!==void 0&&D.type!==void 0&&(i.bindTexture(D.type,null),D.type=void 0,D.texture=void 0)}function _(){try{i.compressedTexImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function O(){try{i.compressedTexImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function q(){try{i.texSubImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function J(){try{i.texSubImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function X(){try{i.compressedTexSubImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function wt(){try{i.compressedTexSubImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function it(){try{i.texStorage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function bt(){try{i.texStorage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Tt(){try{i.texImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function et(){try{i.texImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function ut(D){ht.equals(D)===!1&&(i.scissor(D.x,D.y,D.z,D.w),ht.copy(D))}function Nt(D){It.equals(D)===!1&&(i.viewport(D.x,D.y,D.z,D.w),It.copy(D))}function At(D,nt){let rt=l.get(nt);rt===void 0&&(rt=new WeakMap,l.set(nt,rt));let vt=rt.get(D);vt===void 0&&(vt=i.getUniformBlockIndex(nt,D.name),rt.set(D,vt))}function lt(D,nt){const vt=l.get(nt).get(D);c.get(nt)!==vt&&(i.uniformBlockBinding(nt,vt,D.__bindingPointIndex),c.set(nt,vt))}function Ht(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),u={},st=null,V={},f={},d=new WeakMap,p=[],g=null,v=!1,m=null,h=null,T=null,b=null,E=null,R=null,w=null,C=new jt(0,0,0),L=0,S=!1,M=null,P=null,F=null,k=null,j=null,ht.set(0,0,i.canvas.width,i.canvas.height),It.set(0,0,i.canvas.width,i.canvas.height),r.reset(),a.reset(),o.reset()}return{buffers:{color:r,depth:a,stencil:o},enable:$,disable:dt,bindFramebuffer:Ut,drawBuffers:yt,useProgram:Xt,setBlending:Ct,setMaterial:gt,setFlipSided:pt,setCullFace:ft,setLineWidth:Qt,setPolygonOffset:_t,setScissorTest:Bt,activeTexture:pe,bindTexture:kt,unbindTexture:y,compressedTexImage2D:_,compressedTexImage3D:O,texImage2D:Tt,texImage3D:et,updateUBOMapping:At,uniformBlockBinding:lt,texStorage2D:it,texStorage3D:bt,texSubImage2D:q,texSubImage3D:J,compressedTexSubImage2D:X,compressedTexSubImage3D:wt,scissor:ut,viewport:Nt,reset:Ht}}function ag(i,t,e,n,s,r,a){const o=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new Ot,u=new WeakMap;let f;const d=new WeakMap;let p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(y,_){return p?new OffscreenCanvas(y,_):Zs("canvas")}function v(y,_,O){let q=1;const J=kt(y);if((J.width>O||J.height>O)&&(q=O/Math.max(J.width,J.height)),q<1)if(typeof HTMLImageElement<"u"&&y instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&y instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&y instanceof ImageBitmap||typeof VideoFrame<"u"&&y instanceof VideoFrame){const X=Math.floor(q*J.width),wt=Math.floor(q*J.height);f===void 0&&(f=g(X,wt));const it=_?g(X,wt):f;return it.width=X,it.height=wt,it.getContext("2d").drawImage(y,0,0,X,wt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+J.width+"x"+J.height+") to ("+X+"x"+wt+")."),it}else return"data"in y&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+J.width+"x"+J.height+")."),y;return y}function m(y){return y.generateMipmaps}function h(y){i.generateMipmap(y)}function T(y){return y.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:y.isWebGL3DRenderTarget?i.TEXTURE_3D:y.isWebGLArrayRenderTarget||y.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function b(y,_,O,q,J=!1){if(y!==null){if(i[y]!==void 0)return i[y];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+y+"'")}let X=_;if(_===i.RED&&(O===i.FLOAT&&(X=i.R32F),O===i.HALF_FLOAT&&(X=i.R16F),O===i.UNSIGNED_BYTE&&(X=i.R8)),_===i.RED_INTEGER&&(O===i.UNSIGNED_BYTE&&(X=i.R8UI),O===i.UNSIGNED_SHORT&&(X=i.R16UI),O===i.UNSIGNED_INT&&(X=i.R32UI),O===i.BYTE&&(X=i.R8I),O===i.SHORT&&(X=i.R16I),O===i.INT&&(X=i.R32I)),_===i.RG&&(O===i.FLOAT&&(X=i.RG32F),O===i.HALF_FLOAT&&(X=i.RG16F),O===i.UNSIGNED_BYTE&&(X=i.RG8)),_===i.RG_INTEGER&&(O===i.UNSIGNED_BYTE&&(X=i.RG8UI),O===i.UNSIGNED_SHORT&&(X=i.RG16UI),O===i.UNSIGNED_INT&&(X=i.RG32UI),O===i.BYTE&&(X=i.RG8I),O===i.SHORT&&(X=i.RG16I),O===i.INT&&(X=i.RG32I)),_===i.RGB_INTEGER&&(O===i.UNSIGNED_BYTE&&(X=i.RGB8UI),O===i.UNSIGNED_SHORT&&(X=i.RGB16UI),O===i.UNSIGNED_INT&&(X=i.RGB32UI),O===i.BYTE&&(X=i.RGB8I),O===i.SHORT&&(X=i.RGB16I),O===i.INT&&(X=i.RGB32I)),_===i.RGBA_INTEGER&&(O===i.UNSIGNED_BYTE&&(X=i.RGBA8UI),O===i.UNSIGNED_SHORT&&(X=i.RGBA16UI),O===i.UNSIGNED_INT&&(X=i.RGBA32UI),O===i.BYTE&&(X=i.RGBA8I),O===i.SHORT&&(X=i.RGBA16I),O===i.INT&&(X=i.RGBA32I)),_===i.RGB&&(O===i.UNSIGNED_INT_5_9_9_9_REV&&(X=i.RGB9_E5),O===i.UNSIGNED_INT_10F_11F_11F_REV&&(X=i.R11F_G11F_B10F)),_===i.RGBA){const wt=J?js:Jt.getTransfer(q);O===i.FLOAT&&(X=i.RGBA32F),O===i.HALF_FLOAT&&(X=i.RGBA16F),O===i.UNSIGNED_BYTE&&(X=wt===se?i.SRGB8_ALPHA8:i.RGBA8),O===i.UNSIGNED_SHORT_4_4_4_4&&(X=i.RGBA4),O===i.UNSIGNED_SHORT_5_5_5_1&&(X=i.RGB5_A1)}return(X===i.R16F||X===i.R32F||X===i.RG16F||X===i.RG32F||X===i.RGBA16F||X===i.RGBA32F)&&t.get("EXT_color_buffer_float"),X}function E(y,_){let O;return y?_===null||_===$n||_===Ki?O=i.DEPTH24_STENCIL8:_===vn?O=i.DEPTH32F_STENCIL8:_===Zi&&(O=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):_===null||_===$n||_===Ki?O=i.DEPTH_COMPONENT24:_===vn?O=i.DEPTH_COMPONENT32F:_===Zi&&(O=i.DEPTH_COMPONENT16),O}function R(y,_){return m(y)===!0||y.isFramebufferTexture&&y.minFilter!==Qe&&y.minFilter!==sn?Math.log2(Math.max(_.width,_.height))+1:y.mipmaps!==void 0&&y.mipmaps.length>0?y.mipmaps.length:y.isCompressedTexture&&Array.isArray(y.image)?_.mipmaps.length:1}function w(y){const _=y.target;_.removeEventListener("dispose",w),L(_),_.isVideoTexture&&u.delete(_)}function C(y){const _=y.target;_.removeEventListener("dispose",C),M(_)}function L(y){const _=n.get(y);if(_.__webglInit===void 0)return;const O=y.source,q=d.get(O);if(q){const J=q[_.__cacheKey];J.usedTimes--,J.usedTimes===0&&S(y),Object.keys(q).length===0&&d.delete(O)}n.remove(y)}function S(y){const _=n.get(y);i.deleteTexture(_.__webglTexture);const O=y.source,q=d.get(O);delete q[_.__cacheKey],a.memory.textures--}function M(y){const _=n.get(y);if(y.depthTexture&&(y.depthTexture.dispose(),n.remove(y.depthTexture)),y.isWebGLCubeRenderTarget)for(let q=0;q<6;q++){if(Array.isArray(_.__webglFramebuffer[q]))for(let J=0;J<_.__webglFramebuffer[q].length;J++)i.deleteFramebuffer(_.__webglFramebuffer[q][J]);else i.deleteFramebuffer(_.__webglFramebuffer[q]);_.__webglDepthbuffer&&i.deleteRenderbuffer(_.__webglDepthbuffer[q])}else{if(Array.isArray(_.__webglFramebuffer))for(let q=0;q<_.__webglFramebuffer.length;q++)i.deleteFramebuffer(_.__webglFramebuffer[q]);else i.deleteFramebuffer(_.__webglFramebuffer);if(_.__webglDepthbuffer&&i.deleteRenderbuffer(_.__webglDepthbuffer),_.__webglMultisampledFramebuffer&&i.deleteFramebuffer(_.__webglMultisampledFramebuffer),_.__webglColorRenderbuffer)for(let q=0;q<_.__webglColorRenderbuffer.length;q++)_.__webglColorRenderbuffer[q]&&i.deleteRenderbuffer(_.__webglColorRenderbuffer[q]);_.__webglDepthRenderbuffer&&i.deleteRenderbuffer(_.__webglDepthRenderbuffer)}const O=y.textures;for(let q=0,J=O.length;q<J;q++){const X=n.get(O[q]);X.__webglTexture&&(i.deleteTexture(X.__webglTexture),a.memory.textures--),n.remove(O[q])}n.remove(y)}let P=0;function F(){P=0}function k(){const y=P;return y>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+y+" texture units while this GPU supports only "+s.maxTextures),P+=1,y}function j(y){const _=[];return _.push(y.wrapS),_.push(y.wrapT),_.push(y.wrapR||0),_.push(y.magFilter),_.push(y.minFilter),_.push(y.anisotropy),_.push(y.internalFormat),_.push(y.format),_.push(y.type),_.push(y.generateMipmaps),_.push(y.premultiplyAlpha),_.push(y.flipY),_.push(y.unpackAlignment),_.push(y.colorSpace),_.join()}function W(y,_){const O=n.get(y);if(y.isVideoTexture&&Bt(y),y.isRenderTargetTexture===!1&&y.isExternalTexture!==!0&&y.version>0&&O.__version!==y.version){const q=y.image;if(q===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(q.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{G(O,y,_);return}}else y.isExternalTexture&&(O.__webglTexture=y.sourceTexture?y.sourceTexture:null);e.bindTexture(i.TEXTURE_2D,O.__webglTexture,i.TEXTURE0+_)}function Y(y,_){const O=n.get(y);if(y.isRenderTargetTexture===!1&&y.version>0&&O.__version!==y.version){G(O,y,_);return}e.bindTexture(i.TEXTURE_2D_ARRAY,O.__webglTexture,i.TEXTURE0+_)}function K(y,_){const O=n.get(y);if(y.isRenderTargetTexture===!1&&y.version>0&&O.__version!==y.version){G(O,y,_);return}e.bindTexture(i.TEXTURE_3D,O.__webglTexture,i.TEXTURE0+_)}function H(y,_){const O=n.get(y);if(y.version>0&&O.__version!==y.version){$(O,y,_);return}e.bindTexture(i.TEXTURE_CUBE_MAP,O.__webglTexture,i.TEXTURE0+_)}const st={[ra]:i.REPEAT,[Yn]:i.CLAMP_TO_EDGE,[aa]:i.MIRRORED_REPEAT},V={[Qe]:i.NEAREST,[gh]:i.NEAREST_MIPMAP_NEAREST,[ds]:i.NEAREST_MIPMAP_LINEAR,[sn]:i.LINEAR,[lr]:i.LINEAR_MIPMAP_NEAREST,[qn]:i.LINEAR_MIPMAP_LINEAR},at={[Mh]:i.NEVER,[Ah]:i.ALWAYS,[Sh]:i.LESS,[Ql]:i.LEQUAL,[Eh]:i.EQUAL,[Th]:i.GEQUAL,[yh]:i.GREATER,[bh]:i.NOTEQUAL};function Et(y,_){if(_.type===vn&&t.has("OES_texture_float_linear")===!1&&(_.magFilter===sn||_.magFilter===lr||_.magFilter===ds||_.magFilter===qn||_.minFilter===sn||_.minFilter===lr||_.minFilter===ds||_.minFilter===qn)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(y,i.TEXTURE_WRAP_S,st[_.wrapS]),i.texParameteri(y,i.TEXTURE_WRAP_T,st[_.wrapT]),(y===i.TEXTURE_3D||y===i.TEXTURE_2D_ARRAY)&&i.texParameteri(y,i.TEXTURE_WRAP_R,st[_.wrapR]),i.texParameteri(y,i.TEXTURE_MAG_FILTER,V[_.magFilter]),i.texParameteri(y,i.TEXTURE_MIN_FILTER,V[_.minFilter]),_.compareFunction&&(i.texParameteri(y,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(y,i.TEXTURE_COMPARE_FUNC,at[_.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(_.magFilter===Qe||_.minFilter!==ds&&_.minFilter!==qn||_.type===vn&&t.has("OES_texture_float_linear")===!1)return;if(_.anisotropy>1||n.get(_).__currentAnisotropy){const O=t.get("EXT_texture_filter_anisotropic");i.texParameterf(y,O.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,s.getMaxAnisotropy())),n.get(_).__currentAnisotropy=_.anisotropy}}}function ht(y,_){let O=!1;y.__webglInit===void 0&&(y.__webglInit=!0,_.addEventListener("dispose",w));const q=_.source;let J=d.get(q);J===void 0&&(J={},d.set(q,J));const X=j(_);if(X!==y.__cacheKey){J[X]===void 0&&(J[X]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,O=!0),J[X].usedTimes++;const wt=J[y.__cacheKey];wt!==void 0&&(J[y.__cacheKey].usedTimes--,wt.usedTimes===0&&S(_)),y.__cacheKey=X,y.__webglTexture=J[X].texture}return O}function It(y,_,O){return Math.floor(Math.floor(y/O)/_)}function Dt(y,_,O,q){const X=y.updateRanges;if(X.length===0)e.texSubImage2D(i.TEXTURE_2D,0,0,0,_.width,_.height,O,q,_.data);else{X.sort((et,ut)=>et.start-ut.start);let wt=0;for(let et=1;et<X.length;et++){const ut=X[wt],Nt=X[et],At=ut.start+ut.count,lt=It(Nt.start,_.width,4),Ht=It(ut.start,_.width,4);Nt.start<=At+1&&lt===Ht&&It(Nt.start+Nt.count-1,_.width,4)===lt?ut.count=Math.max(ut.count,Nt.start+Nt.count-ut.start):(++wt,X[wt]=Nt)}X.length=wt+1;const it=i.getParameter(i.UNPACK_ROW_LENGTH),bt=i.getParameter(i.UNPACK_SKIP_PIXELS),Tt=i.getParameter(i.UNPACK_SKIP_ROWS);i.pixelStorei(i.UNPACK_ROW_LENGTH,_.width);for(let et=0,ut=X.length;et<ut;et++){const Nt=X[et],At=Math.floor(Nt.start/4),lt=Math.ceil(Nt.count/4),Ht=At%_.width,D=Math.floor(At/_.width),nt=lt,rt=1;i.pixelStorei(i.UNPACK_SKIP_PIXELS,Ht),i.pixelStorei(i.UNPACK_SKIP_ROWS,D),e.texSubImage2D(i.TEXTURE_2D,0,Ht,D,nt,rt,O,q,_.data)}y.clearUpdateRanges(),i.pixelStorei(i.UNPACK_ROW_LENGTH,it),i.pixelStorei(i.UNPACK_SKIP_PIXELS,bt),i.pixelStorei(i.UNPACK_SKIP_ROWS,Tt)}}function G(y,_,O){let q=i.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(q=i.TEXTURE_2D_ARRAY),_.isData3DTexture&&(q=i.TEXTURE_3D);const J=ht(y,_),X=_.source;e.bindTexture(q,y.__webglTexture,i.TEXTURE0+O);const wt=n.get(X);if(X.version!==wt.__version||J===!0){e.activeTexture(i.TEXTURE0+O);const it=Jt.getPrimaries(Jt.workingColorSpace),bt=_.colorSpace===Cn?null:Jt.getPrimaries(_.colorSpace),Tt=_.colorSpace===Cn||it===bt?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,_.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,_.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Tt);let et=v(_.image,!1,s.maxTextureSize);et=pe(_,et);const ut=r.convert(_.format,_.colorSpace),Nt=r.convert(_.type);let At=b(_.internalFormat,ut,Nt,_.colorSpace,_.isVideoTexture);Et(q,_);let lt;const Ht=_.mipmaps,D=_.isVideoTexture!==!0,nt=wt.__version===void 0||J===!0,rt=X.dataReady,vt=R(_,et);if(_.isDepthTexture)At=E(_.format===Qi,_.type),nt&&(D?e.texStorage2D(i.TEXTURE_2D,1,At,et.width,et.height):e.texImage2D(i.TEXTURE_2D,0,At,et.width,et.height,0,ut,Nt,null));else if(_.isDataTexture)if(Ht.length>0){D&&nt&&e.texStorage2D(i.TEXTURE_2D,vt,At,Ht[0].width,Ht[0].height);for(let Q=0,Z=Ht.length;Q<Z;Q++)lt=Ht[Q],D?rt&&e.texSubImage2D(i.TEXTURE_2D,Q,0,0,lt.width,lt.height,ut,Nt,lt.data):e.texImage2D(i.TEXTURE_2D,Q,At,lt.width,lt.height,0,ut,Nt,lt.data);_.generateMipmaps=!1}else D?(nt&&e.texStorage2D(i.TEXTURE_2D,vt,At,et.width,et.height),rt&&Dt(_,et,ut,Nt)):e.texImage2D(i.TEXTURE_2D,0,At,et.width,et.height,0,ut,Nt,et.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){D&&nt&&e.texStorage3D(i.TEXTURE_2D_ARRAY,vt,At,Ht[0].width,Ht[0].height,et.depth);for(let Q=0,Z=Ht.length;Q<Z;Q++)if(lt=Ht[Q],_.format!==Je)if(ut!==null)if(D){if(rt)if(_.layerUpdates.size>0){const St=el(lt.width,lt.height,_.format,_.type);for(const zt of _.layerUpdates){const oe=lt.data.subarray(zt*St/lt.data.BYTES_PER_ELEMENT,(zt+1)*St/lt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,Q,0,0,zt,lt.width,lt.height,1,ut,oe)}_.clearLayerUpdates()}else e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,Q,0,0,0,lt.width,lt.height,et.depth,ut,lt.data)}else e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,Q,At,lt.width,lt.height,et.depth,0,lt.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else D?rt&&e.texSubImage3D(i.TEXTURE_2D_ARRAY,Q,0,0,0,lt.width,lt.height,et.depth,ut,Nt,lt.data):e.texImage3D(i.TEXTURE_2D_ARRAY,Q,At,lt.width,lt.height,et.depth,0,ut,Nt,lt.data)}else{D&&nt&&e.texStorage2D(i.TEXTURE_2D,vt,At,Ht[0].width,Ht[0].height);for(let Q=0,Z=Ht.length;Q<Z;Q++)lt=Ht[Q],_.format!==Je?ut!==null?D?rt&&e.compressedTexSubImage2D(i.TEXTURE_2D,Q,0,0,lt.width,lt.height,ut,lt.data):e.compressedTexImage2D(i.TEXTURE_2D,Q,At,lt.width,lt.height,0,lt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):D?rt&&e.texSubImage2D(i.TEXTURE_2D,Q,0,0,lt.width,lt.height,ut,Nt,lt.data):e.texImage2D(i.TEXTURE_2D,Q,At,lt.width,lt.height,0,ut,Nt,lt.data)}else if(_.isDataArrayTexture)if(D){if(nt&&e.texStorage3D(i.TEXTURE_2D_ARRAY,vt,At,et.width,et.height,et.depth),rt)if(_.layerUpdates.size>0){const Q=el(et.width,et.height,_.format,_.type);for(const Z of _.layerUpdates){const St=et.data.subarray(Z*Q/et.data.BYTES_PER_ELEMENT,(Z+1)*Q/et.data.BYTES_PER_ELEMENT);e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Z,et.width,et.height,1,ut,Nt,St)}_.clearLayerUpdates()}else e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,et.width,et.height,et.depth,ut,Nt,et.data)}else e.texImage3D(i.TEXTURE_2D_ARRAY,0,At,et.width,et.height,et.depth,0,ut,Nt,et.data);else if(_.isData3DTexture)D?(nt&&e.texStorage3D(i.TEXTURE_3D,vt,At,et.width,et.height,et.depth),rt&&e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,et.width,et.height,et.depth,ut,Nt,et.data)):e.texImage3D(i.TEXTURE_3D,0,At,et.width,et.height,et.depth,0,ut,Nt,et.data);else if(_.isFramebufferTexture){if(nt)if(D)e.texStorage2D(i.TEXTURE_2D,vt,At,et.width,et.height);else{let Q=et.width,Z=et.height;for(let St=0;St<vt;St++)e.texImage2D(i.TEXTURE_2D,St,At,Q,Z,0,ut,Nt,null),Q>>=1,Z>>=1}}else if(Ht.length>0){if(D&&nt){const Q=kt(Ht[0]);e.texStorage2D(i.TEXTURE_2D,vt,At,Q.width,Q.height)}for(let Q=0,Z=Ht.length;Q<Z;Q++)lt=Ht[Q],D?rt&&e.texSubImage2D(i.TEXTURE_2D,Q,0,0,ut,Nt,lt):e.texImage2D(i.TEXTURE_2D,Q,At,ut,Nt,lt);_.generateMipmaps=!1}else if(D){if(nt){const Q=kt(et);e.texStorage2D(i.TEXTURE_2D,vt,At,Q.width,Q.height)}rt&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,ut,Nt,et)}else e.texImage2D(i.TEXTURE_2D,0,At,ut,Nt,et);m(_)&&h(q),wt.__version=X.version,_.onUpdate&&_.onUpdate(_)}y.__version=_.version}function $(y,_,O){if(_.image.length!==6)return;const q=ht(y,_),J=_.source;e.bindTexture(i.TEXTURE_CUBE_MAP,y.__webglTexture,i.TEXTURE0+O);const X=n.get(J);if(J.version!==X.__version||q===!0){e.activeTexture(i.TEXTURE0+O);const wt=Jt.getPrimaries(Jt.workingColorSpace),it=_.colorSpace===Cn?null:Jt.getPrimaries(_.colorSpace),bt=_.colorSpace===Cn||wt===it?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,_.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,_.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,bt);const Tt=_.isCompressedTexture||_.image[0].isCompressedTexture,et=_.image[0]&&_.image[0].isDataTexture,ut=[];for(let Z=0;Z<6;Z++)!Tt&&!et?ut[Z]=v(_.image[Z],!0,s.maxCubemapSize):ut[Z]=et?_.image[Z].image:_.image[Z],ut[Z]=pe(_,ut[Z]);const Nt=ut[0],At=r.convert(_.format,_.colorSpace),lt=r.convert(_.type),Ht=b(_.internalFormat,At,lt,_.colorSpace),D=_.isVideoTexture!==!0,nt=X.__version===void 0||q===!0,rt=J.dataReady;let vt=R(_,Nt);Et(i.TEXTURE_CUBE_MAP,_);let Q;if(Tt){D&&nt&&e.texStorage2D(i.TEXTURE_CUBE_MAP,vt,Ht,Nt.width,Nt.height);for(let Z=0;Z<6;Z++){Q=ut[Z].mipmaps;for(let St=0;St<Q.length;St++){const zt=Q[St];_.format!==Je?At!==null?D?rt&&e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,St,0,0,zt.width,zt.height,At,zt.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,St,Ht,zt.width,zt.height,0,zt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):D?rt&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,St,0,0,zt.width,zt.height,At,lt,zt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,St,Ht,zt.width,zt.height,0,At,lt,zt.data)}}}else{if(Q=_.mipmaps,D&&nt){Q.length>0&&vt++;const Z=kt(ut[0]);e.texStorage2D(i.TEXTURE_CUBE_MAP,vt,Ht,Z.width,Z.height)}for(let Z=0;Z<6;Z++)if(et){D?rt&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,ut[Z].width,ut[Z].height,At,lt,ut[Z].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,Ht,ut[Z].width,ut[Z].height,0,At,lt,ut[Z].data);for(let St=0;St<Q.length;St++){const oe=Q[St].image[Z].image;D?rt&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,St+1,0,0,oe.width,oe.height,At,lt,oe.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,St+1,Ht,oe.width,oe.height,0,At,lt,oe.data)}}else{D?rt&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,At,lt,ut[Z]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,Ht,At,lt,ut[Z]);for(let St=0;St<Q.length;St++){const zt=Q[St];D?rt&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,St+1,0,0,At,lt,zt.image[Z]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,St+1,Ht,At,lt,zt.image[Z])}}}m(_)&&h(i.TEXTURE_CUBE_MAP),X.__version=J.version,_.onUpdate&&_.onUpdate(_)}y.__version=_.version}function dt(y,_,O,q,J,X){const wt=r.convert(O.format,O.colorSpace),it=r.convert(O.type),bt=b(O.internalFormat,wt,it,O.colorSpace),Tt=n.get(_),et=n.get(O);if(et.__renderTarget=_,!Tt.__hasExternalTextures){const ut=Math.max(1,_.width>>X),Nt=Math.max(1,_.height>>X);J===i.TEXTURE_3D||J===i.TEXTURE_2D_ARRAY?e.texImage3D(J,X,bt,ut,Nt,_.depth,0,wt,it,null):e.texImage2D(J,X,bt,ut,Nt,0,wt,it,null)}e.bindFramebuffer(i.FRAMEBUFFER,y),_t(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,q,J,et.__webglTexture,0,Qt(_)):(J===i.TEXTURE_2D||J>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&J<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,q,J,et.__webglTexture,X),e.bindFramebuffer(i.FRAMEBUFFER,null)}function Ut(y,_,O){if(i.bindRenderbuffer(i.RENDERBUFFER,y),_.depthBuffer){const q=_.depthTexture,J=q&&q.isDepthTexture?q.type:null,X=E(_.stencilBuffer,J),wt=_.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,it=Qt(_);_t(_)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,it,X,_.width,_.height):O?i.renderbufferStorageMultisample(i.RENDERBUFFER,it,X,_.width,_.height):i.renderbufferStorage(i.RENDERBUFFER,X,_.width,_.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,wt,i.RENDERBUFFER,y)}else{const q=_.textures;for(let J=0;J<q.length;J++){const X=q[J],wt=r.convert(X.format,X.colorSpace),it=r.convert(X.type),bt=b(X.internalFormat,wt,it,X.colorSpace),Tt=Qt(_);O&&_t(_)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Tt,bt,_.width,_.height):_t(_)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Tt,bt,_.width,_.height):i.renderbufferStorage(i.RENDERBUFFER,bt,_.width,_.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function yt(y,_){if(_&&_.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(i.FRAMEBUFFER,y),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const q=n.get(_.depthTexture);q.__renderTarget=_,(!q.__webglTexture||_.depthTexture.image.width!==_.width||_.depthTexture.image.height!==_.height)&&(_.depthTexture.image.width=_.width,_.depthTexture.image.height=_.height,_.depthTexture.needsUpdate=!0),W(_.depthTexture,0);const J=q.__webglTexture,X=Qt(_);if(_.depthTexture.format===Ji)_t(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,J,0,X):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,J,0);else if(_.depthTexture.format===Qi)_t(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,J,0,X):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,J,0);else throw new Error("Unknown depthTexture format")}function Xt(y){const _=n.get(y),O=y.isWebGLCubeRenderTarget===!0;if(_.__boundDepthTexture!==y.depthTexture){const q=y.depthTexture;if(_.__depthDisposeCallback&&_.__depthDisposeCallback(),q){const J=()=>{delete _.__boundDepthTexture,delete _.__depthDisposeCallback,q.removeEventListener("dispose",J)};q.addEventListener("dispose",J),_.__depthDisposeCallback=J}_.__boundDepthTexture=q}if(y.depthTexture&&!_.__autoAllocateDepthBuffer){if(O)throw new Error("target.depthTexture not supported in Cube render targets");const q=y.texture.mipmaps;q&&q.length>0?yt(_.__webglFramebuffer[0],y):yt(_.__webglFramebuffer,y)}else if(O){_.__webglDepthbuffer=[];for(let q=0;q<6;q++)if(e.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer[q]),_.__webglDepthbuffer[q]===void 0)_.__webglDepthbuffer[q]=i.createRenderbuffer(),Ut(_.__webglDepthbuffer[q],y,!1);else{const J=y.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,X=_.__webglDepthbuffer[q];i.bindRenderbuffer(i.RENDERBUFFER,X),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,X)}}else{const q=y.texture.mipmaps;if(q&&q.length>0?e.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer[0]):e.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer===void 0)_.__webglDepthbuffer=i.createRenderbuffer(),Ut(_.__webglDepthbuffer,y,!1);else{const J=y.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,X=_.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,X),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,X)}}e.bindFramebuffer(i.FRAMEBUFFER,null)}function Se(y,_,O){const q=n.get(y);_!==void 0&&dt(q.__webglFramebuffer,y,y.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),O!==void 0&&Xt(y)}function A(y){const _=y.texture,O=n.get(y),q=n.get(_);y.addEventListener("dispose",C);const J=y.textures,X=y.isWebGLCubeRenderTarget===!0,wt=J.length>1;if(wt||(q.__webglTexture===void 0&&(q.__webglTexture=i.createTexture()),q.__version=_.version,a.memory.textures++),X){O.__webglFramebuffer=[];for(let it=0;it<6;it++)if(_.mipmaps&&_.mipmaps.length>0){O.__webglFramebuffer[it]=[];for(let bt=0;bt<_.mipmaps.length;bt++)O.__webglFramebuffer[it][bt]=i.createFramebuffer()}else O.__webglFramebuffer[it]=i.createFramebuffer()}else{if(_.mipmaps&&_.mipmaps.length>0){O.__webglFramebuffer=[];for(let it=0;it<_.mipmaps.length;it++)O.__webglFramebuffer[it]=i.createFramebuffer()}else O.__webglFramebuffer=i.createFramebuffer();if(wt)for(let it=0,bt=J.length;it<bt;it++){const Tt=n.get(J[it]);Tt.__webglTexture===void 0&&(Tt.__webglTexture=i.createTexture(),a.memory.textures++)}if(y.samples>0&&_t(y)===!1){O.__webglMultisampledFramebuffer=i.createFramebuffer(),O.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,O.__webglMultisampledFramebuffer);for(let it=0;it<J.length;it++){const bt=J[it];O.__webglColorRenderbuffer[it]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,O.__webglColorRenderbuffer[it]);const Tt=r.convert(bt.format,bt.colorSpace),et=r.convert(bt.type),ut=b(bt.internalFormat,Tt,et,bt.colorSpace,y.isXRRenderTarget===!0),Nt=Qt(y);i.renderbufferStorageMultisample(i.RENDERBUFFER,Nt,ut,y.width,y.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+it,i.RENDERBUFFER,O.__webglColorRenderbuffer[it])}i.bindRenderbuffer(i.RENDERBUFFER,null),y.depthBuffer&&(O.__webglDepthRenderbuffer=i.createRenderbuffer(),Ut(O.__webglDepthRenderbuffer,y,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(X){e.bindTexture(i.TEXTURE_CUBE_MAP,q.__webglTexture),Et(i.TEXTURE_CUBE_MAP,_);for(let it=0;it<6;it++)if(_.mipmaps&&_.mipmaps.length>0)for(let bt=0;bt<_.mipmaps.length;bt++)dt(O.__webglFramebuffer[it][bt],y,_,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+it,bt);else dt(O.__webglFramebuffer[it],y,_,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+it,0);m(_)&&h(i.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(wt){for(let it=0,bt=J.length;it<bt;it++){const Tt=J[it],et=n.get(Tt);let ut=i.TEXTURE_2D;(y.isWebGL3DRenderTarget||y.isWebGLArrayRenderTarget)&&(ut=y.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(ut,et.__webglTexture),Et(ut,Tt),dt(O.__webglFramebuffer,y,Tt,i.COLOR_ATTACHMENT0+it,ut,0),m(Tt)&&h(ut)}e.unbindTexture()}else{let it=i.TEXTURE_2D;if((y.isWebGL3DRenderTarget||y.isWebGLArrayRenderTarget)&&(it=y.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(it,q.__webglTexture),Et(it,_),_.mipmaps&&_.mipmaps.length>0)for(let bt=0;bt<_.mipmaps.length;bt++)dt(O.__webglFramebuffer[bt],y,_,i.COLOR_ATTACHMENT0,it,bt);else dt(O.__webglFramebuffer,y,_,i.COLOR_ATTACHMENT0,it,0);m(_)&&h(it),e.unbindTexture()}y.depthBuffer&&Xt(y)}function Ct(y){const _=y.textures;for(let O=0,q=_.length;O<q;O++){const J=_[O];if(m(J)){const X=T(y),wt=n.get(J).__webglTexture;e.bindTexture(X,wt),h(X),e.unbindTexture()}}}const gt=[],pt=[];function ft(y){if(y.samples>0){if(_t(y)===!1){const _=y.textures,O=y.width,q=y.height;let J=i.COLOR_BUFFER_BIT;const X=y.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,wt=n.get(y),it=_.length>1;if(it)for(let Tt=0;Tt<_.length;Tt++)e.bindFramebuffer(i.FRAMEBUFFER,wt.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Tt,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,wt.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Tt,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,wt.__webglMultisampledFramebuffer);const bt=y.texture.mipmaps;bt&&bt.length>0?e.bindFramebuffer(i.DRAW_FRAMEBUFFER,wt.__webglFramebuffer[0]):e.bindFramebuffer(i.DRAW_FRAMEBUFFER,wt.__webglFramebuffer);for(let Tt=0;Tt<_.length;Tt++){if(y.resolveDepthBuffer&&(y.depthBuffer&&(J|=i.DEPTH_BUFFER_BIT),y.stencilBuffer&&y.resolveStencilBuffer&&(J|=i.STENCIL_BUFFER_BIT)),it){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,wt.__webglColorRenderbuffer[Tt]);const et=n.get(_[Tt]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,et,0)}i.blitFramebuffer(0,0,O,q,0,0,O,q,J,i.NEAREST),c===!0&&(gt.length=0,pt.length=0,gt.push(i.COLOR_ATTACHMENT0+Tt),y.depthBuffer&&y.resolveDepthBuffer===!1&&(gt.push(X),pt.push(X),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,pt)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,gt))}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),it)for(let Tt=0;Tt<_.length;Tt++){e.bindFramebuffer(i.FRAMEBUFFER,wt.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Tt,i.RENDERBUFFER,wt.__webglColorRenderbuffer[Tt]);const et=n.get(_[Tt]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,wt.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Tt,i.TEXTURE_2D,et,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,wt.__webglMultisampledFramebuffer)}else if(y.depthBuffer&&y.resolveDepthBuffer===!1&&c){const _=y.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[_])}}}function Qt(y){return Math.min(s.maxSamples,y.samples)}function _t(y){const _=n.get(y);return y.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function Bt(y){const _=a.render.frame;u.get(y)!==_&&(u.set(y,_),y.update())}function pe(y,_){const O=y.colorSpace,q=y.format,J=y.type;return y.isCompressedTexture===!0||y.isVideoTexture===!0||O!==Pi&&O!==Cn&&(Jt.getTransfer(O)===se?(q!==Je||J!==an)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",O)),_}function kt(y){return typeof HTMLImageElement<"u"&&y instanceof HTMLImageElement?(l.width=y.naturalWidth||y.width,l.height=y.naturalHeight||y.height):typeof VideoFrame<"u"&&y instanceof VideoFrame?(l.width=y.displayWidth,l.height=y.displayHeight):(l.width=y.width,l.height=y.height),l}this.allocateTextureUnit=k,this.resetTextureUnits=F,this.setTexture2D=W,this.setTexture2DArray=Y,this.setTexture3D=K,this.setTextureCube=H,this.rebindTextures=Se,this.setupRenderTarget=A,this.updateRenderTargetMipmap=Ct,this.updateMultisampleRenderTarget=ft,this.setupDepthRenderbuffer=Xt,this.setupFrameBufferTexture=dt,this.useMultisampledRTT=_t}function og(i,t){function e(n,s=Cn){let r;const a=Jt.getTransfer(s);if(n===an)return i.UNSIGNED_BYTE;if(n===$a)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Za)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Yl)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===ql)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Wl)return i.BYTE;if(n===Xl)return i.SHORT;if(n===Zi)return i.UNSIGNED_SHORT;if(n===ja)return i.INT;if(n===$n)return i.UNSIGNED_INT;if(n===vn)return i.FLOAT;if(n===rs)return i.HALF_FLOAT;if(n===jl)return i.ALPHA;if(n===$l)return i.RGB;if(n===Je)return i.RGBA;if(n===Ji)return i.DEPTH_COMPONENT;if(n===Qi)return i.DEPTH_STENCIL;if(n===Zl)return i.RED;if(n===Ka)return i.RED_INTEGER;if(n===Kl)return i.RG;if(n===Ja)return i.RG_INTEGER;if(n===Qa)return i.RGBA_INTEGER;if(n===Vs||n===Gs||n===Ws||n===Xs)if(a===se)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Vs)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Gs)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Ws)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Xs)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Vs)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Gs)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Ws)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Xs)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===oa||n===la||n===ca||n===ha)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===oa)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===la)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===ca)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===ha)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===ua||n===da||n===fa)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===ua||n===da)return a===se?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===fa)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===pa||n===ma||n===ga||n===_a||n===va||n===xa||n===Ma||n===Sa||n===Ea||n===ya||n===ba||n===Ta||n===Aa||n===wa)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===pa)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===ma)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===ga)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===_a)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===va)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===xa)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Ma)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Sa)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Ea)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===ya)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===ba)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Ta)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Aa)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===wa)return a===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Ra||n===Ca||n===Pa)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===Ra)return a===se?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Ca)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Pa)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Da||n===La||n===Ia||n===Ua)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===Da)return r.COMPRESSED_RED_RGTC1_EXT;if(n===La)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Ia)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Ua)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Ki?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:e}}const lg=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,cg=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class hg{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){const n=new uc(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,n=new In({vertexShader:lg,fragmentShader:cg,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new Xe(new sr(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class ug extends Jn{constructor(t,e){super();const n=this;let s=null,r=1,a=null,o="local-floor",c=1,l=null,u=null,f=null,d=null,p=null,g=null;const v=typeof XRWebGLBinding<"u",m=new hg,h={},T=e.getContextAttributes();let b=null,E=null;const R=[],w=[],C=new Ot;let L=null;const S=new Ge;S.viewport=new fe;const M=new Ge;M.viewport=new fe;const P=[S,M],F=new Ru;let k=null,j=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(G){let $=R[G];return $===void 0&&($=new Cr,R[G]=$),$.getTargetRaySpace()},this.getControllerGrip=function(G){let $=R[G];return $===void 0&&($=new Cr,R[G]=$),$.getGripSpace()},this.getHand=function(G){let $=R[G];return $===void 0&&($=new Cr,R[G]=$),$.getHandSpace()};function W(G){const $=w.indexOf(G.inputSource);if($===-1)return;const dt=R[$];dt!==void 0&&(dt.update(G.inputSource,G.frame,l||a),dt.dispatchEvent({type:G.type,data:G.inputSource}))}function Y(){s.removeEventListener("select",W),s.removeEventListener("selectstart",W),s.removeEventListener("selectend",W),s.removeEventListener("squeeze",W),s.removeEventListener("squeezestart",W),s.removeEventListener("squeezeend",W),s.removeEventListener("end",Y),s.removeEventListener("inputsourceschange",K);for(let G=0;G<R.length;G++){const $=w[G];$!==null&&(w[G]=null,R[G].disconnect($))}k=null,j=null,m.reset();for(const G in h)delete h[G];t.setRenderTarget(b),p=null,d=null,f=null,s=null,E=null,Dt.stop(),n.isPresenting=!1,t.setPixelRatio(L),t.setSize(C.width,C.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(G){r=G,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(G){o=G,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(G){l=G},this.getBaseLayer=function(){return d!==null?d:p},this.getBinding=function(){return f===null&&v&&(f=new XRWebGLBinding(s,e)),f},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(G){if(s=G,s!==null){if(b=t.getRenderTarget(),s.addEventListener("select",W),s.addEventListener("selectstart",W),s.addEventListener("selectend",W),s.addEventListener("squeeze",W),s.addEventListener("squeezestart",W),s.addEventListener("squeezeend",W),s.addEventListener("end",Y),s.addEventListener("inputsourceschange",K),T.xrCompatible!==!0&&await e.makeXRCompatible(),L=t.getPixelRatio(),t.getSize(C),v&&"createProjectionLayer"in XRWebGLBinding.prototype){let dt=null,Ut=null,yt=null;T.depth&&(yt=T.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,dt=T.stencil?Qi:Ji,Ut=T.stencil?Ki:$n);const Xt={colorFormat:e.RGBA8,depthFormat:yt,scaleFactor:r};f=this.getBinding(),d=f.createProjectionLayer(Xt),s.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),E=new Kn(d.textureWidth,d.textureHeight,{format:Je,type:an,depthTexture:new hc(d.textureWidth,d.textureHeight,Ut,void 0,void 0,void 0,void 0,void 0,void 0,dt),stencilBuffer:T.stencil,colorSpace:t.outputColorSpace,samples:T.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1})}else{const dt={antialias:T.antialias,alpha:!0,depth:T.depth,stencil:T.stencil,framebufferScaleFactor:r};p=new XRWebGLLayer(s,e,dt),s.updateRenderState({baseLayer:p}),t.setPixelRatio(1),t.setSize(p.framebufferWidth,p.framebufferHeight,!1),E=new Kn(p.framebufferWidth,p.framebufferHeight,{format:Je,type:an,colorSpace:t.outputColorSpace,stencilBuffer:T.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1})}E.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await s.requestReferenceSpace(o),Dt.setContext(s),Dt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function K(G){for(let $=0;$<G.removed.length;$++){const dt=G.removed[$],Ut=w.indexOf(dt);Ut>=0&&(w[Ut]=null,R[Ut].disconnect(dt))}for(let $=0;$<G.added.length;$++){const dt=G.added[$];let Ut=w.indexOf(dt);if(Ut===-1){for(let Xt=0;Xt<R.length;Xt++)if(Xt>=w.length){w.push(dt),Ut=Xt;break}else if(w[Xt]===null){w[Xt]=dt,Ut=Xt;break}if(Ut===-1)break}const yt=R[Ut];yt&&yt.connect(dt)}}const H=new I,st=new I;function V(G,$,dt){H.setFromMatrixPosition($.matrixWorld),st.setFromMatrixPosition(dt.matrixWorld);const Ut=H.distanceTo(st),yt=$.projectionMatrix.elements,Xt=dt.projectionMatrix.elements,Se=yt[14]/(yt[10]-1),A=yt[14]/(yt[10]+1),Ct=(yt[9]+1)/yt[5],gt=(yt[9]-1)/yt[5],pt=(yt[8]-1)/yt[0],ft=(Xt[8]+1)/Xt[0],Qt=Se*pt,_t=Se*ft,Bt=Ut/(-pt+ft),pe=Bt*-pt;if($.matrixWorld.decompose(G.position,G.quaternion,G.scale),G.translateX(pe),G.translateZ(Bt),G.matrixWorld.compose(G.position,G.quaternion,G.scale),G.matrixWorldInverse.copy(G.matrixWorld).invert(),yt[10]===-1)G.projectionMatrix.copy($.projectionMatrix),G.projectionMatrixInverse.copy($.projectionMatrixInverse);else{const kt=Se+Bt,y=A+Bt,_=Qt-pe,O=_t+(Ut-pe),q=Ct*A/y*kt,J=gt*A/y*kt;G.projectionMatrix.makePerspective(_,O,q,J,kt,y),G.projectionMatrixInverse.copy(G.projectionMatrix).invert()}}function at(G,$){$===null?G.matrixWorld.copy(G.matrix):G.matrixWorld.multiplyMatrices($.matrixWorld,G.matrix),G.matrixWorldInverse.copy(G.matrixWorld).invert()}this.updateCamera=function(G){if(s===null)return;let $=G.near,dt=G.far;m.texture!==null&&(m.depthNear>0&&($=m.depthNear),m.depthFar>0&&(dt=m.depthFar)),F.near=M.near=S.near=$,F.far=M.far=S.far=dt,(k!==F.near||j!==F.far)&&(s.updateRenderState({depthNear:F.near,depthFar:F.far}),k=F.near,j=F.far),F.layers.mask=G.layers.mask|6,S.layers.mask=F.layers.mask&3,M.layers.mask=F.layers.mask&5;const Ut=G.parent,yt=F.cameras;at(F,Ut);for(let Xt=0;Xt<yt.length;Xt++)at(yt[Xt],Ut);yt.length===2?V(F,S,M):F.projectionMatrix.copy(S.projectionMatrix),Et(G,F,Ut)};function Et(G,$,dt){dt===null?G.matrix.copy($.matrixWorld):(G.matrix.copy(dt.matrixWorld),G.matrix.invert(),G.matrix.multiply($.matrixWorld)),G.matrix.decompose(G.position,G.quaternion,G.scale),G.updateMatrixWorld(!0),G.projectionMatrix.copy($.projectionMatrix),G.projectionMatrixInverse.copy($.projectionMatrixInverse),G.isPerspectiveCamera&&(G.fov=ts*2*Math.atan(1/G.projectionMatrix.elements[5]),G.zoom=1)}this.getCamera=function(){return F},this.getFoveation=function(){if(!(d===null&&p===null))return c},this.setFoveation=function(G){c=G,d!==null&&(d.fixedFoveation=G),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=G)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(F)},this.getCameraTexture=function(G){return h[G]};let ht=null;function It(G,$){if(u=$.getViewerPose(l||a),g=$,u!==null){const dt=u.views;p!==null&&(t.setRenderTargetFramebuffer(E,p.framebuffer),t.setRenderTarget(E));let Ut=!1;dt.length!==F.cameras.length&&(F.cameras.length=0,Ut=!0);for(let A=0;A<dt.length;A++){const Ct=dt[A];let gt=null;if(p!==null)gt=p.getViewport(Ct);else{const ft=f.getViewSubImage(d,Ct);gt=ft.viewport,A===0&&(t.setRenderTargetTextures(E,ft.colorTexture,ft.depthStencilTexture),t.setRenderTarget(E))}let pt=P[A];pt===void 0&&(pt=new Ge,pt.layers.enable(A),pt.viewport=new fe,P[A]=pt),pt.matrix.fromArray(Ct.transform.matrix),pt.matrix.decompose(pt.position,pt.quaternion,pt.scale),pt.projectionMatrix.fromArray(Ct.projectionMatrix),pt.projectionMatrixInverse.copy(pt.projectionMatrix).invert(),pt.viewport.set(gt.x,gt.y,gt.width,gt.height),A===0&&(F.matrix.copy(pt.matrix),F.matrix.decompose(F.position,F.quaternion,F.scale)),Ut===!0&&F.cameras.push(pt)}const yt=s.enabledFeatures;if(yt&&yt.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&v){f=n.getBinding();const A=f.getDepthInformation(dt[0]);A&&A.isValid&&A.texture&&m.init(A,s.renderState)}if(yt&&yt.includes("camera-access")&&v){t.state.unbindTexture(),f=n.getBinding();for(let A=0;A<dt.length;A++){const Ct=dt[A].camera;if(Ct){let gt=h[Ct];gt||(gt=new uc,h[Ct]=gt);const pt=f.getCameraImage(Ct);gt.sourceTexture=pt}}}}for(let dt=0;dt<R.length;dt++){const Ut=w[dt],yt=R[dt];Ut!==null&&yt!==void 0&&yt.update(Ut,$,l||a)}ht&&ht(G,$),$.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:$}),g=null}const Dt=new mc;Dt.setAnimationLoop(It),this.setAnimationLoop=function(G){ht=G},this.dispose=function(){}}}const Vn=new on,dg=new ce;function fg(i,t){function e(m,h){m.matrixAutoUpdate===!0&&m.updateMatrix(),h.value.copy(m.matrix)}function n(m,h){h.color.getRGB(m.fogColor.value,ac(i)),h.isFog?(m.fogNear.value=h.near,m.fogFar.value=h.far):h.isFogExp2&&(m.fogDensity.value=h.density)}function s(m,h,T,b,E){h.isMeshBasicMaterial||h.isMeshLambertMaterial?r(m,h):h.isMeshToonMaterial?(r(m,h),f(m,h)):h.isMeshPhongMaterial?(r(m,h),u(m,h)):h.isMeshStandardMaterial?(r(m,h),d(m,h),h.isMeshPhysicalMaterial&&p(m,h,E)):h.isMeshMatcapMaterial?(r(m,h),g(m,h)):h.isMeshDepthMaterial?r(m,h):h.isMeshDistanceMaterial?(r(m,h),v(m,h)):h.isMeshNormalMaterial?r(m,h):h.isLineBasicMaterial?(a(m,h),h.isLineDashedMaterial&&o(m,h)):h.isPointsMaterial?c(m,h,T,b):h.isSpriteMaterial?l(m,h):h.isShadowMaterial?(m.color.value.copy(h.color),m.opacity.value=h.opacity):h.isShaderMaterial&&(h.uniformsNeedUpdate=!1)}function r(m,h){m.opacity.value=h.opacity,h.color&&m.diffuse.value.copy(h.color),h.emissive&&m.emissive.value.copy(h.emissive).multiplyScalar(h.emissiveIntensity),h.map&&(m.map.value=h.map,e(h.map,m.mapTransform)),h.alphaMap&&(m.alphaMap.value=h.alphaMap,e(h.alphaMap,m.alphaMapTransform)),h.bumpMap&&(m.bumpMap.value=h.bumpMap,e(h.bumpMap,m.bumpMapTransform),m.bumpScale.value=h.bumpScale,h.side===Ie&&(m.bumpScale.value*=-1)),h.normalMap&&(m.normalMap.value=h.normalMap,e(h.normalMap,m.normalMapTransform),m.normalScale.value.copy(h.normalScale),h.side===Ie&&m.normalScale.value.negate()),h.displacementMap&&(m.displacementMap.value=h.displacementMap,e(h.displacementMap,m.displacementMapTransform),m.displacementScale.value=h.displacementScale,m.displacementBias.value=h.displacementBias),h.emissiveMap&&(m.emissiveMap.value=h.emissiveMap,e(h.emissiveMap,m.emissiveMapTransform)),h.specularMap&&(m.specularMap.value=h.specularMap,e(h.specularMap,m.specularMapTransform)),h.alphaTest>0&&(m.alphaTest.value=h.alphaTest);const T=t.get(h),b=T.envMap,E=T.envMapRotation;b&&(m.envMap.value=b,Vn.copy(E),Vn.x*=-1,Vn.y*=-1,Vn.z*=-1,b.isCubeTexture&&b.isRenderTargetTexture===!1&&(Vn.y*=-1,Vn.z*=-1),m.envMapRotation.value.setFromMatrix4(dg.makeRotationFromEuler(Vn)),m.flipEnvMap.value=b.isCubeTexture&&b.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=h.reflectivity,m.ior.value=h.ior,m.refractionRatio.value=h.refractionRatio),h.lightMap&&(m.lightMap.value=h.lightMap,m.lightMapIntensity.value=h.lightMapIntensity,e(h.lightMap,m.lightMapTransform)),h.aoMap&&(m.aoMap.value=h.aoMap,m.aoMapIntensity.value=h.aoMapIntensity,e(h.aoMap,m.aoMapTransform))}function a(m,h){m.diffuse.value.copy(h.color),m.opacity.value=h.opacity,h.map&&(m.map.value=h.map,e(h.map,m.mapTransform))}function o(m,h){m.dashSize.value=h.dashSize,m.totalSize.value=h.dashSize+h.gapSize,m.scale.value=h.scale}function c(m,h,T,b){m.diffuse.value.copy(h.color),m.opacity.value=h.opacity,m.size.value=h.size*T,m.scale.value=b*.5,h.map&&(m.map.value=h.map,e(h.map,m.uvTransform)),h.alphaMap&&(m.alphaMap.value=h.alphaMap,e(h.alphaMap,m.alphaMapTransform)),h.alphaTest>0&&(m.alphaTest.value=h.alphaTest)}function l(m,h){m.diffuse.value.copy(h.color),m.opacity.value=h.opacity,m.rotation.value=h.rotation,h.map&&(m.map.value=h.map,e(h.map,m.mapTransform)),h.alphaMap&&(m.alphaMap.value=h.alphaMap,e(h.alphaMap,m.alphaMapTransform)),h.alphaTest>0&&(m.alphaTest.value=h.alphaTest)}function u(m,h){m.specular.value.copy(h.specular),m.shininess.value=Math.max(h.shininess,1e-4)}function f(m,h){h.gradientMap&&(m.gradientMap.value=h.gradientMap)}function d(m,h){m.metalness.value=h.metalness,h.metalnessMap&&(m.metalnessMap.value=h.metalnessMap,e(h.metalnessMap,m.metalnessMapTransform)),m.roughness.value=h.roughness,h.roughnessMap&&(m.roughnessMap.value=h.roughnessMap,e(h.roughnessMap,m.roughnessMapTransform)),h.envMap&&(m.envMapIntensity.value=h.envMapIntensity)}function p(m,h,T){m.ior.value=h.ior,h.sheen>0&&(m.sheenColor.value.copy(h.sheenColor).multiplyScalar(h.sheen),m.sheenRoughness.value=h.sheenRoughness,h.sheenColorMap&&(m.sheenColorMap.value=h.sheenColorMap,e(h.sheenColorMap,m.sheenColorMapTransform)),h.sheenRoughnessMap&&(m.sheenRoughnessMap.value=h.sheenRoughnessMap,e(h.sheenRoughnessMap,m.sheenRoughnessMapTransform))),h.clearcoat>0&&(m.clearcoat.value=h.clearcoat,m.clearcoatRoughness.value=h.clearcoatRoughness,h.clearcoatMap&&(m.clearcoatMap.value=h.clearcoatMap,e(h.clearcoatMap,m.clearcoatMapTransform)),h.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=h.clearcoatRoughnessMap,e(h.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),h.clearcoatNormalMap&&(m.clearcoatNormalMap.value=h.clearcoatNormalMap,e(h.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(h.clearcoatNormalScale),h.side===Ie&&m.clearcoatNormalScale.value.negate())),h.dispersion>0&&(m.dispersion.value=h.dispersion),h.iridescence>0&&(m.iridescence.value=h.iridescence,m.iridescenceIOR.value=h.iridescenceIOR,m.iridescenceThicknessMinimum.value=h.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=h.iridescenceThicknessRange[1],h.iridescenceMap&&(m.iridescenceMap.value=h.iridescenceMap,e(h.iridescenceMap,m.iridescenceMapTransform)),h.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=h.iridescenceThicknessMap,e(h.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),h.transmission>0&&(m.transmission.value=h.transmission,m.transmissionSamplerMap.value=T.texture,m.transmissionSamplerSize.value.set(T.width,T.height),h.transmissionMap&&(m.transmissionMap.value=h.transmissionMap,e(h.transmissionMap,m.transmissionMapTransform)),m.thickness.value=h.thickness,h.thicknessMap&&(m.thicknessMap.value=h.thicknessMap,e(h.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=h.attenuationDistance,m.attenuationColor.value.copy(h.attenuationColor)),h.anisotropy>0&&(m.anisotropyVector.value.set(h.anisotropy*Math.cos(h.anisotropyRotation),h.anisotropy*Math.sin(h.anisotropyRotation)),h.anisotropyMap&&(m.anisotropyMap.value=h.anisotropyMap,e(h.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=h.specularIntensity,m.specularColor.value.copy(h.specularColor),h.specularColorMap&&(m.specularColorMap.value=h.specularColorMap,e(h.specularColorMap,m.specularColorMapTransform)),h.specularIntensityMap&&(m.specularIntensityMap.value=h.specularIntensityMap,e(h.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,h){h.matcap&&(m.matcap.value=h.matcap)}function v(m,h){const T=t.get(h).light;m.referencePosition.value.setFromMatrixPosition(T.matrixWorld),m.nearDistance.value=T.shadow.camera.near,m.farDistance.value=T.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function pg(i,t,e,n){let s={},r={},a=[];const o=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function c(T,b){const E=b.program;n.uniformBlockBinding(T,E)}function l(T,b){let E=s[T.id];E===void 0&&(g(T),E=u(T),s[T.id]=E,T.addEventListener("dispose",m));const R=b.program;n.updateUBOMapping(T,R);const w=t.render.frame;r[T.id]!==w&&(d(T),r[T.id]=w)}function u(T){const b=f();T.__bindingPointIndex=b;const E=i.createBuffer(),R=T.__size,w=T.usage;return i.bindBuffer(i.UNIFORM_BUFFER,E),i.bufferData(i.UNIFORM_BUFFER,R,w),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,b,E),E}function f(){for(let T=0;T<o;T++)if(a.indexOf(T)===-1)return a.push(T),T;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(T){const b=s[T.id],E=T.uniforms,R=T.__cache;i.bindBuffer(i.UNIFORM_BUFFER,b);for(let w=0,C=E.length;w<C;w++){const L=Array.isArray(E[w])?E[w]:[E[w]];for(let S=0,M=L.length;S<M;S++){const P=L[S];if(p(P,w,S,R)===!0){const F=P.__offset,k=Array.isArray(P.value)?P.value:[P.value];let j=0;for(let W=0;W<k.length;W++){const Y=k[W],K=v(Y);typeof Y=="number"||typeof Y=="boolean"?(P.__data[0]=Y,i.bufferSubData(i.UNIFORM_BUFFER,F+j,P.__data)):Y.isMatrix3?(P.__data[0]=Y.elements[0],P.__data[1]=Y.elements[1],P.__data[2]=Y.elements[2],P.__data[3]=0,P.__data[4]=Y.elements[3],P.__data[5]=Y.elements[4],P.__data[6]=Y.elements[5],P.__data[7]=0,P.__data[8]=Y.elements[6],P.__data[9]=Y.elements[7],P.__data[10]=Y.elements[8],P.__data[11]=0):(Y.toArray(P.__data,j),j+=K.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,F,P.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function p(T,b,E,R){const w=T.value,C=b+"_"+E;if(R[C]===void 0)return typeof w=="number"||typeof w=="boolean"?R[C]=w:R[C]=w.clone(),!0;{const L=R[C];if(typeof w=="number"||typeof w=="boolean"){if(L!==w)return R[C]=w,!0}else if(L.equals(w)===!1)return L.copy(w),!0}return!1}function g(T){const b=T.uniforms;let E=0;const R=16;for(let C=0,L=b.length;C<L;C++){const S=Array.isArray(b[C])?b[C]:[b[C]];for(let M=0,P=S.length;M<P;M++){const F=S[M],k=Array.isArray(F.value)?F.value:[F.value];for(let j=0,W=k.length;j<W;j++){const Y=k[j],K=v(Y),H=E%R,st=H%K.boundary,V=H+st;E+=st,V!==0&&R-V<K.storage&&(E+=R-V),F.__data=new Float32Array(K.storage/Float32Array.BYTES_PER_ELEMENT),F.__offset=E,E+=K.storage}}}const w=E%R;return w>0&&(E+=R-w),T.__size=E,T.__cache={},this}function v(T){const b={boundary:0,storage:0};return typeof T=="number"||typeof T=="boolean"?(b.boundary=4,b.storage=4):T.isVector2?(b.boundary=8,b.storage=8):T.isVector3||T.isColor?(b.boundary=16,b.storage=12):T.isVector4?(b.boundary=16,b.storage=16):T.isMatrix3?(b.boundary=48,b.storage=48):T.isMatrix4?(b.boundary=64,b.storage=64):T.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",T),b}function m(T){const b=T.target;b.removeEventListener("dispose",m);const E=a.indexOf(b.__bindingPointIndex);a.splice(E,1),i.deleteBuffer(s[b.id]),delete s[b.id],delete r[b.id]}function h(){for(const T in s)i.deleteBuffer(s[T]);a=[],s={},r={}}return{bind:c,update:l,dispose:h}}class mg{constructor(t={}){const{canvas:e=Gh(),context:n=null,depth:s=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:f=!1,reversedDepthBuffer:d=!1}=t;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=n.getContextAttributes().alpha}else p=a;const g=new Uint32Array(4),v=new Int32Array(4);let m=null,h=null;const T=[],b=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Dn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const E=this;let R=!1;this._outputColorSpace=Ve;let w=0,C=0,L=null,S=-1,M=null;const P=new fe,F=new fe;let k=null;const j=new jt(0);let W=0,Y=e.width,K=e.height,H=1,st=null,V=null;const at=new fe(0,0,Y,K),Et=new fe(0,0,Y,K);let ht=!1;const It=new io;let Dt=!1,G=!1;const $=new ce,dt=new I,Ut=new fe,yt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Xt=!1;function Se(){return L===null?H:1}let A=n;function Ct(x,U){return e.getContext(x,U)}try{const x={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:u,failIfMajorPerformanceCaveat:f};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${qa}`),e.addEventListener("webglcontextlost",rt,!1),e.addEventListener("webglcontextrestored",vt,!1),e.addEventListener("webglcontextcreationerror",Q,!1),A===null){const U="webgl2";if(A=Ct(U,x),A===null)throw Ct(U)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(x){throw console.error("THREE.WebGLRenderer: "+x.message),x}let gt,pt,ft,Qt,_t,Bt,pe,kt,y,_,O,q,J,X,wt,it,bt,Tt,et,ut,Nt,At,lt,Ht;function D(){gt=new Tp(A),gt.init(),At=new og(A,gt),pt=new vp(A,gt,t,At),ft=new rg(A,gt),pt.reversedDepthBuffer&&d&&ft.buffers.depth.setReversed(!0),Qt=new Rp(A),_t=new Ym,Bt=new ag(A,gt,ft,_t,pt,At,Qt),pe=new Mp(E),kt=new bp(E),y=new Iu(A),lt=new gp(A,y),_=new Ap(A,y,Qt,lt),O=new Pp(A,_,y,Qt),et=new Cp(A,pt,Bt),it=new xp(_t),q=new Xm(E,pe,kt,gt,pt,lt,it),J=new fg(E,_t),X=new jm,wt=new tg(gt),Tt=new mp(E,pe,kt,ft,O,p,c),bt=new ig(E,O,pt),Ht=new pg(A,Qt,pt,ft),ut=new _p(A,gt,Qt),Nt=new wp(A,gt,Qt),Qt.programs=q.programs,E.capabilities=pt,E.extensions=gt,E.properties=_t,E.renderLists=X,E.shadowMap=bt,E.state=ft,E.info=Qt}D();const nt=new ug(E,A);this.xr=nt,this.getContext=function(){return A},this.getContextAttributes=function(){return A.getContextAttributes()},this.forceContextLoss=function(){const x=gt.get("WEBGL_lose_context");x&&x.loseContext()},this.forceContextRestore=function(){const x=gt.get("WEBGL_lose_context");x&&x.restoreContext()},this.getPixelRatio=function(){return H},this.setPixelRatio=function(x){x!==void 0&&(H=x,this.setSize(Y,K,!1))},this.getSize=function(x){return x.set(Y,K)},this.setSize=function(x,U,B=!0){if(nt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}Y=x,K=U,e.width=Math.floor(x*H),e.height=Math.floor(U*H),B===!0&&(e.style.width=x+"px",e.style.height=U+"px"),this.setViewport(0,0,x,U)},this.getDrawingBufferSize=function(x){return x.set(Y*H,K*H).floor()},this.setDrawingBufferSize=function(x,U,B){Y=x,K=U,H=B,e.width=Math.floor(x*B),e.height=Math.floor(U*B),this.setViewport(0,0,x,U)},this.getCurrentViewport=function(x){return x.copy(P)},this.getViewport=function(x){return x.copy(at)},this.setViewport=function(x,U,B,z){x.isVector4?at.set(x.x,x.y,x.z,x.w):at.set(x,U,B,z),ft.viewport(P.copy(at).multiplyScalar(H).round())},this.getScissor=function(x){return x.copy(Et)},this.setScissor=function(x,U,B,z){x.isVector4?Et.set(x.x,x.y,x.z,x.w):Et.set(x,U,B,z),ft.scissor(F.copy(Et).multiplyScalar(H).round())},this.getScissorTest=function(){return ht},this.setScissorTest=function(x){ft.setScissorTest(ht=x)},this.setOpaqueSort=function(x){st=x},this.setTransparentSort=function(x){V=x},this.getClearColor=function(x){return x.copy(Tt.getClearColor())},this.setClearColor=function(){Tt.setClearColor(...arguments)},this.getClearAlpha=function(){return Tt.getClearAlpha()},this.setClearAlpha=function(){Tt.setClearAlpha(...arguments)},this.clear=function(x=!0,U=!0,B=!0){let z=0;if(x){let N=!1;if(L!==null){const tt=L.texture.format;N=tt===Qa||tt===Ja||tt===Ka}if(N){const tt=L.texture.type,ct=tt===an||tt===$n||tt===Zi||tt===Ki||tt===$a||tt===Za,Mt=Tt.getClearColor(),mt=Tt.getClearAlpha(),Lt=Mt.r,Ft=Mt.g,Rt=Mt.b;ct?(g[0]=Lt,g[1]=Ft,g[2]=Rt,g[3]=mt,A.clearBufferuiv(A.COLOR,0,g)):(v[0]=Lt,v[1]=Ft,v[2]=Rt,v[3]=mt,A.clearBufferiv(A.COLOR,0,v))}else z|=A.COLOR_BUFFER_BIT}U&&(z|=A.DEPTH_BUFFER_BIT),B&&(z|=A.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),A.clear(z)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",rt,!1),e.removeEventListener("webglcontextrestored",vt,!1),e.removeEventListener("webglcontextcreationerror",Q,!1),Tt.dispose(),X.dispose(),wt.dispose(),_t.dispose(),pe.dispose(),kt.dispose(),O.dispose(),lt.dispose(),Ht.dispose(),q.dispose(),nt.dispose(),nt.removeEventListener("sessionstart",tn),nt.removeEventListener("sessionend",uo),Nn.stop()};function rt(x){x.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),R=!0}function vt(){console.log("THREE.WebGLRenderer: Context Restored."),R=!1;const x=Qt.autoReset,U=bt.enabled,B=bt.autoUpdate,z=bt.needsUpdate,N=bt.type;D(),Qt.autoReset=x,bt.enabled=U,bt.autoUpdate=B,bt.needsUpdate=z,bt.type=N}function Q(x){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",x.statusMessage)}function Z(x){const U=x.target;U.removeEventListener("dispose",Z),St(U)}function St(x){zt(x),_t.remove(x)}function zt(x){const U=_t.get(x).programs;U!==void 0&&(U.forEach(function(B){q.releaseProgram(B)}),x.isShaderMaterial&&q.releaseShaderCache(x))}this.renderBufferDirect=function(x,U,B,z,N,tt){U===null&&(U=yt);const ct=N.isMesh&&N.matrixWorld.determinant()<0,Mt=Uc(x,U,B,z,N);ft.setMaterial(z,ct);let mt=B.index,Lt=1;if(z.wireframe===!0){if(mt=_.getWireframeAttribute(B),mt===void 0)return;Lt=2}const Ft=B.drawRange,Rt=B.attributes.position;let Zt=Ft.start*Lt,ne=(Ft.start+Ft.count)*Lt;tt!==null&&(Zt=Math.max(Zt,tt.start*Lt),ne=Math.min(ne,(tt.start+tt.count)*Lt)),mt!==null?(Zt=Math.max(Zt,0),ne=Math.min(ne,mt.count)):Rt!=null&&(Zt=Math.max(Zt,0),ne=Math.min(ne,Rt.count));const de=ne-Zt;if(de<0||de===1/0)return;lt.setup(N,z,Mt,B,mt);let le,ae=ut;if(mt!==null&&(le=y.get(mt),ae=Nt,ae.setIndex(le)),N.isMesh)z.wireframe===!0?(ft.setLineWidth(z.wireframeLinewidth*Se()),ae.setMode(A.LINES)):ae.setMode(A.TRIANGLES);else if(N.isLine){let Pt=z.linewidth;Pt===void 0&&(Pt=1),ft.setLineWidth(Pt*Se()),N.isLineSegments?ae.setMode(A.LINES):N.isLineLoop?ae.setMode(A.LINE_LOOP):ae.setMode(A.LINE_STRIP)}else N.isPoints?ae.setMode(A.POINTS):N.isSprite&&ae.setMode(A.TRIANGLES);if(N.isBatchedMesh)if(N._multiDrawInstances!==null)es("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),ae.renderMultiDrawInstances(N._multiDrawStarts,N._multiDrawCounts,N._multiDrawCount,N._multiDrawInstances);else if(gt.get("WEBGL_multi_draw"))ae.renderMultiDraw(N._multiDrawStarts,N._multiDrawCounts,N._multiDrawCount);else{const Pt=N._multiDrawStarts,he=N._multiDrawCounts,Kt=N._multiDrawCount,Ne=mt?y.get(mt).bytesPerElement:1,ni=_t.get(z).currentProgram.getUniforms();for(let Fe=0;Fe<Kt;Fe++)ni.setValue(A,"_gl_DrawID",Fe),ae.render(Pt[Fe]/Ne,he[Fe])}else if(N.isInstancedMesh)ae.renderInstances(Zt,de,N.count);else if(B.isInstancedBufferGeometry){const Pt=B._maxInstanceCount!==void 0?B._maxInstanceCount:1/0,he=Math.min(B.instanceCount,Pt);ae.renderInstances(Zt,de,he)}else ae.render(Zt,de)};function oe(x,U,B){x.transparent===!0&&x.side===_n&&x.forceSinglePass===!1?(x.side=Ie,x.needsUpdate=!0,hs(x,U,B),x.side=Ln,x.needsUpdate=!0,hs(x,U,B),x.side=_n):hs(x,U,B)}this.compile=function(x,U,B=null){B===null&&(B=x),h=wt.get(B),h.init(U),b.push(h),B.traverseVisible(function(N){N.isLight&&N.layers.test(U.layers)&&(h.pushLight(N),N.castShadow&&h.pushShadow(N))}),x!==B&&x.traverseVisible(function(N){N.isLight&&N.layers.test(U.layers)&&(h.pushLight(N),N.castShadow&&h.pushShadow(N))}),h.setupLights();const z=new Set;return x.traverse(function(N){if(!(N.isMesh||N.isPoints||N.isLine||N.isSprite))return;const tt=N.material;if(tt)if(Array.isArray(tt))for(let ct=0;ct<tt.length;ct++){const Mt=tt[ct];oe(Mt,B,N),z.add(Mt)}else oe(tt,B,N),z.add(tt)}),h=b.pop(),z},this.compileAsync=function(x,U,B=null){const z=this.compile(x,U,B);return new Promise(N=>{function tt(){if(z.forEach(function(ct){_t.get(ct).currentProgram.isReady()&&z.delete(ct)}),z.size===0){N(x);return}setTimeout(tt,10)}gt.get("KHR_parallel_shader_compile")!==null?tt():setTimeout(tt,10)})};let te=null;function ln(x){te&&te(x)}function tn(){Nn.stop()}function uo(){Nn.start()}const Nn=new mc;Nn.setAnimationLoop(ln),typeof self<"u"&&Nn.setContext(self),this.setAnimationLoop=function(x){te=x,nt.setAnimationLoop(x),x===null?Nn.stop():Nn.start()},nt.addEventListener("sessionstart",tn),nt.addEventListener("sessionend",uo),this.render=function(x,U){if(U!==void 0&&U.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(R===!0)return;if(x.matrixWorldAutoUpdate===!0&&x.updateMatrixWorld(),U.parent===null&&U.matrixWorldAutoUpdate===!0&&U.updateMatrixWorld(),nt.enabled===!0&&nt.isPresenting===!0&&(nt.cameraAutoUpdate===!0&&nt.updateCamera(U),U=nt.getCamera()),x.isScene===!0&&x.onBeforeRender(E,x,U,L),h=wt.get(x,b.length),h.init(U),b.push(h),$.multiplyMatrices(U.projectionMatrix,U.matrixWorldInverse),It.setFromProjectionMatrix($,rn,U.reversedDepth),G=this.localClippingEnabled,Dt=it.init(this.clippingPlanes,G),m=X.get(x,T.length),m.init(),T.push(m),nt.enabled===!0&&nt.isPresenting===!0){const tt=E.xr.getDepthSensingMesh();tt!==null&&ar(tt,U,-1/0,E.sortObjects)}ar(x,U,0,E.sortObjects),m.finish(),E.sortObjects===!0&&m.sort(st,V),Xt=nt.enabled===!1||nt.isPresenting===!1||nt.hasDepthSensing()===!1,Xt&&Tt.addToRenderList(m,x),this.info.render.frame++,Dt===!0&&it.beginShadows();const B=h.state.shadowsArray;bt.render(B,x,U),Dt===!0&&it.endShadows(),this.info.autoReset===!0&&this.info.reset();const z=m.opaque,N=m.transmissive;if(h.setupLights(),U.isArrayCamera){const tt=U.cameras;if(N.length>0)for(let ct=0,Mt=tt.length;ct<Mt;ct++){const mt=tt[ct];po(z,N,x,mt)}Xt&&Tt.render(x);for(let ct=0,Mt=tt.length;ct<Mt;ct++){const mt=tt[ct];fo(m,x,mt,mt.viewport)}}else N.length>0&&po(z,N,x,U),Xt&&Tt.render(x),fo(m,x,U);L!==null&&C===0&&(Bt.updateMultisampleRenderTarget(L),Bt.updateRenderTargetMipmap(L)),x.isScene===!0&&x.onAfterRender(E,x,U),lt.resetDefaultState(),S=-1,M=null,b.pop(),b.length>0?(h=b[b.length-1],Dt===!0&&it.setGlobalState(E.clippingPlanes,h.state.camera)):h=null,T.pop(),T.length>0?m=T[T.length-1]:m=null};function ar(x,U,B,z){if(x.visible===!1)return;if(x.layers.test(U.layers)){if(x.isGroup)B=x.renderOrder;else if(x.isLOD)x.autoUpdate===!0&&x.update(U);else if(x.isLight)h.pushLight(x),x.castShadow&&h.pushShadow(x);else if(x.isSprite){if(!x.frustumCulled||It.intersectsSprite(x)){z&&Ut.setFromMatrixPosition(x.matrixWorld).applyMatrix4($);const ct=O.update(x),Mt=x.material;Mt.visible&&m.push(x,ct,Mt,B,Ut.z,null)}}else if((x.isMesh||x.isLine||x.isPoints)&&(!x.frustumCulled||It.intersectsObject(x))){const ct=O.update(x),Mt=x.material;if(z&&(x.boundingSphere!==void 0?(x.boundingSphere===null&&x.computeBoundingSphere(),Ut.copy(x.boundingSphere.center)):(ct.boundingSphere===null&&ct.computeBoundingSphere(),Ut.copy(ct.boundingSphere.center)),Ut.applyMatrix4(x.matrixWorld).applyMatrix4($)),Array.isArray(Mt)){const mt=ct.groups;for(let Lt=0,Ft=mt.length;Lt<Ft;Lt++){const Rt=mt[Lt],Zt=Mt[Rt.materialIndex];Zt&&Zt.visible&&m.push(x,ct,Zt,B,Ut.z,Rt)}}else Mt.visible&&m.push(x,ct,Mt,B,Ut.z,null)}}const tt=x.children;for(let ct=0,Mt=tt.length;ct<Mt;ct++)ar(tt[ct],U,B,z)}function fo(x,U,B,z){const N=x.opaque,tt=x.transmissive,ct=x.transparent;h.setupLightsView(B),Dt===!0&&it.setGlobalState(E.clippingPlanes,B),z&&ft.viewport(P.copy(z)),N.length>0&&cs(N,U,B),tt.length>0&&cs(tt,U,B),ct.length>0&&cs(ct,U,B),ft.buffers.depth.setTest(!0),ft.buffers.depth.setMask(!0),ft.buffers.color.setMask(!0),ft.setPolygonOffset(!1)}function po(x,U,B,z){if((B.isScene===!0?B.overrideMaterial:null)!==null)return;h.state.transmissionRenderTarget[z.id]===void 0&&(h.state.transmissionRenderTarget[z.id]=new Kn(1,1,{generateMipmaps:!0,type:gt.has("EXT_color_buffer_half_float")||gt.has("EXT_color_buffer_float")?rs:an,minFilter:qn,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Jt.workingColorSpace}));const tt=h.state.transmissionRenderTarget[z.id],ct=z.viewport||P;tt.setSize(ct.z*E.transmissionResolutionScale,ct.w*E.transmissionResolutionScale);const Mt=E.getRenderTarget(),mt=E.getActiveCubeFace(),Lt=E.getActiveMipmapLevel();E.setRenderTarget(tt),E.getClearColor(j),W=E.getClearAlpha(),W<1&&E.setClearColor(16777215,.5),E.clear(),Xt&&Tt.render(B);const Ft=E.toneMapping;E.toneMapping=Dn;const Rt=z.viewport;if(z.viewport!==void 0&&(z.viewport=void 0),h.setupLightsView(z),Dt===!0&&it.setGlobalState(E.clippingPlanes,z),cs(x,B,z),Bt.updateMultisampleRenderTarget(tt),Bt.updateRenderTargetMipmap(tt),gt.has("WEBGL_multisampled_render_to_texture")===!1){let Zt=!1;for(let ne=0,de=U.length;ne<de;ne++){const le=U[ne],ae=le.object,Pt=le.geometry,he=le.material,Kt=le.group;if(he.side===_n&&ae.layers.test(z.layers)){const Ne=he.side;he.side=Ie,he.needsUpdate=!0,mo(ae,B,z,Pt,he,Kt),he.side=Ne,he.needsUpdate=!0,Zt=!0}}Zt===!0&&(Bt.updateMultisampleRenderTarget(tt),Bt.updateRenderTargetMipmap(tt))}E.setRenderTarget(Mt,mt,Lt),E.setClearColor(j,W),Rt!==void 0&&(z.viewport=Rt),E.toneMapping=Ft}function cs(x,U,B){const z=U.isScene===!0?U.overrideMaterial:null;for(let N=0,tt=x.length;N<tt;N++){const ct=x[N],Mt=ct.object,mt=ct.geometry,Lt=ct.group;let Ft=ct.material;Ft.allowOverride===!0&&z!==null&&(Ft=z),Mt.layers.test(B.layers)&&mo(Mt,U,B,mt,Ft,Lt)}}function mo(x,U,B,z,N,tt){x.onBeforeRender(E,U,B,z,N,tt),x.modelViewMatrix.multiplyMatrices(B.matrixWorldInverse,x.matrixWorld),x.normalMatrix.getNormalMatrix(x.modelViewMatrix),N.onBeforeRender(E,U,B,z,x,tt),N.transparent===!0&&N.side===_n&&N.forceSinglePass===!1?(N.side=Ie,N.needsUpdate=!0,E.renderBufferDirect(B,U,z,N,x,tt),N.side=Ln,N.needsUpdate=!0,E.renderBufferDirect(B,U,z,N,x,tt),N.side=_n):E.renderBufferDirect(B,U,z,N,x,tt),x.onAfterRender(E,U,B,z,N,tt)}function hs(x,U,B){U.isScene!==!0&&(U=yt);const z=_t.get(x),N=h.state.lights,tt=h.state.shadowsArray,ct=N.state.version,Mt=q.getParameters(x,N.state,tt,U,B),mt=q.getProgramCacheKey(Mt);let Lt=z.programs;z.environment=x.isMeshStandardMaterial?U.environment:null,z.fog=U.fog,z.envMap=(x.isMeshStandardMaterial?kt:pe).get(x.envMap||z.environment),z.envMapRotation=z.environment!==null&&x.envMap===null?U.environmentRotation:x.envMapRotation,Lt===void 0&&(x.addEventListener("dispose",Z),Lt=new Map,z.programs=Lt);let Ft=Lt.get(mt);if(Ft!==void 0){if(z.currentProgram===Ft&&z.lightsStateVersion===ct)return _o(x,Mt),Ft}else Mt.uniforms=q.getUniforms(x),x.onBeforeCompile(Mt,E),Ft=q.acquireProgram(Mt,mt),Lt.set(mt,Ft),z.uniforms=Mt.uniforms;const Rt=z.uniforms;return(!x.isShaderMaterial&&!x.isRawShaderMaterial||x.clipping===!0)&&(Rt.clippingPlanes=it.uniform),_o(x,Mt),z.needsLights=Fc(x),z.lightsStateVersion=ct,z.needsLights&&(Rt.ambientLightColor.value=N.state.ambient,Rt.lightProbe.value=N.state.probe,Rt.directionalLights.value=N.state.directional,Rt.directionalLightShadows.value=N.state.directionalShadow,Rt.spotLights.value=N.state.spot,Rt.spotLightShadows.value=N.state.spotShadow,Rt.rectAreaLights.value=N.state.rectArea,Rt.ltc_1.value=N.state.rectAreaLTC1,Rt.ltc_2.value=N.state.rectAreaLTC2,Rt.pointLights.value=N.state.point,Rt.pointLightShadows.value=N.state.pointShadow,Rt.hemisphereLights.value=N.state.hemi,Rt.directionalShadowMap.value=N.state.directionalShadowMap,Rt.directionalShadowMatrix.value=N.state.directionalShadowMatrix,Rt.spotShadowMap.value=N.state.spotShadowMap,Rt.spotLightMatrix.value=N.state.spotLightMatrix,Rt.spotLightMap.value=N.state.spotLightMap,Rt.pointShadowMap.value=N.state.pointShadowMap,Rt.pointShadowMatrix.value=N.state.pointShadowMatrix),z.currentProgram=Ft,z.uniformsList=null,Ft}function go(x){if(x.uniformsList===null){const U=x.currentProgram.getUniforms();x.uniformsList=Ys.seqWithValue(U.seq,x.uniforms)}return x.uniformsList}function _o(x,U){const B=_t.get(x);B.outputColorSpace=U.outputColorSpace,B.batching=U.batching,B.batchingColor=U.batchingColor,B.instancing=U.instancing,B.instancingColor=U.instancingColor,B.instancingMorph=U.instancingMorph,B.skinning=U.skinning,B.morphTargets=U.morphTargets,B.morphNormals=U.morphNormals,B.morphColors=U.morphColors,B.morphTargetsCount=U.morphTargetsCount,B.numClippingPlanes=U.numClippingPlanes,B.numIntersection=U.numClipIntersection,B.vertexAlphas=U.vertexAlphas,B.vertexTangents=U.vertexTangents,B.toneMapping=U.toneMapping}function Uc(x,U,B,z,N){U.isScene!==!0&&(U=yt),Bt.resetTextureUnits();const tt=U.fog,ct=z.isMeshStandardMaterial?U.environment:null,Mt=L===null?E.outputColorSpace:L.isXRRenderTarget===!0?L.texture.colorSpace:Pi,mt=(z.isMeshStandardMaterial?kt:pe).get(z.envMap||ct),Lt=z.vertexColors===!0&&!!B.attributes.color&&B.attributes.color.itemSize===4,Ft=!!B.attributes.tangent&&(!!z.normalMap||z.anisotropy>0),Rt=!!B.morphAttributes.position,Zt=!!B.morphAttributes.normal,ne=!!B.morphAttributes.color;let de=Dn;z.toneMapped&&(L===null||L.isXRRenderTarget===!0)&&(de=E.toneMapping);const le=B.morphAttributes.position||B.morphAttributes.normal||B.morphAttributes.color,ae=le!==void 0?le.length:0,Pt=_t.get(z),he=h.state.lights;if(Dt===!0&&(G===!0||x!==M)){const Ae=x===M&&z.id===S;it.setState(z,x,Ae)}let Kt=!1;z.version===Pt.__version?(Pt.needsLights&&Pt.lightsStateVersion!==he.state.version||Pt.outputColorSpace!==Mt||N.isBatchedMesh&&Pt.batching===!1||!N.isBatchedMesh&&Pt.batching===!0||N.isBatchedMesh&&Pt.batchingColor===!0&&N.colorTexture===null||N.isBatchedMesh&&Pt.batchingColor===!1&&N.colorTexture!==null||N.isInstancedMesh&&Pt.instancing===!1||!N.isInstancedMesh&&Pt.instancing===!0||N.isSkinnedMesh&&Pt.skinning===!1||!N.isSkinnedMesh&&Pt.skinning===!0||N.isInstancedMesh&&Pt.instancingColor===!0&&N.instanceColor===null||N.isInstancedMesh&&Pt.instancingColor===!1&&N.instanceColor!==null||N.isInstancedMesh&&Pt.instancingMorph===!0&&N.morphTexture===null||N.isInstancedMesh&&Pt.instancingMorph===!1&&N.morphTexture!==null||Pt.envMap!==mt||z.fog===!0&&Pt.fog!==tt||Pt.numClippingPlanes!==void 0&&(Pt.numClippingPlanes!==it.numPlanes||Pt.numIntersection!==it.numIntersection)||Pt.vertexAlphas!==Lt||Pt.vertexTangents!==Ft||Pt.morphTargets!==Rt||Pt.morphNormals!==Zt||Pt.morphColors!==ne||Pt.toneMapping!==de||Pt.morphTargetsCount!==ae)&&(Kt=!0):(Kt=!0,Pt.__version=z.version);let Ne=Pt.currentProgram;Kt===!0&&(Ne=hs(z,U,N));let ni=!1,Fe=!1,Fi=!1;const ue=Ne.getUniforms(),ze=Pt.uniforms;if(ft.useProgram(Ne.program)&&(ni=!0,Fe=!0,Fi=!0),z.id!==S&&(S=z.id,Fe=!0),ni||M!==x){ft.buffers.depth.getReversed()&&x.reversedDepth!==!0&&(x._reversedDepth=!0,x.updateProjectionMatrix()),ue.setValue(A,"projectionMatrix",x.projectionMatrix),ue.setValue(A,"viewMatrix",x.matrixWorldInverse);const De=ue.map.cameraPosition;De!==void 0&&De.setValue(A,dt.setFromMatrixPosition(x.matrixWorld)),pt.logarithmicDepthBuffer&&ue.setValue(A,"logDepthBufFC",2/(Math.log(x.far+1)/Math.LN2)),(z.isMeshPhongMaterial||z.isMeshToonMaterial||z.isMeshLambertMaterial||z.isMeshBasicMaterial||z.isMeshStandardMaterial||z.isShaderMaterial)&&ue.setValue(A,"isOrthographic",x.isOrthographicCamera===!0),M!==x&&(M=x,Fe=!0,Fi=!0)}if(N.isSkinnedMesh){ue.setOptional(A,N,"bindMatrix"),ue.setOptional(A,N,"bindMatrixInverse");const Ae=N.skeleton;Ae&&(Ae.boneTexture===null&&Ae.computeBoneTexture(),ue.setValue(A,"boneTexture",Ae.boneTexture,Bt))}N.isBatchedMesh&&(ue.setOptional(A,N,"batchingTexture"),ue.setValue(A,"batchingTexture",N._matricesTexture,Bt),ue.setOptional(A,N,"batchingIdTexture"),ue.setValue(A,"batchingIdTexture",N._indirectTexture,Bt),ue.setOptional(A,N,"batchingColorTexture"),N._colorsTexture!==null&&ue.setValue(A,"batchingColorTexture",N._colorsTexture,Bt));const ke=B.morphAttributes;if((ke.position!==void 0||ke.normal!==void 0||ke.color!==void 0)&&et.update(N,B,Ne),(Fe||Pt.receiveShadow!==N.receiveShadow)&&(Pt.receiveShadow=N.receiveShadow,ue.setValue(A,"receiveShadow",N.receiveShadow)),z.isMeshGouraudMaterial&&z.envMap!==null&&(ze.envMap.value=mt,ze.flipEnvMap.value=mt.isCubeTexture&&mt.isRenderTargetTexture===!1?-1:1),z.isMeshStandardMaterial&&z.envMap===null&&U.environment!==null&&(ze.envMapIntensity.value=U.environmentIntensity),Fe&&(ue.setValue(A,"toneMappingExposure",E.toneMappingExposure),Pt.needsLights&&Nc(ze,Fi),tt&&z.fog===!0&&J.refreshFogUniforms(ze,tt),J.refreshMaterialUniforms(ze,z,H,K,h.state.transmissionRenderTarget[x.id]),Ys.upload(A,go(Pt),ze,Bt)),z.isShaderMaterial&&z.uniformsNeedUpdate===!0&&(Ys.upload(A,go(Pt),ze,Bt),z.uniformsNeedUpdate=!1),z.isSpriteMaterial&&ue.setValue(A,"center",N.center),ue.setValue(A,"modelViewMatrix",N.modelViewMatrix),ue.setValue(A,"normalMatrix",N.normalMatrix),ue.setValue(A,"modelMatrix",N.matrixWorld),z.isShaderMaterial||z.isRawShaderMaterial){const Ae=z.uniformsGroups;for(let De=0,or=Ae.length;De<or;De++){const Fn=Ae[De];Ht.update(Fn,Ne),Ht.bind(Fn,Ne)}}return Ne}function Nc(x,U){x.ambientLightColor.needsUpdate=U,x.lightProbe.needsUpdate=U,x.directionalLights.needsUpdate=U,x.directionalLightShadows.needsUpdate=U,x.pointLights.needsUpdate=U,x.pointLightShadows.needsUpdate=U,x.spotLights.needsUpdate=U,x.spotLightShadows.needsUpdate=U,x.rectAreaLights.needsUpdate=U,x.hemisphereLights.needsUpdate=U}function Fc(x){return x.isMeshLambertMaterial||x.isMeshToonMaterial||x.isMeshPhongMaterial||x.isMeshStandardMaterial||x.isShadowMaterial||x.isShaderMaterial&&x.lights===!0}this.getActiveCubeFace=function(){return w},this.getActiveMipmapLevel=function(){return C},this.getRenderTarget=function(){return L},this.setRenderTargetTextures=function(x,U,B){const z=_t.get(x);z.__autoAllocateDepthBuffer=x.resolveDepthBuffer===!1,z.__autoAllocateDepthBuffer===!1&&(z.__useRenderToTexture=!1),_t.get(x.texture).__webglTexture=U,_t.get(x.depthTexture).__webglTexture=z.__autoAllocateDepthBuffer?void 0:B,z.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(x,U){const B=_t.get(x);B.__webglFramebuffer=U,B.__useDefaultFramebuffer=U===void 0};const Oc=A.createFramebuffer();this.setRenderTarget=function(x,U=0,B=0){L=x,w=U,C=B;let z=!0,N=null,tt=!1,ct=!1;if(x){const mt=_t.get(x);if(mt.__useDefaultFramebuffer!==void 0)ft.bindFramebuffer(A.FRAMEBUFFER,null),z=!1;else if(mt.__webglFramebuffer===void 0)Bt.setupRenderTarget(x);else if(mt.__hasExternalTextures)Bt.rebindTextures(x,_t.get(x.texture).__webglTexture,_t.get(x.depthTexture).__webglTexture);else if(x.depthBuffer){const Rt=x.depthTexture;if(mt.__boundDepthTexture!==Rt){if(Rt!==null&&_t.has(Rt)&&(x.width!==Rt.image.width||x.height!==Rt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Bt.setupDepthRenderbuffer(x)}}const Lt=x.texture;(Lt.isData3DTexture||Lt.isDataArrayTexture||Lt.isCompressedArrayTexture)&&(ct=!0);const Ft=_t.get(x).__webglFramebuffer;x.isWebGLCubeRenderTarget?(Array.isArray(Ft[U])?N=Ft[U][B]:N=Ft[U],tt=!0):x.samples>0&&Bt.useMultisampledRTT(x)===!1?N=_t.get(x).__webglMultisampledFramebuffer:Array.isArray(Ft)?N=Ft[B]:N=Ft,P.copy(x.viewport),F.copy(x.scissor),k=x.scissorTest}else P.copy(at).multiplyScalar(H).floor(),F.copy(Et).multiplyScalar(H).floor(),k=ht;if(B!==0&&(N=Oc),ft.bindFramebuffer(A.FRAMEBUFFER,N)&&z&&ft.drawBuffers(x,N),ft.viewport(P),ft.scissor(F),ft.setScissorTest(k),tt){const mt=_t.get(x.texture);A.framebufferTexture2D(A.FRAMEBUFFER,A.COLOR_ATTACHMENT0,A.TEXTURE_CUBE_MAP_POSITIVE_X+U,mt.__webglTexture,B)}else if(ct){const mt=U;for(let Lt=0;Lt<x.textures.length;Lt++){const Ft=_t.get(x.textures[Lt]);A.framebufferTextureLayer(A.FRAMEBUFFER,A.COLOR_ATTACHMENT0+Lt,Ft.__webglTexture,B,mt)}}else if(x!==null&&B!==0){const mt=_t.get(x.texture);A.framebufferTexture2D(A.FRAMEBUFFER,A.COLOR_ATTACHMENT0,A.TEXTURE_2D,mt.__webglTexture,B)}S=-1},this.readRenderTargetPixels=function(x,U,B,z,N,tt,ct,Mt=0){if(!(x&&x.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let mt=_t.get(x).__webglFramebuffer;if(x.isWebGLCubeRenderTarget&&ct!==void 0&&(mt=mt[ct]),mt){ft.bindFramebuffer(A.FRAMEBUFFER,mt);try{const Lt=x.textures[Mt],Ft=Lt.format,Rt=Lt.type;if(!pt.textureFormatReadable(Ft)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!pt.textureTypeReadable(Rt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}U>=0&&U<=x.width-z&&B>=0&&B<=x.height-N&&(x.textures.length>1&&A.readBuffer(A.COLOR_ATTACHMENT0+Mt),A.readPixels(U,B,z,N,At.convert(Ft),At.convert(Rt),tt))}finally{const Lt=L!==null?_t.get(L).__webglFramebuffer:null;ft.bindFramebuffer(A.FRAMEBUFFER,Lt)}}},this.readRenderTargetPixelsAsync=async function(x,U,B,z,N,tt,ct,Mt=0){if(!(x&&x.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let mt=_t.get(x).__webglFramebuffer;if(x.isWebGLCubeRenderTarget&&ct!==void 0&&(mt=mt[ct]),mt)if(U>=0&&U<=x.width-z&&B>=0&&B<=x.height-N){ft.bindFramebuffer(A.FRAMEBUFFER,mt);const Lt=x.textures[Mt],Ft=Lt.format,Rt=Lt.type;if(!pt.textureFormatReadable(Ft))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!pt.textureTypeReadable(Rt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Zt=A.createBuffer();A.bindBuffer(A.PIXEL_PACK_BUFFER,Zt),A.bufferData(A.PIXEL_PACK_BUFFER,tt.byteLength,A.STREAM_READ),x.textures.length>1&&A.readBuffer(A.COLOR_ATTACHMENT0+Mt),A.readPixels(U,B,z,N,At.convert(Ft),At.convert(Rt),0);const ne=L!==null?_t.get(L).__webglFramebuffer:null;ft.bindFramebuffer(A.FRAMEBUFFER,ne);const de=A.fenceSync(A.SYNC_GPU_COMMANDS_COMPLETE,0);return A.flush(),await Wh(A,de,4),A.bindBuffer(A.PIXEL_PACK_BUFFER,Zt),A.getBufferSubData(A.PIXEL_PACK_BUFFER,0,tt),A.deleteBuffer(Zt),A.deleteSync(de),tt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(x,U=null,B=0){const z=Math.pow(2,-B),N=Math.floor(x.image.width*z),tt=Math.floor(x.image.height*z),ct=U!==null?U.x:0,Mt=U!==null?U.y:0;Bt.setTexture2D(x,0),A.copyTexSubImage2D(A.TEXTURE_2D,B,0,0,ct,Mt,N,tt),ft.unbindTexture()};const Bc=A.createFramebuffer(),zc=A.createFramebuffer();this.copyTextureToTexture=function(x,U,B=null,z=null,N=0,tt=null){tt===null&&(N!==0?(es("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),tt=N,N=0):tt=0);let ct,Mt,mt,Lt,Ft,Rt,Zt,ne,de;const le=x.isCompressedTexture?x.mipmaps[tt]:x.image;if(B!==null)ct=B.max.x-B.min.x,Mt=B.max.y-B.min.y,mt=B.isBox3?B.max.z-B.min.z:1,Lt=B.min.x,Ft=B.min.y,Rt=B.isBox3?B.min.z:0;else{const ke=Math.pow(2,-N);ct=Math.floor(le.width*ke),Mt=Math.floor(le.height*ke),x.isDataArrayTexture?mt=le.depth:x.isData3DTexture?mt=Math.floor(le.depth*ke):mt=1,Lt=0,Ft=0,Rt=0}z!==null?(Zt=z.x,ne=z.y,de=z.z):(Zt=0,ne=0,de=0);const ae=At.convert(U.format),Pt=At.convert(U.type);let he;U.isData3DTexture?(Bt.setTexture3D(U,0),he=A.TEXTURE_3D):U.isDataArrayTexture||U.isCompressedArrayTexture?(Bt.setTexture2DArray(U,0),he=A.TEXTURE_2D_ARRAY):(Bt.setTexture2D(U,0),he=A.TEXTURE_2D),A.pixelStorei(A.UNPACK_FLIP_Y_WEBGL,U.flipY),A.pixelStorei(A.UNPACK_PREMULTIPLY_ALPHA_WEBGL,U.premultiplyAlpha),A.pixelStorei(A.UNPACK_ALIGNMENT,U.unpackAlignment);const Kt=A.getParameter(A.UNPACK_ROW_LENGTH),Ne=A.getParameter(A.UNPACK_IMAGE_HEIGHT),ni=A.getParameter(A.UNPACK_SKIP_PIXELS),Fe=A.getParameter(A.UNPACK_SKIP_ROWS),Fi=A.getParameter(A.UNPACK_SKIP_IMAGES);A.pixelStorei(A.UNPACK_ROW_LENGTH,le.width),A.pixelStorei(A.UNPACK_IMAGE_HEIGHT,le.height),A.pixelStorei(A.UNPACK_SKIP_PIXELS,Lt),A.pixelStorei(A.UNPACK_SKIP_ROWS,Ft),A.pixelStorei(A.UNPACK_SKIP_IMAGES,Rt);const ue=x.isDataArrayTexture||x.isData3DTexture,ze=U.isDataArrayTexture||U.isData3DTexture;if(x.isDepthTexture){const ke=_t.get(x),Ae=_t.get(U),De=_t.get(ke.__renderTarget),or=_t.get(Ae.__renderTarget);ft.bindFramebuffer(A.READ_FRAMEBUFFER,De.__webglFramebuffer),ft.bindFramebuffer(A.DRAW_FRAMEBUFFER,or.__webglFramebuffer);for(let Fn=0;Fn<mt;Fn++)ue&&(A.framebufferTextureLayer(A.READ_FRAMEBUFFER,A.COLOR_ATTACHMENT0,_t.get(x).__webglTexture,N,Rt+Fn),A.framebufferTextureLayer(A.DRAW_FRAMEBUFFER,A.COLOR_ATTACHMENT0,_t.get(U).__webglTexture,tt,de+Fn)),A.blitFramebuffer(Lt,Ft,ct,Mt,Zt,ne,ct,Mt,A.DEPTH_BUFFER_BIT,A.NEAREST);ft.bindFramebuffer(A.READ_FRAMEBUFFER,null),ft.bindFramebuffer(A.DRAW_FRAMEBUFFER,null)}else if(N!==0||x.isRenderTargetTexture||_t.has(x)){const ke=_t.get(x),Ae=_t.get(U);ft.bindFramebuffer(A.READ_FRAMEBUFFER,Bc),ft.bindFramebuffer(A.DRAW_FRAMEBUFFER,zc);for(let De=0;De<mt;De++)ue?A.framebufferTextureLayer(A.READ_FRAMEBUFFER,A.COLOR_ATTACHMENT0,ke.__webglTexture,N,Rt+De):A.framebufferTexture2D(A.READ_FRAMEBUFFER,A.COLOR_ATTACHMENT0,A.TEXTURE_2D,ke.__webglTexture,N),ze?A.framebufferTextureLayer(A.DRAW_FRAMEBUFFER,A.COLOR_ATTACHMENT0,Ae.__webglTexture,tt,de+De):A.framebufferTexture2D(A.DRAW_FRAMEBUFFER,A.COLOR_ATTACHMENT0,A.TEXTURE_2D,Ae.__webglTexture,tt),N!==0?A.blitFramebuffer(Lt,Ft,ct,Mt,Zt,ne,ct,Mt,A.COLOR_BUFFER_BIT,A.NEAREST):ze?A.copyTexSubImage3D(he,tt,Zt,ne,de+De,Lt,Ft,ct,Mt):A.copyTexSubImage2D(he,tt,Zt,ne,Lt,Ft,ct,Mt);ft.bindFramebuffer(A.READ_FRAMEBUFFER,null),ft.bindFramebuffer(A.DRAW_FRAMEBUFFER,null)}else ze?x.isDataTexture||x.isData3DTexture?A.texSubImage3D(he,tt,Zt,ne,de,ct,Mt,mt,ae,Pt,le.data):U.isCompressedArrayTexture?A.compressedTexSubImage3D(he,tt,Zt,ne,de,ct,Mt,mt,ae,le.data):A.texSubImage3D(he,tt,Zt,ne,de,ct,Mt,mt,ae,Pt,le):x.isDataTexture?A.texSubImage2D(A.TEXTURE_2D,tt,Zt,ne,ct,Mt,ae,Pt,le.data):x.isCompressedTexture?A.compressedTexSubImage2D(A.TEXTURE_2D,tt,Zt,ne,le.width,le.height,ae,le.data):A.texSubImage2D(A.TEXTURE_2D,tt,Zt,ne,ct,Mt,ae,Pt,le);A.pixelStorei(A.UNPACK_ROW_LENGTH,Kt),A.pixelStorei(A.UNPACK_IMAGE_HEIGHT,Ne),A.pixelStorei(A.UNPACK_SKIP_PIXELS,ni),A.pixelStorei(A.UNPACK_SKIP_ROWS,Fe),A.pixelStorei(A.UNPACK_SKIP_IMAGES,Fi),tt===0&&U.generateMipmaps&&A.generateMipmap(he),ft.unbindTexture()},this.initRenderTarget=function(x){_t.get(x).__webglFramebuffer===void 0&&Bt.setupRenderTarget(x)},this.initTexture=function(x){x.isCubeTexture?Bt.setTextureCube(x,0):x.isData3DTexture?Bt.setTexture3D(x,0):x.isDataArrayTexture||x.isCompressedArrayTexture?Bt.setTexture2DArray(x,0):Bt.setTexture2D(x,0),ft.unbindTexture()},this.resetState=function(){w=0,C=0,L=null,ft.reset(),lt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return rn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=Jt._getDrawingBufferColorSpace(t),e.unpackColorSpace=Jt._getUnpackColorSpace()}}const Al={type:"change"},oo={type:"start"},Mc={type:"end"},ks=new ls,wl=new Rn,gg=Math.cos(70*tc.DEG2RAD),_e=new I,Le=2*Math.PI,re={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},kr=1e-6;class _g extends Du{constructor(t,e=null){super(t,e),this.state=re.NONE,this.target=new I,this.cursor=new I,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Ei.ROTATE,MIDDLE:Ei.DOLLY,RIGHT:Ei.PAN},this.touches={ONE:Mi.ROTATE,TWO:Mi.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new I,this._lastQuaternion=new Zn,this._lastTargetPosition=new I,this._quat=new Zn().setFromUnitVectors(t.up,new I(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new tl,this._sphericalDelta=new tl,this._scale=1,this._panOffset=new I,this._rotateStart=new Ot,this._rotateEnd=new Ot,this._rotateDelta=new Ot,this._panStart=new Ot,this._panEnd=new Ot,this._panDelta=new Ot,this._dollyStart=new Ot,this._dollyEnd=new Ot,this._dollyDelta=new Ot,this._dollyDirection=new I,this._mouse=new Ot,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=xg.bind(this),this._onPointerDown=vg.bind(this),this._onPointerUp=Mg.bind(this),this._onContextMenu=wg.bind(this),this._onMouseWheel=yg.bind(this),this._onKeyDown=bg.bind(this),this._onTouchStart=Tg.bind(this),this._onTouchMove=Ag.bind(this),this._onMouseDown=Sg.bind(this),this._onMouseMove=Eg.bind(this),this._interceptControlDown=Rg.bind(this),this._interceptControlUp=Cg.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}connect(t){super.connect(t),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(t){t.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=t}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Al),this.update(),this.state=re.NONE}update(t=null){const e=this.object.position;_e.copy(e).sub(this.target),_e.applyQuaternion(this._quat),this._spherical.setFromVector3(_e),this.autoRotate&&this.state===re.NONE&&this._rotateLeft(this._getAutoRotationAngle(t)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let n=this.minAzimuthAngle,s=this.maxAzimuthAngle;isFinite(n)&&isFinite(s)&&(n<-Math.PI?n+=Le:n>Math.PI&&(n-=Le),s<-Math.PI?s+=Le:s>Math.PI&&(s-=Le),n<=s?this._spherical.theta=Math.max(n,Math.min(s,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(n+s)/2?Math.max(n,this._spherical.theta):Math.min(s,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let r=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const a=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),r=a!=this._spherical.radius}if(_e.setFromSpherical(this._spherical),_e.applyQuaternion(this._quatInverse),e.copy(this.target).add(_e),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let a=null;if(this.object.isPerspectiveCamera){const o=_e.length();a=this._clampDistance(o*this._scale);const c=o-a;this.object.position.addScaledVector(this._dollyDirection,c),this.object.updateMatrixWorld(),r=!!c}else if(this.object.isOrthographicCamera){const o=new I(this._mouse.x,this._mouse.y,0);o.unproject(this.object);const c=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),r=c!==this.object.zoom;const l=new I(this._mouse.x,this._mouse.y,0);l.unproject(this.object),this.object.position.sub(l).add(o),this.object.updateMatrixWorld(),a=_e.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;a!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(a).add(this.object.position):(ks.origin.copy(this.object.position),ks.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(ks.direction))<gg?this.object.lookAt(this.target):(wl.setFromNormalAndCoplanarPoint(this.object.up,this.target),ks.intersectPlane(wl,this.target))))}else if(this.object.isOrthographicCamera){const a=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),a!==this.object.zoom&&(this.object.updateProjectionMatrix(),r=!0)}return this._scale=1,this._performCursorZoom=!1,r||this._lastPosition.distanceToSquared(this.object.position)>kr||8*(1-this._lastQuaternion.dot(this.object.quaternion))>kr||this._lastTargetPosition.distanceToSquared(this.target)>kr?(this.dispatchEvent(Al),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(t){return t!==null?Le/60*this.autoRotateSpeed*t:Le/60/60*this.autoRotateSpeed}_getZoomScale(t){const e=Math.abs(t*.01);return Math.pow(.95,this.zoomSpeed*e)}_rotateLeft(t){this._sphericalDelta.theta-=t}_rotateUp(t){this._sphericalDelta.phi-=t}_panLeft(t,e){_e.setFromMatrixColumn(e,0),_e.multiplyScalar(-t),this._panOffset.add(_e)}_panUp(t,e){this.screenSpacePanning===!0?_e.setFromMatrixColumn(e,1):(_e.setFromMatrixColumn(e,0),_e.crossVectors(this.object.up,_e)),_e.multiplyScalar(t),this._panOffset.add(_e)}_pan(t,e){const n=this.domElement;if(this.object.isPerspectiveCamera){const s=this.object.position;_e.copy(s).sub(this.target);let r=_e.length();r*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*t*r/n.clientHeight,this.object.matrix),this._panUp(2*e*r/n.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(t*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(e*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(t,e){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const n=this.domElement.getBoundingClientRect(),s=t-n.left,r=e-n.top,a=n.width,o=n.height;this._mouse.x=s/a*2-1,this._mouse.y=-(r/o)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(t){return Math.max(this.minDistance,Math.min(this.maxDistance,t))}_handleMouseDownRotate(t){this._rotateStart.set(t.clientX,t.clientY)}_handleMouseDownDolly(t){this._updateZoomParameters(t.clientX,t.clientX),this._dollyStart.set(t.clientX,t.clientY)}_handleMouseDownPan(t){this._panStart.set(t.clientX,t.clientY)}_handleMouseMoveRotate(t){this._rotateEnd.set(t.clientX,t.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const e=this.domElement;this._rotateLeft(Le*this._rotateDelta.x/e.clientHeight),this._rotateUp(Le*this._rotateDelta.y/e.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(t){this._dollyEnd.set(t.clientX,t.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(t){this._panEnd.set(t.clientX,t.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(t){this._updateZoomParameters(t.clientX,t.clientY),t.deltaY<0?this._dollyIn(this._getZoomScale(t.deltaY)):t.deltaY>0&&this._dollyOut(this._getZoomScale(t.deltaY)),this.update()}_handleKeyDown(t){let e=!1;switch(t.code){case this.keys.UP:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(Le*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),e=!0;break;case this.keys.BOTTOM:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(-Le*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),e=!0;break;case this.keys.LEFT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(Le*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),e=!0;break;case this.keys.RIGHT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(-Le*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),e=!0;break}e&&(t.preventDefault(),this.update())}_handleTouchStartRotate(t){if(this._pointers.length===1)this._rotateStart.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),s=.5*(t.pageY+e.y);this._rotateStart.set(n,s)}}_handleTouchStartPan(t){if(this._pointers.length===1)this._panStart.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),s=.5*(t.pageY+e.y);this._panStart.set(n,s)}}_handleTouchStartDolly(t){const e=this._getSecondPointerPosition(t),n=t.pageX-e.x,s=t.pageY-e.y,r=Math.sqrt(n*n+s*s);this._dollyStart.set(0,r)}_handleTouchStartDollyPan(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enablePan&&this._handleTouchStartPan(t)}_handleTouchStartDollyRotate(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enableRotate&&this._handleTouchStartRotate(t)}_handleTouchMoveRotate(t){if(this._pointers.length==1)this._rotateEnd.set(t.pageX,t.pageY);else{const n=this._getSecondPointerPosition(t),s=.5*(t.pageX+n.x),r=.5*(t.pageY+n.y);this._rotateEnd.set(s,r)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const e=this.domElement;this._rotateLeft(Le*this._rotateDelta.x/e.clientHeight),this._rotateUp(Le*this._rotateDelta.y/e.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(t){if(this._pointers.length===1)this._panEnd.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),s=.5*(t.pageY+e.y);this._panEnd.set(n,s)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(t){const e=this._getSecondPointerPosition(t),n=t.pageX-e.x,s=t.pageY-e.y,r=Math.sqrt(n*n+s*s);this._dollyEnd.set(0,r),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const a=(t.pageX+e.x)*.5,o=(t.pageY+e.y)*.5;this._updateZoomParameters(a,o)}_handleTouchMoveDollyPan(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enablePan&&this._handleTouchMovePan(t)}_handleTouchMoveDollyRotate(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enableRotate&&this._handleTouchMoveRotate(t)}_addPointer(t){this._pointers.push(t.pointerId)}_removePointer(t){delete this._pointerPositions[t.pointerId];for(let e=0;e<this._pointers.length;e++)if(this._pointers[e]==t.pointerId){this._pointers.splice(e,1);return}}_isTrackingPointer(t){for(let e=0;e<this._pointers.length;e++)if(this._pointers[e]==t.pointerId)return!0;return!1}_trackPointer(t){let e=this._pointerPositions[t.pointerId];e===void 0&&(e=new Ot,this._pointerPositions[t.pointerId]=e),e.set(t.pageX,t.pageY)}_getSecondPointerPosition(t){const e=t.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[e]}_customWheelEvent(t){const e=t.deltaMode,n={clientX:t.clientX,clientY:t.clientY,deltaY:t.deltaY};switch(e){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100;break}return t.ctrlKey&&!this._controlActive&&(n.deltaY*=10),n}}function vg(i){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(i.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(i)&&(this._addPointer(i),i.pointerType==="touch"?this._onTouchStart(i):this._onMouseDown(i)))}function xg(i){this.enabled!==!1&&(i.pointerType==="touch"?this._onTouchMove(i):this._onMouseMove(i))}function Mg(i){switch(this._removePointer(i),this._pointers.length){case 0:this.domElement.releasePointerCapture(i.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(Mc),this.state=re.NONE;break;case 1:const t=this._pointers[0],e=this._pointerPositions[t];this._onTouchStart({pointerId:t,pageX:e.x,pageY:e.y});break}}function Sg(i){let t;switch(i.button){case 0:t=this.mouseButtons.LEFT;break;case 1:t=this.mouseButtons.MIDDLE;break;case 2:t=this.mouseButtons.RIGHT;break;default:t=-1}switch(t){case Ei.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(i),this.state=re.DOLLY;break;case Ei.ROTATE:if(i.ctrlKey||i.metaKey||i.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(i),this.state=re.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(i),this.state=re.ROTATE}break;case Ei.PAN:if(i.ctrlKey||i.metaKey||i.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(i),this.state=re.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(i),this.state=re.PAN}break;default:this.state=re.NONE}this.state!==re.NONE&&this.dispatchEvent(oo)}function Eg(i){switch(this.state){case re.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(i);break;case re.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(i);break;case re.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(i);break}}function yg(i){this.enabled===!1||this.enableZoom===!1||this.state!==re.NONE||(i.preventDefault(),this.dispatchEvent(oo),this._handleMouseWheel(this._customWheelEvent(i)),this.dispatchEvent(Mc))}function bg(i){this.enabled!==!1&&this._handleKeyDown(i)}function Tg(i){switch(this._trackPointer(i),this._pointers.length){case 1:switch(this.touches.ONE){case Mi.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(i),this.state=re.TOUCH_ROTATE;break;case Mi.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(i),this.state=re.TOUCH_PAN;break;default:this.state=re.NONE}break;case 2:switch(this.touches.TWO){case Mi.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(i),this.state=re.TOUCH_DOLLY_PAN;break;case Mi.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(i),this.state=re.TOUCH_DOLLY_ROTATE;break;default:this.state=re.NONE}break;default:this.state=re.NONE}this.state!==re.NONE&&this.dispatchEvent(oo)}function Ag(i){switch(this._trackPointer(i),this.state){case re.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(i),this.update();break;case re.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(i),this.update();break;case re.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(i),this.update();break;case re.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(i),this.update();break;default:this.state=re.NONE}}function wg(i){this.enabled!==!1&&i.preventDefault()}function Rg(i){i.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function Cg(i){i.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}const _i={selected:1280888,related:12749348,dimOpacity:.16};function Pg(i,t,e,{active:n=!1,related:s=!1,focused:r=!0,baseOpacity:a=1,dimOpacity:o=_i.dimOpacity}={}){var f;const c=i.material,l=n&&r,u=r&&!n&&!s;c.color.copy(t),l&&c.color.lerp(new jt(_i.selected),.4),c.opacity=u?Math.min(a,o):a,c.transparent=c.opacity<1,c.depthWrite=!c.transparent,(f=c.emissive)==null||f.set(l?_i.selected:s?_i.related:0),"emissiveIntensity"in c&&(c.emissiveIntensity=l||s?.25:0),e&&(e.visible=l||s,e.material.color.set(l?_i.selected:_i.related))}function Sc(i,t){const e=new mu,n=new Ge(38,1,.05,100),s=new mg({antialias:!0,alpha:!0});s.setPixelRatio(Math.min(devicePixelRatio,2)),s.setClearColor(t,1),i.append(s.domElement);const r=new _g(n,s.domElement);return r.enableDamping=!0,r.minDistance=3,r.maxDistance=22,new ResizeObserver(()=>{const a=i.clientWidth,o=i.clientHeight;!a||!o||(s.setSize(a,o,!1),n.aspect=a/o,n.updateProjectionMatrix())}).observe(i),{world:e,camera:n,renderer:s,controls:r}}function Dg(i,t,e){const{world:n,camera:s,renderer:r,controls:a}=Sc(i,15857655),o={},c=[];for(const V of t)o[V.id]=new Xi,n.add(o[V.id]);function l(){s.position.set(8,5.5,10),a.target.set(.3,1.3,0),a.update()}l(),n.add(new bu(16777215,8427931,3));const u=new wu(16777215,3);u.position.set(3,8,5),n.add(u),n.add(new Pu(12,24,13097944,14805736));function f(V,at,Et,ht,It=!1){const Dt=new Xe(at,new Su({color:Et,metalness:.35,roughness:.35}));Dt.position.set(...ht),Dt.userData={part:V,color:new jt(Et),glass:It},o[V].add(Dt),c.push(Dt);const G=new so(new dc(at,35),new ir({color:821880,depthTest:!1}));return G.renderOrder=5,Dt.add(G),Dt.userData.outline=G,Dt}const d=(V,at,Et,ht)=>f(V,new Ui(...at),Et,ht);function p(V,at,Et,ht,It){const Dt=f(V,new Ai(at,at,Et,40),ht,It);return Dt.rotation.z=-Math.PI/2,Dt}d("vacuum",[8,.2,3.8],14017509,[.3,-.05,0]),d("vacuum",[1,.7,.9],7112337,[-3,.4,-1]),d("cryostat",[1.2,.4,1.2],7379371,[-2,.4,0]),p("cryostat",.35,1,9878729,[-2,1,0]);const g=f("tip",new Ai(.025,.24,1.4,40),13147244,[-2,1.5,0]);g.rotation.z=-Math.PI/2;const v=f("tip",new tr(.08,20,12),16039288,[-1.3,1.5,0]),m=f("electrode",new ro(.47,.14,16,48),7448476,[-.5,1.5,0]);m.rotation.y=Math.PI/2;const h=p("flight",.85,3.7,11783891,[1.5,1.5,0]);h.userData.glass=!0,p("detector",1.05,.2,9599157,[3.5,1.5,0]),p("detector",1.16,.08,5993088,[3.67,1.5,0]),p("laser",.22,1,6717326,[-2.7,3,-.8]).quaternion.setFromUnitVectors(new I(0,1,0),new I(1,-1.5,.8).normalize()),d("pulser",[1,.6,.7],8293799,[-2.5,.65,1.1]),d("pulser",[.3,.3,.3],6191763,[-2.2,1.2,.7]);function b(V,at){const Et=new Xe(new Ai(at,at,1,12),new Ks({color:V,transparent:!0,opacity:.9,depthTest:!1}));return Et.renderOrder=7,n.add(Et),Et}function E(V,at,Et){const ht=Et.clone().sub(at);V.position.copy(at).add(Et).multiplyScalar(.5),V.quaternion.setFromUnitVectors(new I(0,1,0),ht.clone().normalize()),V.scale.y=ht.length()}const R=b(14920761,.035),w=b(15696465,.027),C=Array.from({length:1},()=>b(10122182,.014)),L=Array.from({length:1},()=>{const V=new Xe(new tr(.07,12,8),new Ks({color:11632093,depthTest:!1}));return V.renderOrder=8,n.add(V),V});let S="tip",M=!0,P=[],F=!1,k=0;const j={tip:[-1,0,0],electrode:[0,1,0],laser:[-1,1,-.5],pulser:[-1,0,1],flight:[0,1,0],detector:[1,0,0],cryostat:[0,-.1,1],vacuum:[0,-.2,-.4]};function W(){for(const V of c)Pg(V,V.userData.color,V.userData.outline,{active:V.userData.part===S,related:P.includes(V.userData.part),focused:M,baseOpacity:V.userData.glass?.18:1})}W();const Y=new Ot,K=new Cu;let H;r.domElement.addEventListener("pointerdown",V=>{H=[V.clientX,V.clientY]}),r.domElement.addEventListener("pointerup",V=>{if(!H||Math.hypot(V.clientX-H[0],V.clientY-H[1])>5)return;const at=r.domElement.getBoundingClientRect();Y.set((V.clientX-at.left)/at.width*2-1,-(V.clientY-at.top)/at.height*2+1),K.setFromCamera(Y,s);const Et=K.intersectObjects(c,!1)[0];Et&&e(Et.object.userData.part)});function st(V,at,Et){k=tc.damp(k,F?1:0,6,at);for(const[G,$]of Object.entries(o))$.position.set(...j[G]).multiplyScalar(k);g.scale.y=1-V.evaporated/V.total*.2,g.position.x=-2-V.evaporated/V.total*.14,v.position.x=-1.3-V.evaporated/V.total*.28;const ht=v.position.clone(),It=V.sequence,Dt=!F&&k<.02;R.visible=Dt&&It.pulseOn&&V.status==="scanning"&&V.mode==="laser",w.visible=Dt&&It.pulseOn&&V.status==="scanning"&&V.mode==="voltage",E(R,new I(-2.5,2.7,-.65),ht),E(w,new I(-2.2,1.2,.7),ht),R.material.opacity=.95;for(let G=0;G<L.length;G++){const $=It.row,dt=new I(3.38,1.5+(($==null?void 0:$.hitX)||0)*.85,(($==null?void 0:$.hitY)||0)*.85);C[G].visible=!1,L[G].visible=Dt&&(It.ionVisible||It.stage==="detection"),E(C[G],ht,dt),L[G].position.lerpVectors(ht,dt,It.flightProgress),L[G].material.color.set(er[($==null?void 0:$.element)||"Si"].color)}a.update(),r.render(n,s)}return{render:st,home:l,select(V){S=V,W()},related(V){P=V,W()},focus(V){M=V,W()},explode(V){F=V}}}function Lg(i){const{world:t,camera:e,renderer:n,controls:s}=Sc(i,1320496);e.position.set(4,2,5),s.target.set(0,0,0),s.update();const r=new Float32Array(4096*3),a=new Float32Array(4096*3),o=new Pe;o.setAttribute("position",new qe(r,3)),o.setAttribute("color",new qe(a,3)),o.setDrawRange(0,0);const c=new Mu(o,new cc({size:.045,vertexColors:!0}));c.frustumCulled=!1,t.add(c);const l=new so(new dc(new Ai(.8,.8,3,32)),new ir({color:3955045,transparent:!0,opacity:.5}));t.add(l);let u,f=-1,d;function p(g,v){if(g.rows!==u||g.index!==f||v!==d){let m=0;for(const h of g.rows){if(v!=="all"&&h.element!==v)continue;r.set([h.x*.1,1.5-h.z*.1,h.y*.1],m*3);const T=new jt(er[h.element].color);a.set([T.r,T.g,T.b],m*3),m++}o.attributes.position.needsUpdate=!0,o.attributes.color.needsUpdate=!0,o.setDrawRange(0,m),u=g.rows,f=g.index,d=v}s.update(),n.render(t,e)}return{render:p,home(){e.position.set(4,2,5),s.target.set(0,0,0),s.update()}}}function Ig(i,t,e,n){const s=i.getContext("2d"),r=i.width,a=i.height;if(s.clearRect(0,0,r,a),s.fillStyle="#f7fafb",s.fillRect(0,0,r,a),s.font="16px sans-serif",e==="detector"){s.fillStyle="#142630",s.fillRect(0,0,r,a);const p=135,g=r/2,v=a/2;s.strokeStyle="#42616a",s.beginPath(),s.arc(g,v,p,0,Math.PI*2),s.stroke();for(const m of t.rows)n!=="all"&&m.element!==n||(s.fillStyle=er[m.element].color,s.fillRect(g+m.hitX*p,v-m.hitY*p,2,2));s.fillStyle="#d9e7e9",s.fillText("검출 XY · 정규화 −1…1",20,28),s.fillText("같은 이벤트의 도착 위치",20,a-16);return}const o=Array(280).fill(0);for(const p of t.rows)(n==="all"||p.element===n)&&o[Math.min(279,Math.round(p.massToCharge*4))]++;const c=Math.max(1,...o),l=55,u=35,f=r-75,d=a-90;s.strokeStyle="#dce6e8",s.fillStyle="#4c6975";for(let p=0;p<=4;p++){const g=Math.round(c*p/4),v=u+d*(1-p/4);s.beginPath(),s.moveTo(l,v),s.lineTo(l+f,v),s.stroke(),s.fillText(String(g),5,v+5)}s.strokeStyle="#338d86",s.lineWidth=2,s.beginPath(),o.forEach((p,g)=>{const v=l+g/280*f,m=u+d*(1-p/c);g===0?s.moveTo(v,m):s.lineTo(v,m)}),s.stroke(),s.fillStyle="#4c6975";for(const p of[0,10,20,30,40,50,60,70])s.fillText(String(p),l+p/70*f-7,a-30);s.fillText("Counts · 취득 이벤트",l,22),s.fillText("m/z · Da/e",r/2-40,a-6),t.index||(s.fillStyle="#789197",s.fillText("취득을 시작하면 이벤트가 누적됩니다.",75,a/2))}const Ec=[.1,.25,.5,1,2];class Ug{constructor(t=.25){this.setRate(t),this.previous=null,this.elapsed=0,this.realDelta=0}setRate(t){if(!Ec.includes(t))throw new RangeError("Unsupported playback rate");this.rate=t}resetTimestamp(){this.previous=null,this.realDelta=0}step(t){if(!Number.isFinite(t))return 0;this.realDelta=this.previous===null?0:Math.min(.1,Math.max(0,(t-this.previous)/1e3)),this.previous=t;const e=this.realDelta*this.rate;return this.elapsed+=e*1e3,e}}const ie=(i,t,e,n,s,r,a,o,c)=>({id:i,name:t,parts:e,transform:n,appearance:s,cause:r,checks:a,confound:o,only:c}),Hr={afm:[ie("double-tip","이중 팁처럼 보이는 복제 형상",["probe"],"double","돌출부가 옆으로 복제되어 보이고 폭이 커집니다.","여러 접촉점이 서로 다른 위치의 표면을 읽는 상황을 두 번째 이동 영상과의 최대값으로 근사합니다.","Trace/Retrace·주사 방향과 기준 패턴을 비교한 뒤 승인된 절차로 팁을 점검합니다.","시료에 실제 반복 패턴이 있어도 비슷하게 보일 수 있습니다."),ie("vibration","주기 외란·라인 줄무늬",["base","controller"],"stripes","높이맵에 수평 띠와 가짜 높이 변화가 생깁니다.","취득 라인에 따라 반복되는 합성 높이 오프셋을 더합니다. 실제 공진/PID 계산은 아닙니다.","진동·기류·시료 고정·케이블을 확인하고 왕복 프로파일과 기준 위치를 비교합니다.","실제 표면 단차·피드백 추종 지연도 줄무늬처럼 보일 수 있습니다.")],apt:[ie("tof-zero","TOF 영점 오차",["pulser","flight","detector"],"apt-time","질량 피크 위치가 달라져 잘못된 이온종 판독을 유도할 수 있습니다.","같은 취득 이온의 TOF에 가상 양의 지연을 더하고 동일 이상식 m/z∝t²로 다시 계산합니다.","시간 영점·전압/경로 가정과 기준 피크를 확인합니다. 원자료와 교정 이력을 보존합니다.","전하 상태·중첩·분자 이온도 피크 해석을 바꾸므로 한 피크로 단정하지 않습니다."),ie("hit-loss","검출 위치 의존 이벤트 누락",["detector"],"apt-loss","히스토그램 계수가 줄고 원소 비율도 달라 보일 수 있습니다.","검출 원판의 한 영역에서 일부 이벤트를 결정적으로 제외하는 검출 효율 예시입니다. 원본 이벤트는 보존합니다.","히트맵·검출기 응답·다중 히트·측정 조건을 함께 비교합니다.","이온 증발률·실제 시료 분포 변화와 구분해야 합니다.")],fib:[ie("curtaining","Curtaining 유사 세로 줄무늬",["ion","sample"],"curtain","취득 SEM 영상에 세로 띠가 나타나 단면 구조처럼 보입니다.","불균일 제거가 영상에 남기는 모양을 열 방향 강도 편차로만 근사합니다. 실제 가공 형상을 다시 계산하지 않습니다.","재료 차이·표면 상태·가공 이력과 기준 단면을 비교합니다.","실제 적층·검출기 음영·주사 잡음도 줄무늬를 만들 수 있습니다."),ie("fib-focus","전자 영상 초점 저하",["electron","detector"],"blur","미세 경계가 퍼지고 작은 구조의 대비가 감소합니다.","취득 영상의 이웃 픽셀을 평균해 공간 분해능 저하를 표현합니다.","기준 시료에서 초점·비점·작업 거리·충전을 구분합니다.","시료 손상·진동·오염을 초점 문제로 오인하지 않습니다.")],ftir:[ie("background-mismatch","배경 불일치·가짜 음의 밴드",["source","sample","control"],"ftir-background","원래 없던 양/음의 밴드와 기울어진 기준선이 생깁니다.","A′=A+log₁₀(Bwrong/Btrue)에 해당하는 가상 배경 비 오차를 적용합니다. 정규화된 교육 예시이며 실제 대기 보정식은 아닙니다.","동일 액세서리·퍼지·시점의 새 배경과 비교합니다. 음의 피크를 곧바로 물질 신호로 해석하지 않습니다.","실제 방출·위상·기준선 처리도 음의 특징을 만들 수 있습니다."),ie("weak-contact","약한 투과 흡수·ATR 접촉 응답",["sample"],"attenuate","밴드 위치는 같지만 흡광도 크기가 작아집니다.","유효 광학 두께/접촉 가중치가 감소한 모습을 흡광도 배율로 근사합니다.","시료 두께 또는 ATR 접촉·결정 상태와 동일 조건 기준 시료를 비교합니다.","성분 함량·밴드 세기 차이도 같은 형태를 만들 수 있습니다.")],nanoindenter:[ie("thermal-drift","열 드리프트 유사 깊이 이동",["optics","base"],"depth-drift","시간이 지날수록 곡선이 깊이 방향으로 밀리고 잔류 깊이가 달라 보입니다.","측정 깊이에 시간에 비례하는 오프셋을 더합니다. 실제 크리프나 열 모델은 아니며 정상 물성 계산은 바꾸지 않습니다.","온도 안정화·변위 영점·드리프트 기록·기준 재료를 비교합니다.","실제 크리프·프레임 컴플라이언스·표면 검출 오차와 구분합니다."),ie("force-zero","하중 영점 오프셋",["source","control"],"force-offset","비접촉·제하 끝에서도 가짜 하중이 남습니다.","실제 인가 하중이 아니라 기록된 하중 채널에 일정 오프셋을 더하는 예시입니다.","하중 영점·표면 검출·힘 센서 교정 이력을 확인합니다.","접착력·잔류 접촉과 전기적 영점 문제를 혼동하지 않습니다.")],raman:[ie("fluorescence","형광 유사 넓은 배경",["source","sample","detector"],"fluorescence","스펙트럼 기준선이 올라가 피크가 묻히거나 맵 대비가 줄어듭니다.","넓은 양의 배경을 더합니다. 실제 형광 수명·선량·온도 계산이 아닙니다.","여기 파장·암신호·포화·기준 시료·시료 손상을 비교합니다.","오염·검출기 배경·우주선 신호도 별도로 검토합니다."),ie("raman-axis","파수축 교정 오차",["detector","source"],"axis-shift","피크가 같은 방향으로 이동해 응력/조성 변화처럼 보일 수 있습니다.","기록된 Raman shift 축에 확대된 합성 영점 오차를 더합니다.","기준 밴드·레이저 파장·분광축 교정 이력을 확인합니다.","실제 온도·응력·조성 변화에 의한 이동과 구분합니다.","spectrum")],sam:[ie("coupling","결합 불량 유사 신호 약화",["probe","tank","receiver"],"attenuate","RF 에코나 반사/투과 영상이 함께 약해져 결함처럼 보일 수 있습니다.","가상 결합 효율을 낮추는 신호 배율입니다. 새로운 박리/보이드를 시료에 추가하지 않습니다.","전면 에코·기준 위치·기포·수침 결합과 수신기 정렬을 비교합니다.","깊은 층의 실제 감쇠·음향 그림자도 신호를 줄입니다."),ie("rf-noise","수신 배경·RF 잡음",["pulser","control"],"noise","RF 파형의 기준선과 영상에 불규칙한 무늬가 추가됩니다.","결정적 의사 잡음/배경을 더합니다. 실제 전자계 잡음 통계나 다중반사 모델은 아닙니다.","케이블·수신 포화·게인·기준 RF와 반복 취득을 확인합니다.","실제 계면 반사·회절·수중 움직임과 구분합니다.")],sem:[ie("sem-focus","초점·공간 분해능 저하",["objective","condenser"],"blur","경계가 퍼지고 작은 입자가 사라진 것처럼 보입니다.","취득 픽셀의 이웃 평균으로 초점 저하를 근사합니다. 실제 전자 광학 계산은 아닙니다.","기준 시료에서 초점·비점·작업 거리·진동을 비교합니다.","원래 둥근 구조나 오염도 부드러운 경계를 만들 수 있습니다."),ie("charging","Charging 유사 밝기 띠",["sample","scan","se"],"charging","수평 밝기 편차·국소 포화가 구조 대비처럼 보입니다.","전하가 검출 효율과 주사에 영향을 주는 현상을 합성 라인 오프셋과 클리핑으로만 표현합니다.","시간/주사 조건·도전 경로·기준 위치·SE/BSE 차이를 비교합니다.","재료 대비·검출기 음영·전자계 잡음도 유사합니다.")],sims:[ie("mass-axis","질량축 교정 오차",["analyzer","detector"],"mass-shift","선택 피크의 명목 m/z가 달라 보입니다.","ToF에서는 시간 영점, M-SIMS에서는 자장 영점 오차에 해당하는 √(m/z) 축 오프셋을 개념적으로 적용합니다.","기준 질량·전하 상태·극성·에너지 조건과 교정 기록을 확인합니다.","동질량 간섭·분자 이온을 교정 오차로 단정하지 않습니다.","spectrum"),ie("ion-yield","이차이온 감도/수율 변화",["source","sample","lens"],"attenuate","스펙트럼·깊이·맵의 세기가 줄어 농도가 감소한 것처럼 보입니다.","수율·추출/검출 효율의 영향을 하나의 가상 배율로만 근사합니다. 정량 매트릭스 모델이 아닙니다.","기준 재료·1차 빔·매트릭스·추출 조건과 기준 이온을 비교합니다.","실제 농도·스퍼터 속도 변화도 별도 확인해야 합니다.")],tem:[ie("tem-resolution","결상/분광 분해능 저하",["objective","aperture","eels"],"blur","영상 경계·회절점 또는 EELS 피크가 퍼집니다.","영상은 이웃 픽셀 평균, EELS는 인접 에너지 채널 평균입니다. 후자는 단순한 영상 초점이 아닌 분광 분해능 예시입니다.","영상 모드의 초점/비점과 분광 모드의 영점/에너지 분해능을 구분해 기준 시료와 비교합니다.","시료 두께·오염·비탄성 산란도 대비와 피크 폭을 바꿉니다."),ie("detector-background","검출 배경 증가",["detector","gun"],"noise","미세 영상 대비나 약한 EELS edge가 배경에 묻힙니다.","검출 채널에 합성 배경/의사 잡음을 추가합니다. 산란 단면적·계수 통계 계산은 아닙니다.","암신호·포화·노출·빔 안정성과 기준 취득을 비교합니다.","실제 확산 산란이나 시료 변화도 배경을 높일 수 있습니다.")],xps:[ie("charge-shift","대전 유사 피크 이동·퍼짐",["neutralizer","sample","analyzer"],"xps-charge","피크가 높은 결합 에너지로 이동하고 넓어집니다.","기록된 결합 에너지 축에 양의 이동을 더하고 이웃 채널 평균을 적용합니다. 균일/차등 대전의 정량 계산은 아닙니다.","중화·시료 접지·기준 신호·교정과 시간 변화를 비교합니다.","실제 화학 상태 이동과 대전을 반드시 구분합니다.","energy"),ie("xps-background","신호 감도 저하·배경 증가",["lens","detector","source"],"low-snr","피크/깊이 응답의 대비가 낮아지고 기준선이 올라갑니다.","취득 응답을 줄이고 양의 배경을 추가합니다. 깊이 값이나 시료 조성을 바꾸지 않습니다.","기준 시료·수집 렌즈·검출기·광원과 포화를 확인합니다.","실제 표면 오염·기판 감쇠·제거 손상도 세기를 바꿉니다.")],xrd:[ie("angle-zero","각도 영점 오차",["goniometer","sample"],"axis-shift","회절 피크 또는 XRR 임계 영역이 각도 축에서 이동합니다.","기록 각도에 합성 일정 오프셋을 더합니다. 시료 변위의 각도 의존성이나 실제 격자 변화를 계산하지 않습니다.","기준 시료·각도 영점·시료 높이·정렬과 측정 기하를 확인합니다.","실제 격자 간격·응력 변화도 피크 위치를 바꿉니다."),ie("xrd-background","검출 배경·산란 증가",["detector","optics"],"background","약한 피크·XRR 진동이 배경에 묻힙니다.","각도별 응답에 양의 배경을 더합니다. XRR에서는 로그 축으로 미약한 진동의 소실을 비교합니다.","빈 홀더·슬릿·주변 산란·검출기 배경과 기준 데이터를 비교합니다.","실제 거칠기·두께 분포도 XRR 진동을 줄일 수 있습니다.")],xrm:[ie("detector-column","검출 열 편차·CT 링 아티팩트",["detector","control"],"xrm-column","투영 열 편차가 누적되어 CT에 링/호가 나타납니다.","같은 취득 투영의 한 고정 검출 열에 로그 응답 편차를 주고 FBP를 다시 계산합니다. 단면에 링 그림을 덧씌우지 않습니다.","플랫/다크·불량 픽셀·검출 응답과 원시 sinogram을 비교합니다.","실제 원형 구조·빔 경화·회전 중심 오차도 함께 검토합니다."),ie("rotation-center","회전 중심 오차",["stage","control"],"xrm-center","CT 경계가 이중화되거나 줄무늬/호가 생깁니다.","검출 위치가 일정하게 어긋난 투영을 사용해 같은 FBP를 다시 계산합니다. Radiography에서는 위치 어긋남만 표시합니다.","회전 중심·홀더 고정·정렬과 기준 투영을 비교합니다.","실제 시료 움직임·각도 부족도 경계를 흐릴 수 있습니다.")],afmir:[ie("contact-response","접촉 응답 저하",["probe","detector","source"],"attenuate","IR 응답이 약해져 비흡수 영역처럼 보일 수 있습니다.","화학 구조를 바꾸지 않고 접촉/열/검출 응답의 영향을 가상 배율로 표현합니다.","접촉 상태·광학 레버·IR 조사·출력 정규화와 기준 재료를 비교합니다.","실제 흡수·두께 차이도 같은 결과를 만들 수 있습니다."),ie("height-crosstalk","지형–화학 응답 교차 영향",["piezo","probe","sample"],"height-cross","화학 맵에 높이 패턴이 섞여 가짜 도메인이 보입니다.","같은 위치의 합성 지형 채널 일부를 IR 응답에 섞습니다. 실제 열/접촉 역학의 예측 모델은 아닙니다.","높이·다른 파수·접촉 안정성·두께를 비교해 화학 대비와 구분합니다.","실제 화학 도메인과 지형이 함께 존재할 수도 있습니다.","map")]};function yc(i,t){return!i||!t?!1:i.only==="spectrum"?t.shape==="curve"&&t.mode==="spectrum":i.only==="energy"?t.shape==="curve"&&["survey","highres"].includes(t.mode):i.only==="map"?t.shape==="grid"&&t.mode==="map":!0}const xt=(i,t,e,n,s)=>({input:i,output:t,mechanism:e,signature:n,checks:s}),Ng={afm:"표면/XY 이동 → 팁 휨 → 광학 레버·검출기 → 오차 → Z 추종 → 높이",apt:"DC 바이어스·펄스 → 전계 증발 → 이온 비행 → TOF/검출 XY → 질량·개념 점군",fib:"이온빔 → 가공 / 전자빔 → SE 검출 → 가공 시점의 영상",ftir:"광대역 IR → 두 팔 광로차 → 시료·간섭신호 → DFT → 샘플/배경 비",nanoindenter:"하중 명령 → 팁 접촉 → 힘/변위 읽기 → 제하 곡선·면적 → 물성 예시",raman:"여기 레이저 → 산란 → Rayleigh 제거 → 분광·CCD 적분 → 스펙트럼/맵",sam:"전기 펄스 → 음향 송신 → 반사/투과 → 수신 RF → 시간 게이트/XY 영상",sem:"전자빔 → 편향·집속 → 시료 상호작용 → SE/BSE → XY 픽셀",sims:"1차 이온 → 스퍼터/이온화 → 추출 → ToF 또는 ESA/자기 섹터 → 이차이온 신호",tem:"전자총 → 집속·얇은 시료 → 결상/회절 또는 STEM/EELS 검출 → 모드별 데이터",xps:"X선 → 광전자 → 렌즈·에너지 분석 → 전자 검출 → 결합 에너지 스펙트럼",xrd:"X선·입사 기하 → 산란/반사 → 각도 동기 검출 → 회절/XRR 곡선",xrm:"X선 노출 → 흡수·투과 → 검출 열/투영 → 로그 변환 → CT 필터 역투영",afmir:"IR 펄스 → 열팽창 → 접촉 캔틸레버 진동 → 별도 광학 읽기 → IR 응답"},Fg={afm:[["AFM 아티팩트 원리","https://afmhelp.com/index.php?Itemid=55&id=54%3Aartifacts&option=com_content&view=article"]],apt:[["CAMECA · APT 원리","https://www.cameca.com/Products/APT/Introduction-to-APT"]],fib:[["Thermo Fisher · FIB-SEM 아티팩트","https://www.thermofisher.com/us/en/home/materials-science/learning-center/fib-sem-industrial-scientific-applications/articles/common-fib-sem-challenges-solutions.html"]],ftir:[["Thermo Fisher · FTIR 배경/아티팩트","https://www.thermofisher.com/us/en/home/industrial/spectroscopy-elemental-isotope-analysis/molecular-spectroscopy/fourier-transform-infrared-spectroscopy/faqs.html"],["Shimadzu · Fourier 변환과 배경","https://www.ssi.shimadzu.com/service-support/technical-support/analysis-basics/tips-ftir/apodization.html"]],nanoindenter:[["Oliver–Pharr 원 논문","https://web.mit.edu/cortiz/www/3.052/3.052CourseReader/45_OliverPharr1992Nanoindentation.pdf"],["열 드리프트 연구","https://www.frontiersin.org/journals/materials/articles/10.3389/fmats.2022.900088/full"]],raman:[["HORIBA · Raman 광학/검출","https://www.horiba.com/int/scientific/technologies/raman-imaging-and-spectroscopy/raman-spectrometer-presentation/"],["HORIBA · 교정","https://www.horiba.com/ind/scientific/technologies/raman-imaging-and-spectroscopy/raman-explained-faq/how-do-you-perform-good-calibration-on-a-raman-system/"]],sam:[["PVA TePla · 음향 현미경","https://www.pvatepla.com/products-technologies/faq-sam/"]],sem:[["JEOL · Charging","https://www.jeol.com/words/semterms/20121024.054158.php"]],sims:[["NIST · SIMS 매트릭스 효과","https://www.nist.gov/publications/secondary-ion-yield-matrix-effects-sims-depth-profiles-sige-multilayers"]],tem:[["JEOL · STEM 원리","https://www.jeol.com/words/emterms/20121023.055058.php"]],xps:[["Thermo Fisher · XPS 대전","https://www.thermofisher.com/us/en/home/materials-science/learning-center/surface-analysis/charge-compensation.html"]],xrd:[["Rigaku · XRR 원리","https://rigaku.com/resources/techniques/x-ray-reflectometry-xrr"]],xrm:[["Fraunhofer · CT 링 아티팩트","https://www.iis.fraunhofer.de/en/ff/zfp/tech/basics_ct/Artifacts.html"]],afmir:[["Bruker · photothermal AFM-IR","https://www.bruker.com/en/products-and-solutions/infrared-and-raman/nanoscale-infrared-spectrometers/re-afm-ir.html"]]},ti={afm:{probe:xt("팁–표면 상호작용과 평균 접촉 위치","캔틸레버 휨·반사 광점 변화","유한한 팁 형상으로 표면을 읽으므로 높이와 측면 형상 해석은 다릅니다. 이 모델은 실제 접촉역학·팁 형상을 계산하지 않습니다.","이중 형상·폭 증가·Trace/Retrace 불일치.","기준 패턴·주사 방향을 비교하고 접촉 해제 후 팁을 점검합니다."),detector:xt("캔틸레버에서 반사된 가시광","차동/합 신호·정규화 휨 읽기","차동 신호는 휨 변화, 합 신호는 수광 상태를 살피는 기준입니다. 차동값만으로 광점이 잘 맞았다고 판단하지 않습니다.","합 신호 저하·광점 이탈·포화·불안정한 오차.","수광량·정렬·광점과 시료 접촉 전후 기준을 확인합니다."),piezo:xt("오차에 따른 Z 보정 명령","Z 위치와 높이 데이터","고정 XY 프로브 아래로 스테이지가 움직이고 Z 스캐너가 평균 접촉을 추종합니다. 출력 높이는 실제 표면과 추종 오차를 구분해야 합니다.","높이 포화·줄무늬·왕복 지연.","Z 범위·속도/이득·오차 신호를 함께 비교합니다."),controller:xt("설정값·정규화 휨/오차","Z 보정·XY와 동기화한 저장","제어 목표와 측정된 휨의 차이를 줄입니다. 본 모델은 1차 추종으로 실제 PID 발진·공진을 예측하지 않습니다.","오차 증가·추종 지연·조건에 따른 영상 변화.","속도·이득·Z 범위·왕복 프로파일과 기준 시료를 비교합니다.")},apt:{tip:xt("높은 정전계와 레이저/전압 펄스","전계 증발한 이온","표면 원자가 이온으로 방출되고 이후에도 비행합니다. 실제 펄스의 무검출·다중 히트·지연/배경 증발은 교육 모델 범위 밖입니다.","이벤트율·질량 피크·조성/깊이 변화.","팁 형상·시료 준비·펄스/전압 이력과 검출 데이터를 함께 검토합니다."),pulser:xt("정전 바이어스·트리거","시간 기준이 있는 펄스 입력","펄스는 증발 유도와 TOF 시간 원점에 관련됩니다. 화면의 대표 주기와 실제 펄스율/ns는 동일하지 않습니다.","TOF 영점 불일치·피크 이동.","시간 기준·모드·전압 가정과 교정 이력을 확인합니다."),flight:xt("방출된 이온의 에너지·m/z","검출 도착 시간","직선 이상식 t=L√[(m/z)u/(2eV)]를 사용합니다. 실제 광학 경로·에너지 분산·reflectron 보정은 구현하지 않습니다.","피크 위치/폭의 변화·질량 해석 불일치.","길이·전압·영점·전하 상태 가정을 구분합니다."),detector:xt("비행 경로를 지난 개별 이온의 도착","동일 이벤트의 시간과 XY 히트","시간으로 질량을, 위치로 개념 재구성 좌표를 만듭니다. 누락 이벤트는 되돌릴 수 없으며 검출 효율이 조성 해석에 영향을 줄 수 있습니다.","히트맵 편차·검출 누락·다중 히트 응답.","전체 히트 분포·효율·시간/위치 교정과 기준 피크를 비교합니다.")},fib:{ion:xt("이온 생성·가속·편향 명령","국소 스퍼터 제거","가공은 시료를 바꾸는 입력입니다. 재료·지형에 따른 제거 차이를 실제 단면 구조와 혼동하지 않아야 합니다.","Curtaining·재증착·가공 균일도 저하.","가공 이력·시료 재료·표면 상태를 먼저 비교합니다."),electron:xt("전자빔·주사 조건","시료에서 방출된 영상 신호","전자 컬럼의 관찰과 이온 컬럼의 가공은 구분됩니다. 이전 SEM 영상은 현재 가공면의 실시간 상태가 아닐 수 있습니다.","흐림·비점·충전 대비.","영상 취득 시 가공 깊이·초점·작업 거리와 기준 시료를 확인합니다."),detector:xt("시료 방출 이차전자","동기화된 영상 픽셀","빔이 어느 위치를 조사했는지와 신호를 짝지어 영상으로 저장합니다. 밝기만으로 재료 종류나 단면 높이를 정량하지 않습니다.","약한 신호·포화·음영·줄무늬.","선택 검출기·표시 범위·기준 영상과 빔 상태를 비교합니다.")},ftir:{splitter:xt("광대역 IR","고정·이동 거울의 두 팔과 재결합 광","여러 파수 성분이 함께 간섭합니다. 파수를 하나씩 선택해 읽는 분산형 스캔과 다릅니다.","간섭 대비 저하·중심 버스트 이상.","광학 범위·정렬·광원·습기 영향과 기준 간섭신호를 확인합니다."),moving:xt("거울 스캔 명령","시간에 따른 광로차(OPD)","왕복 광학 경로이므로 OPD 변화는 거울 이동의 두 배입니다. 광로차별 합성 신호를 취득한 뒤 DFT를 수행합니다.","파형 왜곡·반복성 저하·스캔 이상.","위치 기준·구동·진동과 간섭신호 반복성을 비교합니다."),sample:xt("간섭계에서 나온 IR·투과 시료 또는 ATR 접촉","시료에 의해 가중된 간섭 신호","투과는 경로의 흡수, ATR은 표면 접촉과 파수 의존 응답에 민감합니다. 두 액세서리의 배경을 섞어 쓰지 않습니다.","밴드 크기 변화·가짜 양/음의 특징.","동일 액세서리의 새 배경·두께/접촉·오염·퍼지를 확인합니다."),detector:xt("시료를 거친 광대역 간섭 광","광로차별 한 신호 값","먼저 간섭신호를 측정하고 변환한 샘플/배경 스펙트럼 비로 T와 A를 계산합니다. 흡광도는 원시 검출 전압 자체가 아닙니다.","포화·약한 버스트·배경 불일치.","원시 간섭신호·변환 결과·배경·포화를 단계별로 비교합니다.")},nanoindenter:{source:xt("하중 이력 명령","팁에 전달되는 힘","인가 하중과 센서가 기록한 하중을 구분합니다. 영점 오차는 접촉 전이나 제하 뒤에도 가짜 하중을 남길 수 있습니다.","하중 기준선 이동·재현성 저하.","영점·기준 재료·프레임 교정·표면 검출을 확인합니다."),optics:xt("팁/변위계의 위치 변화","압입 깊이 기록","변위 센서의 읽기에는 압입 외에 드리프트·프레임 변형·표면 검출 오차가 섞일 수 있습니다. 도식은 특정 센서 방식의 CAD가 아닙니다.","시간 의존 깊이 이동·잔류 깊이 편차.","열 안정화·드리프트 기록·접촉 기준과 기준 시료를 비교합니다."),probe:xt("하중·표면 접촉","접촉 면적과 하중–변위 응답","팁 면적 함수는 H와 Eᵣ 계산의 핵심입니다. 이상적 A=24.5h_c²는 마모·라운딩·pile-up을 자동 보정하지 않습니다.","동일 하중의 깊이/경도 편차.","면적 함수 교정·팁 상태·압흔 간격·기판 영향을 검토합니다.")},raman:{source:xt("선택 여기 파장·빛","시료의 탄성/비탄성 산란","레이저 파장은 검출 광 파장과 세기에 관련되지만 동일 진동 모드의 Raman shift 자체와는 구분합니다.","형광·시료 손상·강도/파장 불안정.","기준 시료·여기 파장·출력 안정성·포화를 비교합니다."),filter:xt("강한 Rayleigh와 약한 Raman 산란","레이저 선이 억제된 분광 입력","Rayleigh를 제거해야 약한 Stokes 신호를 읽기 쉽습니다. 필터 종류에 따라 관찰 가능한 shift 범위가 달라집니다.","레이저 선 누설·저파수 신호 소실.","레이저 파장과 필터 대응·정렬·기준 스펙트럼을 확인합니다."),detector:xt("격자로 분산된 산란광","여러 shift 채널의 누적 신호","이 모델은 CCD 전 채널을 동시에 적분합니다. 축 교정과 암신호/형광 배경을 구분해야 작은 피크 이동을 해석할 수 있습니다.","피크 공통 이동·넓은 배경·포화.","기준 밴드·분광축·암신호·초점과 여기 조건을 비교합니다.")},sam:{probe:xt("전기 송신 펄스·수침 결합","음향 펄스와 pulse-echo 수신 RF","같은 탐촉자가 송신/반사 수신을 담당할 수 있습니다. 전면 에코를 기준으로 물 경로와 시료 내부 시간을 구분합니다.","전면/하부 에코 약화·파형 변화.","기준 위치·초점·기포·케이블·수신 포화를 확인합니다."),tank:xt("탐촉자·결합수·시료 배치","음향 전달 경로","결합 상태가 나빠지면 진짜 내부 결함이 없어도 신호가 약해집니다. 깊은 층의 음향 그림자도 함께 검토합니다.","전체 신호 저하·시간/위치 변화.","수침 적합성·수질·기포·수위·온도와 전면 에코를 비교합니다."),control:xt("수신 RF·좌표·시간 기준","게이트 피크와 A/B/C/Through 영상","게이트는 기록 파형의 시간창이지 물리 반사면이 아닙니다. Through는 별도 하부 수신기와 편도 경로를 사용합니다.","게이트 위치에 따른 영상 변화·잘못된 깊이 해석.","원래 RF·전면 영점·음속 가정·게이트 폭/채널을 함께 확인합니다.")},sem:{objective:xt("렌즈에 입사하는 전자빔","시료 표면의 집속 프로브","초점/비점/작업 거리는 경계와 미세 구조의 전달에 영향을 줍니다. 부드러운 경계를 곧바로 실제 표면 모양으로 해석하지 않습니다.","경계 퍼짐·방향성 흐림.","기준 시료·초점/비점·진동과 시료 충전을 분리해 확인합니다."),sample:xt("주사 전자빔·시료 고정/도전 경로","SE/BSE·축적 전하","충전은 방출 신호의 검출 효율과 빔 경로를 바꿀 수 있습니다. 밝기 변화가 언제나 재료 대비를 의미하지 않습니다.","밝고 어두운 띠·국소 포화·시간 의존 이동.","도전 경로·시간/주사 조건·SE/BSE·기준 위치를 비교합니다."),se:xt("저에너지 이차전자","표면/지형 민감 영상 신호","방출 전자와 수집 기하에 따라 신호가 달라집니다. 도체/비도체와 충전 상태에 의한 대비도 포함될 수 있습니다.","음영·약한 신호·충전 대비.","검출기·포화·시료 기하와 BSE 기준을 비교합니다."),bse:xt("후방산란 전자","재료·기하에 의존하는 영상 신호","SE와 다른 상호작용/수집 경로를 사용합니다. 조성 대비 외에도 표면 기하와 측정 조건의 영향을 받습니다.","검출 위치 편차·비정상 대비.","SE와 같은 영역을 비교하고 검출 조건·시료 배치를 확인합니다.")},sims:{source:xt("1차 이온 조사","스퍼터된 중성/이온 입자","검출되는 것은 방출 입자 중 이온화되고 수집된 일부입니다. M-SIMS는 연속, ToF 분석은 펄스 입력을 구분합니다.","신호 감도·제거/분석 응답 변화.","방식·극성·빔 조건·기준 재료와 손상 이력을 비교합니다."),analyzer:xt("추출된 이차이온","m/z별 분리된 검출 신호","ToF는 비행시간, M-SIMS는 에너지 필터와 자기 섹터로 구분합니다. 같은 명목 질량에도 분자/동질량 간섭이 가능합니다.","질량축 이동·분리/투과 변화.","방식별 기준 질량·극성·에너지/시간/자장 교정 이력을 확인합니다."),sample:xt("1차 이온·시료 매트릭스","이차이온 수율과 깊이/위치 응답","신호는 농도뿐 아니라 매트릭스·스퍼터·이온화·추출에 의존합니다. a.u. 프로파일을 곧바로 원자 농도로 읽지 않습니다.","실제 층 변화처럼 보이는 강도 변화.","기준 재료·선택 이온·매트릭스·명목 깊이 보정을 구분합니다.")},tem:{objective:xt("얇은 시료를 지난 전자","영상/회절 형성에 쓰이는 전자파","BF·DF·회절은 선택하는 전자 성분과 영상 평면이 다릅니다. 초점·비점·두께·시료 방향 영향을 분리합니다.","흐림·대비 변화·회절점 퍼짐.","모드·조리개·기준 시료·정렬/초점을 비교합니다."),aperture:xt("직진/산란 전자의 각도 분포","선택된 전자 성분","DF에서는 선택 회절파를, BF에서는 주로 직접 빔 성분을 사용합니다. 조리개 선택 변화는 고장 없이도 대비를 바꿉니다.","갑작스러운 밝기/영역 대비 변화.","모드·선택 회절파·조리개 위치·시료 방향을 확인합니다."),eels:xt("투과 전자의 에너지 분포","에너지 손실 스펙트럼","ZLP·저손실·edge를 구분합니다. 에너지 영점/분해능과 결상 초점은 동일한 문제가 아닙니다. 모델 edge는 원소 동정이 아닙니다.","ZLP 이동/퍼짐·배경 증가·약한 edge 소실.","영점·에너지 교정·두께·암신호·노출을 비교합니다.")},xps:{neutralizer:xt("시료 대전 상태와 보상 입력","광전자 방출 중 전하 균형","중화는 대전 영향을 줄이지만 잘못된 기준 참조를 자동으로 해결하지 않습니다. 피크 이동을 화학 상태 변화와 구분합니다.","공통/비균일 피크 이동·퍼짐.","시료 접지·중화·기준 신호·시간 변화와 교정 이력을 확인합니다."),analyzer:xt("수집·감속된 광전자","에너지별 전자 신호","패스 에너지·렌즈·분석 기하는 투과와 에너지 분해능에 관련됩니다. Survey/Narrow와 깊이 응답의 축을 혼동하지 않습니다.","피크 위치/폭·세기 변화.","에너지 기준·패스 에너지·렌즈 조건·대전을 분리해 확인합니다."),sputter:xt("깊이 제거 이온빔","분석 전 새 가상 표면","최초 표면을 분석한 뒤 제거/분석을 교대합니다. 명목 깊이는 제거율 교정 없이 실제 깊이 또는 조성과 같지 않습니다.","프로파일 이동·손상·층 대비 변화.","제거 이력·교정·혼합/거칠기·선택적 제거와 기준 재료를 검토합니다.")},xrd:{goniometer:xt("입사/검출 각도 명령","측정 기하와 기록 각도","In/Out/XRR에서 기준 각도와 산란 벡터가 다릅니다. 기하 오차와 실제 격자/표면 변화를 분리해야 합니다.","모든 피크의 공통 이동·반사 영역 변화.","기준 시료·각도 영점·시료 높이·측정 기하를 비교합니다."),optics:xt("광원에서 나온 X선","정렬·각도/폭이 정해진 입사 빔","슬릿/광학 조건은 조사 면적·발산·배경과 관련됩니다. 시료 밖 산란도 검출 강도에 포함될 수 있습니다.","배경 상승·피크 폭/세기 변화.","정렬·슬릿·빈 홀더·기준 시료를 확인합니다."),detector:xt("산란/반사 X선","각도별 강도","신호와 배경·포화를 구분합니다. 약한 XRR 진동은 로그 축에서 배경과 함께 살펴야 합니다.","미약한 피크/진동 소실·기준선 변화.","검출 범위·배경·포화·기준 취득을 비교합니다.")},xrm:{stage:xt("회전 각도·시료 고정","각도별 같은 단면의 투영","정지 노출 전 각도를 이동합니다. 잘못된 회전 중심 가정은 동일한 투영도 잘못 재구성하게 만듭니다.","CT 경계 이중화·호·줄무늬.","회전 중심·흔들림·시료 고정과 원시 투영을 비교합니다."),detector:xt("시료를 통과한 X선","I/I₀ 투과율·검출 열 신호","고정 검출 열의 응답 편차는 여러 투영에 반복됩니다. CT에서 링으로 나타날 수 있어 단면만이 아니라 sinogram도 확인합니다.","고정 열 편차·링/호 아티팩트.","플랫/다크·불량 픽셀·포화·원시 투영을 확인합니다."),control:xt("각도·투과율·회전 중심 가정","로그 투영과 FBP 단면","정답 팬텀을 표시하는 것이 아니라 취득한 투영에서 단면을 계산합니다. 현재 모델은 2D 평행빔이며 실제 3D/위상 대비 CT가 아닙니다.","각도 부족 줄무늬·부정확한 형상.","각도 수·중심·필터·보정과 재구성 전 데이터를 비교합니다.")},afmir:{source:xt("선택 IR 파수·펄스","시료의 흡수·국소 열팽창","IR 펄스가 꺼진 뒤에도 열·기계 응답이 남습니다. 실제 펄스율/열 확산을 화면 시간과 동일시하지 않습니다.","진동 응답 약화·파수별 세기 변화.","IR 파수·조사 위치·출력 정규화·동기와 기준 재료를 확인합니다."),probe:xt("접촉 시료의 열팽창","캔틸레버 진동","진동은 화학 흡수뿐 아니라 접촉·기계·열·두께 영향도 포함합니다. 신호를 곧바로 흡수 계수나 농도로 읽지 않습니다.","국소 응답 소실·기계 대비·재현성 저하.","접촉 안정성·팁·기준 시료·높이/다른 파수의 맵을 비교합니다."),detector:xt("별도 가시광 레이저의 반사 광점","진동/평균 휨 읽기","IR 광자를 직접 세는 검출 경로가 아닙니다. 평균 접촉을 위한 Z 추종과 빠른 광열 진동을 구분합니다.","수광량 저하·진동 배경·지형 교차 영향.","광학 레버 정렬·수광량·동기와 접촉 상태를 비교합니다.")}};Object.assign(ti.afm,{laser:xt("가시광 광원과 입사 정렬","캔틸레버 뒷면에서 반사되는 광점","레이저는 표면 높이를 직접 측정하지 않고 광학 레버를 읽습니다. 팁 접촉 전에도 정렬용 빛이 켜져 있을 수 있습니다.","SUM 저하·반사점 이탈·휨 신호 잡음.","시료 접근과 분리해 기준 광점·수광량·오염을 승인된 정렬 절차로 확인합니다."),sample:xt("XY 래스터 이동 명령·고정 시료","팁 아래를 지나는 시료 좌표","이 모델에서 XY는 시료 스테이지가, Z 추종은 스캐너가 담당합니다. Trace와 Retrace는 같은 Y 라인의 반대 이동입니다.","주사 왜곡·위치 반복성 저하·왕복 차이.","고정·기울기·이동 방향·기준 패턴을 비교하고 팁 충돌 여유를 확인합니다."),approach:xt("접근 명령·초기 높이와 여유 공간","미세 Z 제어가 가능한 근접 상태","조동 접근은 넓은 이동 범위를, 미세 Z 추종은 접촉 오차 보정을 담당합니다. 두 동작을 혼동하면 팁/시료 충돌 위험이 있습니다.","접근 실패·너무 이른 접촉·Z 범위 소진.","접근을 중지하고 시료 높이·장착·센서 상태를 제조사 절차로 확인합니다.")});Object.assign(ti.xps,{source:xt("X선원·단색화 조건","시료를 조사하는 광자","광전 효과로 방출되는 전자의 에너지로 표면 화학 정보를 읽습니다. 광원 에너지와 검출 전자 운동에너지를 구분합니다.","전체 피크 약화·배경/폭 변화.","광원 경보·기준 시료의 강도/폭·조사 위치를 비교합니다."),sample:xt("X선 조사·표면 조성·접지 상태","감쇠와 화학 상태가 반영된 광전자","광전자 탈출 깊이에 따른 표면 민감 측정입니다. 절연막 대전은 실제 화학 이동과 달리 여러 피크를 함께 움직일 수 있습니다.","피크 이동·시간에 따른 변동·표면 오염 신호.","접지·중화·기준 에너지·측정 위치와 이전 기록을 함께 확인합니다."),lens:xt("시료에서 방출된 광전자의 각도/에너지 분포","분석기 입구로 수집된 전자","수집 조건과 정렬은 감도에 영향을 주며 단순히 농도를 바꾸는 것이 아닙니다. 패스 에너지에 따른 분해능/감도를 함께 비교합니다.","피크 약화·상대 감도 편차.","기준 시료·렌즈 모드·조사/수집 위치·검출 포화를 확인합니다."),detector:xt("분석기를 통과한 전자","에너지 채널별 계수 신호","기록된 계수에는 배경과 검출 응답이 포함됩니다. 세기만으로 농도를 단정하지 않고 감도·전달 함수·배경을 고려해야 합니다.","계수 부족·포화·암배경 증가.","기준 취득·암신호·수집 시간·계수 범위와 교정 기록을 확인합니다.")});Object.assign(ti.tem,{gun:xt("전자 방출·가속 조건","시료 조명을 위한 전자빔","전자 파동이 얇은 시료와 상호작용합니다. 빔을 켜는 일과 검출기로 노출을 적분하는 일은 별개입니다.","조명 세기/안정성 변화.","진공/전자총 경보·조명 조건·기준 취득을 확인하며 고전압부는 열지 않습니다."),sample:xt("투과 전자빔·얇은 시료의 구조와 두께","투과·탄성/비탄성 산란 전자","두께·방향·선량에 따라 영상/회절/EELS가 달라집니다. 두꺼운 영역의 대비 변화를 검출기 고장으로 단정하지 않습니다.","대비 약화·다중 산란·오염·노출 의존 변화.","시료 위치·두께·홀더 고정·선량과 기준 영역을 비교합니다."),stem:xt("집속 프로브의 XY 주사·시료 산란","각 위치의 ADF 픽셀 강도","환형 검출기는 선택 각도 범위의 산란 전자를 모읍니다. 단순 밝기는 원자번호뿐 아니라 두께·회절·수집 조건에도 영향을 받습니다.","주사 줄무늬·대비/수집량 변화.","프로브·검출기 범위·주사 동기·시료 두께와 기준 영상을 확인합니다."),detector:xt("렌즈가 투사한 영상면 또는 회절면 전자","노출 중 누적된 카메라 신호","BF/DF 영상과 회절 패턴은 같은 종류의 높이맵이 아닙니다. 모드와 조리개/렌즈 선택이 어떤 전자를 기록하는지 바꿉니다.","포화·암배경·픽셀 편차·약한 신호.","모드·노출·검출기·암/기준 영상과 포화를 비교합니다.")});Object.assign(ti.sem,{gun:xt("전자 방출·가속 조건","조명계로 향하는 전자빔","전자빔은 시료와 상호작용해 SE/BSE를 만듭니다. 총 방출 상태와 시료에서 얻는 검출 신호를 구분합니다.","전체 신호 약화·시간 변동.","전자총/진공 경보·조명 조건·기준 시료를 확인합니다."),scan:xt("주사 좌표와 시간 동기","시료 위 빔 위치","빔 편향과 검출 신호의 시간 대응으로 픽셀을 배치합니다. 본 모델에서 스테이지는 고정이며 빔이 래스터 주사합니다.","줄무늬·기하 왜곡·주사 방향 의존 패턴.","주사 방향·속도·기준 패턴·외란을 비교합니다."),condenser:xt("전자총에서 나온 빔·조명/조리개 설정","집속 조건과 전류가 정해진 빔","프로브 크기와 전류의 절충은 해상도·신호에 영향을 줍니다. 이 웹 모델은 렌즈장을 수치 계산하지 않습니다.","신호 약화·프로브 확장·대비 변화.","기준 조건·조리개·조명 정렬·검출 포화를 구분합니다.")});Object.assign(ti.sam,{pulser:xt("주기 트리거·송신 명령","탐촉자 구동 전기 펄스와 시간 기준","송신 뒤 음향이 이동하고 계면에서 반사된 후 수신됩니다. 전면 기준 RF 시간과 수신 게이트를 구분해야 깊이를 해석할 수 있습니다.","시간 기준 이동·에코 누락·포화.","케이블·동기·전면 에코·수신 범위와 반복 RF를 비교합니다."),receiver:xt("시료를 통과한 음향","Through 모드의 수신 신호","반사 탐촉자와 분리된 하부 수신기입니다. 투과 약화는 두께 방향의 누적 영향으로 특정 접합층 결함 위치를 단독 결정하지 못합니다.","전체 투과 약화·음향 그림자·정렬 의존 변화.","송수신 정렬·결합·기준 위치와 반사 모드의 계면 에코를 함께 비교합니다.")});function Og(i,t,e={}){var a;const n=(a=ti[i])==null?void 0:a[t.id],s=xt("장비 신호 경로의 선행 입력 또는 시료·환경 상태","아래 역할에 따른 상호작용·전달 신호 또는 지지 상태",t.role,"신호·영상 변화만으로 이 부품의 단독 고장을 확정하지 않습니다. 기준 취득과 아래 점검 포인트를 함께 확인합니다.",t.check),r={...n??s,normal:"정상 여부는 같은 조건의 기준 시료·이전 기록과 비교합니다. 안정된 값 하나만으로 정상 또는 고장을 확정하지 않습니다.",chain:Ng[i],scope:"이 설명은 일반화된 교육 모델입니다. 특정 제조사의 구조·정비·교정 절차를 대체하지 않습니다."};return i==="sims"&&t.id==="analyzer"&&(r.input+=" · 현재 "+(e.technology==="magnetic"?"M-SIMS 연속/자기 섹터":"ToF-SIMS 펄스/비행시간")),r}const Bg=64;function zg(i,t,e="islands"){return e==="steps"?12+Math.floor(i*5)*13+5*Math.sin(t*8):e==="waves"?38+22*Math.sin(i*14)*Math.cos(t*10)+8*Math.sin(t*28):5+[[.27,.3,.12,65],[.65,.35,.16,83],[.45,.72,.13,54],[.82,.8,.08,42]].reduce((s,[r,a,o,c])=>s+c*Math.exp(-((i-r)**2+(t-a)**2)/(2*o**2)),0)+3*Math.sin(i*25)*Math.sin(t*19)}class kg{constructor(t=Bg){this.size=t,this.rate=1,this.gain=.45,this.surface="islands",this.reset()}reset(){this.trace=new Float32Array(this.size**2).fill(NaN),this.retrace=new Float32Array(this.size**2).fill(NaN),this.index=0,this.elapsed=0,this.accumulator=0,this.z=0,this.error=0,this.deflection=0,this.sum=1,this.line=0,this.column=0,this.direction="Trace",this.status="idle",this.transition=0,this.last=null}start(){if(this.status==="paused"){this.status="scanning";return}["idle","complete","retracted"].includes(this.status)&&(this.reset(),this.status="approaching")}pause(){this.status==="scanning"&&(this.status="paused")}retract(){this.status="retracting",this.transition=0}tick(t){if(["approaching","retracting"].includes(this.status)){this.transition+=t,this.transition>=1.2&&(this.status=this.status==="approaching"?"scanning":"retracted",this.transition=0);return}if(this.status==="scanning")for(this.elapsed+=t,this.accumulator+=t*this.rate*this.size*2;this.accumulator>=1&&this.status==="scanning";)this.accumulator-=1,this.sample()}sample(){if(this.index>=this.size*this.size*2){this.status="complete";return}const t=Math.floor(this.index/(2*this.size)),e=this.index%(2*this.size),n=e<this.size,s=n?e:2*this.size-1-e,r=zg(s/(this.size-1),t/(this.size-1),this.surface),a=1-Math.exp(-this.gain*8/this.rate);this.z+=a*(r-this.z),this.error=r-this.z,this.deflection=this.error/100,(n?this.trace:this.retrace)[t*this.size+s]=this.z,this.line=t,this.column=s,this.direction=n?"Trace":"Retrace",this.last={row:t,column:s,direction:this.direction,height:this.z,error:this.error},this.index+=1,this.index===this.size*this.size*2&&(this.status="complete")}get progress(){return this.index/(this.size*this.size*2)}get xy(){return[this.column/(this.size-1),this.line/(this.size-1)]}get clearance(){return this.status==="approaching"?1-this.transition/1.2:this.status==="retracting"?this.transition/1.2:["idle","retracted"].includes(this.status)?1:0}csv(){const t=["x_um,y_um,trace_nm,retrace_nm"];for(let e=0;e<this.size;e++)for(let n=0;n<this.size;n++){const s=e*this.size+n;t.push([n/(this.size-1)*5,e/(this.size-1)*5,Number.isFinite(this.trace[s])?this.trace[s].toFixed(4):"",Number.isFinite(this.retrace[s])?this.retrace[s].toFixed(4):""].join(","))}return t.join(`
`)}}const Hg=64;class Vg{constructor(t=Hg){this.size=t,this.rate=1,this.reset()}reset(){this.mode="idle",this.milling=0,this.scan=0,this.image=new Float32Array(this.size*this.size).fill(NaN),this.imageDepth=0}startMilling(){this.milling>=1&&(this.milling=0),this.mode="milling"}startImaging(){this.mode="imaging",this.scan=0,this.image.fill(NaN),this.imageDepth=this.milling}pause(){this.mode="paused"}tick(t){if(!(!Number.isFinite(t)||t<=0)){if(this.mode==="milling")this.milling=Math.min(1,this.milling+t*this.rate/18),this.milling===1&&(this.mode="milled");else if(this.mode==="imaging"){const e=Math.floor(this.scan*this.size*this.size);this.scan=Math.min(1,this.scan+t/6);const n=Math.floor(this.scan*this.size*this.size);for(let s=e;s<n;s++){const r=Math.floor(s/this.size),a=s%this.size;this.image[s]=Wg(a/(this.size-1),r/(this.size-1),this.imageDepth)}this.scan===1&&(this.mode="imaged")}}}get depth(){return this.milling*180}}function Gg(i,t){const e=(n,s,r)=>Math.max(0,Math.min(1,(n-s)/.035,(r-n)/.035));return e(i,.21,.79)*e(t,.32,.68)}function Wg(i,t,e){const n=.49+.08*Math.sin(37*i+4*Math.sin(t*11))+.06*Math.cos(54*t+5*i)+.025*Math.sin(93*i+87*t),s=Gg(i,t);return Math.max(0,Math.min(1,n-e*s*.3+e*(s>0&&s<1?.18:0)))}const Vr={image:{name:"BF",title:"BF TEM 이미지",description:"투과파를 이용한 밝은 바탕의 개념 영상입니다.",duration:4},diffraction:{name:"Diffraction",title:"회절 패턴",description:"결정구조를 계산하지 않는 합성 회절 점 배열입니다.",duration:4},df:{name:"DF",title:"DF TEM 이미지",description:"대물 조리개로 선택한 회절파가 발생한 영역이 밝아지는 개념 영상입니다. g₁/g₂를 바꿔 비교하세요.",duration:4},stem:{name:"STEM · ADF",title:"STEM ADF 주사 영상",description:"집속 프로브를 한 점씩 주사하며 환형 검출 신호로 픽셀을 채웁니다. 조성·원자번호 정량 모델은 아닙니다.",duration:8},eels:{name:"EELS",title:"EELS 스펙트럼",description:"에너지 손실에 따른 합성 강도입니다. 0 eV 부근 제로로스, 저손실 피크와 임의의 코어 에지 A/B를 표시합니다.",duration:5}};function Xg(i,t,e,n=1){const s=n===1?[.32,.4]:[.7,.6],r=Math.exp(-((i-s[0])**2/.025+(t-s[1])**2/.045)),a=.65+.35*Math.cos(60*i+27*t);return Math.min(1,.025+r*a*(.5+.3*Li(e)))}function Yg(i,t,e){let n=.04;for(let s=0;s<7;s++)for(let r=0;r<7;r++){const a=i-(.12+r*.125+s%2*.025),o=t-(.12+s*.125);n+=(.45+.25*((s+r)%3)/2)*Math.exp(-(a*a+o*o)/32e-5)}return Math.min(1,n*(.5+e/150))}function bc(i,t){const e=48e3*Li(t)*Math.exp(-.5*(i/2.2)**2),n=1800*(1-Li(t))*Math.exp(-.5*((i-22)/7)**2),s=180*(t/50)/(1+Math.max(0,i)/45)**1.5,r=(a,o)=>i<a?0:o*(t/50)*Math.exp(-(i-a)/110);return Math.max(1,e+n+s+r(200,90)+r(520,65))}function Li(i){return Math.exp(-i/100)}function qg(i,t,e){const n=Math.sin(15*i+4*Math.sin(8*t))+Math.cos(21*t-5*i)+.7*Math.sin(26*(i+t)),s=.1*Math.sin(91*i+79*t)*Math.cos(67*i-83*t);return Math.max(0,Math.min(1,.28+.46*Li(e)+.1*n+s))}function jg(i,t,e){let n=.025;for(let s=-3;s<=3;s++)for(let r=-3;r<=3;r++){const a=i-.5-r*.115,o=t-.5-s*.115,c=r===0&&s===0?.8:.5*Math.exp(-.08*(r*r+s*s));n+=c*Li(e)*Math.exp(-(a*a+o*o)/11e-5)}return Math.min(1,n)}class $g{constructor(){this.thickness=50,this.reflection=1,this.reset()}reset(){this.status="idle",this.mode=this.mode||"image",this.progress=0,this.exposureThickness=this.thickness,this.exposureReflection=this.reflection}configure(t){if("mode"in t&&!Vr[t.mode])throw new RangeError("Unknown TEM mode");if("thickness"in t&&(!Number.isFinite(t.thickness)||t.thickness<10||t.thickness>100))throw new RangeError("Invalid thickness");if("reflection"in t&&![1,2].includes(t.reflection))throw new RangeError("Invalid reflection");for(const e of["mode","thickness","reflection"])e in t&&(this[e]=t[e]);this.reset()}start(t=this.mode,e=!1){if(!Vr[t])throw Error("Unknown TEM mode");if(!e&&this.status==="paused"&&this.mode===t){this.status="exposing";return}this.mode=t,this.progress=0,this.exposureThickness=this.thickness,this.exposureReflection=this.reflection,this.status="exposing"}pause(){this.status==="exposing"&&(this.status="paused")}tick(t){this.status!=="exposing"||!Number.isFinite(t)||t<=0||(this.progress=Math.min(1,this.progress+t/Vr[this.mode].duration),this.progress>=1-1e-10&&(this.progress=1,this.status="complete"))}get scanXY(){const t=Math.min(4095,Math.floor(this.progress*4096));return[t%64/63,Math.floor(t/64)/63]}eelsCsv(){return`# synthetic EELS; no element identification
energy_loss_eV,intensity_au
`+Array.from({length:401},(t,e)=>{const n=e*2;return n+","+(bc(n,this.exposureThickness)*this.progress).toFixed(5)}).join(`
`)}get brightness(){return Li(this.exposureThickness)*this.progress}}const Tc=.15406,Gr={out:{name:"Out-of-plane",ko:"면외 회절",min:10,max:90,axis:"2θ (°)",description:"대칭 θ–2θ 기하로 시료 표면의 법선 방향 격자 간격을 살펴봅니다. 산란벡터 q는 표면에 수직입니다."},in:{name:"In-plane",ko:"면내 회절",min:10,max:90,axis:"2θχ (°)",description:"입사·출사각을 작은 값으로 유지하고 검출기를 면내 방향으로 회전합니다. 산란벡터 q는 주로 표면에 평행합니다."},xrr:{name:"XRR",ko:"X선 반사율",min:.05,max:4,axis:"θ (°)",description:"낮은 입사각의 정반사 기하입니다. 박막 두께는 간섭무늬의 간격, 거칠기는 고각 반사율 감쇠에 영향을 줍니다."}};function Zg(i,t=1){const e=t*Tc/(2*i);return e>0&&e<=1?2*Math.asin(e)*180/Math.PI:null}function Kg(i,t,e){const n=i*Math.PI/180,s=.22*Math.PI/180,r=n<=s?1:(s/n)**4,a=4*Math.PI*Math.sin(n)/Tc,o=.58+.42*Math.cos(a*t);return Math.max(1e-9,Math.min(1,r*(n<=s?1:o)*Math.exp(-((a*e)**2))))}function Jg(i,t,e){let n=20+30*Math.exp(-i/35);for(let s=1;s<=3;s++){const r=Zg(t,s);r!==null&&(n+=(e==="in"?850:1100)/s**2*Math.exp(-.5*((i-r)/.42)**2))}return n}class Qg{constructor(){this.mode="out",this.spacingOut=.25,this.spacingIn=.28,this.thickness=30,this.roughness=.3,this.reset()}reset(){this.status="idle",this.progress=0,this.values=[],this.angle=Gr[this.mode].min,this.settings=null}setMode(t){if(!Gr[t])throw Error("Unknown XRD mode");this.mode=t,this.reset()}start(){if(this.status==="paused"){this.status="scanning";return}this.reset(),this.settings={spacing:this.mode==="in"?this.spacingIn:this.spacingOut,thickness:this.thickness,roughness:this.roughness},this.status="scanning"}pause(){this.status==="scanning"&&(this.status="paused")}tick(t){var s;if(this.status!=="scanning")return;this.progress=Math.min(1,this.progress+t/8);const e=Math.floor(this.progress*400),n=Gr[this.mode];for(;this.values.length<e;){const r=n.min+(n.max-n.min)*this.values.length/399,a=this.mode==="xrr"?Kg(r,this.settings.thickness,this.settings.roughness):Jg(r,this.settings.spacing,this.mode);this.values.push({x:r,y:a})}this.angle=((s=this.values.at(-1))==null?void 0:s.x)??n.min,this.progress===1&&(this.status="complete")}csv(){const t=this.mode==="xrr"?"theta_deg,reflectivity":"two_theta_deg,intensity_au";return"# synthetic educational data; mode="+this.mode+`
`+t+`
`+this.values.map(({x:e,y:n})=>e.toFixed(5)+","+n.toPrecision(7)).join(`
`)}}const Ac={se:{name:"SE · 이차전자",short:"SE",detector:"se",description:"표면의 기울기와 모서리가 강조됩니다. 낮은 에너지의 이차전자를 측면 검출기로 수집하는 개념 모델입니다."},bse:{name:"BSE · 후방산란전자",short:"BSE",detector:"bse",description:"상대적으로 높은 평균 원자번호 영역이 밝아지는 조성 대비입니다. 실제 BSE에는 형상·결정방향 대비도 포함될 수 있습니다."}},Ba=i=>Math.max(0,Math.min(1,i));function Vi(i,t){const e=.36*Math.exp(-((i-.32)**2+(t-.35)**2)/.012),n=.18*Math.exp(-((i-.72)**2/.006+(t-.65)**2/.08)),s=.09/(1+Math.exp(-(i+t-1)*45));return e+n+s}function t_(i,t){return Math.hypot(i-.67,t-.3)<.125?.88:Math.hypot(i-.3,t-.73)<.105?.22:.48}function e_(i,t,e){const s=(Vi(i+.006,t)-Vi(i-.006,t))/.012,r=(Vi(i,t+.006)-Vi(i,t-.006))/(2*.006),a=.1*Vi(i,t)+.09*s+.055*r,o=.015*Math.sin(i*190)*Math.sin(t*170);return Ba(e==="se"?.43+a+o:t_(i,t)+.22*a+o)}function n_(i,t,e="se",n=0){if(!Ac[e])throw new RangeError("Unknown SEM mode");const s=Math.max(0,Math.min(100,n))*7e-4;let r=0;for(const a of[-1,0,1])for(const o of[-1,0,1])r+=e_(Ba(i+a*s),Ba(t+o*s),e);return r/9}class i_{constructor(t=64){if(!Number.isInteger(t)||t<2)throw new RangeError("Invalid raster size");this.size=t,this.mode="se",this.defocus=0,this.duration=8,this.reset()}reset(){this.status="idle",this.elapsed=0,this.index=0,this.pixels=new Float32Array(this.size**2).fill(NaN)}configure(t,e=this.defocus){if(!Ac[t])throw new RangeError("Unknown SEM mode");this.mode=t,this.defocus=Math.max(0,Math.min(100,e)),this.reset()}start(){this.status==="complete"&&this.reset(),this.status="scanning"}pause(){this.status==="scanning"&&(this.status="paused")}tick(t){if(this.status!=="scanning"||!Number.isFinite(t)||t<=0)return;this.elapsed=Math.min(this.duration,this.elapsed+t);const e=Math.min(this.pixels.length,Math.floor(this.elapsed/this.duration*this.pixels.length+1e-8));for(;this.index<e;){const{x:n,y:s}=this.coordinate(this.index);this.pixels[this.index]=n_(n,s,this.mode,this.defocus),this.index++}this.index===this.pixels.length&&(this.status="complete")}coordinate(t=Math.max(0,this.index-1)){const e=Math.max(0,Math.min(this.pixels.length-1,t));return{x:e%this.size/(this.size-1),y:Math.floor(e/this.size)/(this.size-1)}}get progress(){return this.index/this.pixels.length}csv(){const t=["mode,x_pixel,y_pixel,intensity_au,defocus_percent"];for(let e=0;e<this.index;e++)t.push(`${this.mode},${e%this.size},${Math.floor(e/this.size)},${this.pixels[e].toFixed(6)},${this.defocus}`);return t.join(`
`)}}const s_=5.5,za=720,r_=[65,130,195,260,325,390,455,520,590,690],Rl={a:{name:"A-Scan",description:"한 XY 위치에서 반사 RF 진폭을 시간에 따라 취득합니다. 아래 파형의 색칠된 구간이 깊이 게이트입니다.",duration:2},b:{name:"B-Scan",description:"선택한 Y를 따라 X를 주사합니다. 가로는 X 위치, 세로는 표면 기준 추정 깊이인 단면 영상입니다.",duration:6},c:{name:"C-Scan",description:"XY 면을 주사하고 선택 게이트 안의 반사 피크를 픽셀로 만듭니다. 게이트 깊이를 바꾸어 다른 접합면을 비교하세요.",duration:8},through:{name:"Through-Scan",description:"시료 아래 별도 수신기로 투과 신호를 취득합니다. 반사 게이트와 무관한 두께 방향 투영 영상이며 깊이를 특정할 수 없습니다.",duration:8}},wc=i=>Math.max(0,Math.min(1,i)),ns=i=>2*i/s_;function is(i,t,e,n="both"){return(n==="both"||n==="delamination")&&Math.abs(e-260)<1&&((i-.36)/.17)**2+((t-.45)/.13)**2<1?"delamination":(n==="both"||n==="void")&&Math.abs(e-590)<1&&((i-.69)/.12)**2+((t-.66)/.1)**2<1?"void":null}function a_(i,t,e,n){return(e>260&&is(i,t,260,n)?.18:1)*(e>590&&is(i,t,590,n)?.22:1)}function Cl(i){return Math.cos(2*Math.PI*.1*i)*Math.exp(-(i**2)/32)}function o_(i,t,e="both"){return r_.map(n=>({depth:n,amplitude:(is(i,t,n,e)?-.92:n===690?.32:.14+.02*Math.sin(i*18+t*15+n))*Math.exp(-n/1100)*a_(i,t,n,e)}))}function ka(i,t,e,n="both"){let s=.55*Cl(e);for(const{depth:r,amplitude:a}of o_(i,t,n))s+=a*Cl(e-ns(r));return s}function l_(i,t,e=260,n=40,s="both"){const r=ns(Math.max(0,e-n/2)),a=ns(Math.min(za,e+n/2));let o=0;for(let c=0;c<=40;c++){const l=ka(i,t,r+(a-r)*c/40,s);Math.abs(l)>Math.abs(o)&&(o=l)}return o}function c_(i,t,e="both"){let n=.66+.025*Math.sin(i*17)*Math.sin(t*19);return is(i,t,260,e)&&(n*=.14),is(i,t,590,e)&&(n*=.19),wc(n)}class h_{constructor(t=64){this.size=t,this.depthRows=128,this.mode="c",this.sample="both",this.center=260,this.width=40,this.x=.36,this.y=.45,this.reset()}get total(){return this.mode==="a"?512:this.mode==="b"?this.size:this.size**2}get coordinate(){if(!this.index)return{x:this.x,y:this.y};const t=this.index-1;return this.mode==="a"?{x:this.x,y:this.y}:this.mode==="b"?{x:t/(this.size-1),y:this.y}:{x:t%this.size/(this.size-1),y:Math.floor(t/this.size)/(this.size-1)}}reset(){this.elapsed=0,this.index=0,this.status="idle",this.values=new Float32Array(this.mode==="b"?this.size*this.depthRows:this.total).fill(NaN)}configure(t){if(t.mode&&!Rl[t.mode])throw new RangeError("Unknown SAM mode");if(t.sample&&!["both","healthy","void","delamination"].includes(t.sample))throw new RangeError("Unknown sample");for(const e of["x","y","center","width"])if(e in t&&!Number.isFinite(t[e]))throw new RangeError("Invalid "+e);for(const e of["mode","sample"])e in t&&(this[e]=t[e]);for(const e of["x","y"])e in t&&(this[e]=wc(t[e]));"center"in t&&(this.center=Math.max(25,Math.min(690,t.center))),"width"in t&&(this.width=Math.max(10,Math.min(100,t.width))),this.reset()}start(){this.status==="complete"&&this.reset(),this.status="scanning"}pause(){this.status==="scanning"&&(this.status="paused")}tick(t){if(this.status!=="scanning"||!Number.isFinite(t)||t<=0)return;const e=Rl[this.mode].duration;this.elapsed=Math.min(e,this.elapsed+t);const n=Math.min(this.total,Math.floor(this.elapsed/e*this.total+1e-8));for(;this.index<n;){const s=this.index;if(this.mode==="a")this.values[s]=ka(this.x,this.y,-20+300*s/(this.total-1),this.sample);else if(this.mode==="b"){const r=s/(this.size-1);for(let a=0;a<this.depthRows;a++)this.values[a*this.size+s]=ka(r,this.y,ns(za*a/(this.depthRows-1)),this.sample)}else{const r=s%this.size/(this.size-1),a=Math.floor(s/this.size)/(this.size-1);this.values[s]=this.mode==="through"?c_(r,a,this.sample):l_(r,a,this.center,this.width,this.sample)}this.index++}this.index===this.total&&(this.status="complete")}get progress(){return this.index/this.total}csv(){const t=["mode,sample,x_normalized,y_normalized,depth_um_approx,time_ns_from_front,value_au,gate_center_um,gate_width_um"],e=(n,s,r,a,o)=>t.push([this.mode,this.sample,n.toFixed(5),s.toFixed(5),r,a,o.toFixed(6),this.center,this.width].join(","));for(let n=0;n<this.index;n++)if(this.mode==="a"){const s=-20+300*n/(this.total-1);e(this.x,this.y,"",s.toFixed(4),this.values[n])}else if(this.mode==="b")for(let s=0;s<this.depthRows;s++){const r=za*s/(this.depthRows-1);e(n/(this.size-1),this.y,r.toFixed(3),ns(r).toFixed(4),this.values[s*this.size+n])}else e(n%this.size/(this.size-1),Math.floor(n/this.size)/(this.size-1),this.mode==="c"?this.center:"","",this.values[n]);return t.join(`
`)}}class Rc{reset(){this.status="idle",this.elapsed=0,this.index=0,this.rows=[]}start(){this.status==="complete"&&this.reset(),this.status="scanning"}pause(){this.status==="scanning"&&(this.status="paused")}get total(){return this.mode==="depth"?81:this.mode==="image"?4096:801}get duration(){return this.mode==="depth"?12:this.mode==="image"?8:6}get progress(){return this.index/this.total}get depth(){return this.mode==="depth"&&this.index?this.rows.at(-1).axis:0}get surfaceDepth(){if(this.mode!=="depth")return 0;const t=this.kind==="sims"?80:30;if(this.elapsed>=this.duration)return t;const e=this.elapsed/(this.duration/this.total),n=Math.floor(e),s=this.technology==="magnetic"?e:Math.max(0,n-1+Math.min(1,e%1*2));return Math.min(t,s*t/(this.total-1))}get phase(){return this.mode==="depth"&&this.status==="scanning"&&this.elapsed>=this.duration/this.total&&this.elapsed/(this.duration/this.total)%1<.5?"sputter":"analyze"}tick(t){if(this.status!=="scanning"||!Number.isFinite(t)||t<=0)return;this.elapsed=Math.min(this.duration,this.elapsed+t);const e=Math.min(this.total,Math.floor(this.progressAtTime()*this.total+1e-8));for(;this.index<e;)this.rows.push(this.point(this.index)),this.index++;this.index===this.total&&(this.status="complete")}progressAtTime(){return this.elapsed/this.duration}csv(){const t='"'+JSON.stringify(this.metadata()).replaceAll('"','""')+'"';return["instrument,mode,axis,signal_au,si_au,oxide_or_oxygen_au,carbon_au,copper_au,boron_au,nominal_depth_nm,metadata",...this.rows.map(e=>[this.kind,this.mode,e.axis,e.value,e.si??"",e.o??"",e.c??"",e.cu??"",e.b??"",this.mode==="depth"?e.axis:"",t].join(","))].join(`
`)}}const Ce=(i,t,e)=>Math.exp(-.5*((i-t)/e)**2),u_=1486.6,d_=4.5,Wr={si2p:{name:"Si 2p",range:[110,94],peaks:[[99.4,"Si⁰"],[103.5,"Si⁴⁺"]]},c1s:{name:"C 1s",range:[295,278],peaks:[[284.8,"C 1s"]]},o1s:{name:"O 1s",range:[544,524],peaks:[[532.8,"O 1s"]]}};function Cc(i,t){const e=Math.max(0,t-i),n=Math.exp(-e/3);return{si:n,o:1-n,c:.22*Math.exp(-i/1.5)}}function f_(i,{thickness:t=6,charge:e=2,neutralizer:n=!0,passEnergy:s=20,mode:r="survey"}={}){const a=e*(n?.1:1),o=Cc(0,t),c=r==="survey"?1.6:s===20?.35:.8,l=u=>Ce(i,u+a,c)+.5*Ce(i,u+.6+a,c);return .012+o.si*l(99.4)+o.o*l(103.5)+o.o*.9*Ce(i,532.8+a,r==="survey"?2.2:c)+o.c*Ce(i,284.8+a,r==="survey"?1.2:Math.hypot(c,.35))}class p_ extends Rc{constructor(){super(),this.kind="xps",this.mode="survey",this.region="si2p",this.thickness=6,this.charge=2,this.neutralizer=!0,this.passEnergy=20,this.reset()}get energyRange(){return this.mode==="survey"?[600,0]:Wr[this.region].range}configure(t){if(t.mode&&!["survey","highres","depth"].includes(t.mode))throw new RangeError("Unknown XPS mode");if("region"in t&&!Object.hasOwn(Wr,t.region))throw new RangeError("Unknown Narrow region");for(const e of["thickness","charge"])if(e in t&&!Number.isFinite(t[e]))throw new RangeError("Invalid "+e);if("passEnergy"in t&&![20,80].includes(t.passEnergy))throw new RangeError("Invalid pass energy");for(const e of["mode","region","neutralizer","passEnergy"])e in t&&(this[e]=t[e]);"thickness"in t&&(this.thickness=Math.max(2,Math.min(12,t.thickness))),"charge"in t&&(this.charge=Math.max(0,Math.min(4,t.charge))),this.reset()}point(t){if(this.mode==="depth"){const r=t/(this.total-1)*30,a=Cc(r,this.thickness);return{axis:r,value:a.si,...a}}const[e,n]=this.energyRange,s=e+(n-e)*t/(this.total-1);return{axis:s,value:f_(s,this)}}metadata(){return{sample:"synthetic_SiO2_on_Si",mode_label:this.mode==="highres"?"Narrow":this.mode==="depth"?"Depth Profiling":"Survey",narrow_region:this.mode==="highres"?Wr[this.region].name:null,energy_range_eV:this.mode==="depth"?null:this.energyRange,thickness_nm:this.thickness,charge_eV:this.charge,neutralizer:this.neutralizer,pass_energy_eV:this.passEnergy,photon_eV:u_,work_function_eV_assumed:d_}}}const vi={positive:[{id:"si",name:"²⁸Si⁺",mass:28},{id:"cu",name:"⁶³Cu⁺",mass:63},{id:"b",name:"¹¹B⁺",mass:11}],negative:[{id:"o",name:"¹⁶O⁻",mass:16},{id:"c",name:"¹²C⁻",mass:12},{id:"si",name:"²⁸Si⁻",mass:28}]};function m_(i,t){return Math.abs(i-.32)<.12&&t>.2&&t<.8||Math.abs(t-.32)<.1&&i>.32&&i<.8?1:0}function Ha(i=0,t=.32,e=.5,n=10,s=!0){const r=m_(t,e),a=Math.max(0,i-(r?8:0)),o=1/(1+Math.exp((a-n)/1.8)),c=r/(1+Math.exp((i-8)/1.3));return{cu:.85*c*(s?.65:1),o:.65*o*(1-.85*c)*(s?1.3:1),si:(.15+.7*(1-o))*(1-.8*c),c:.32*Math.exp(-i/2)*(1-.6*c),b:.38*Ce(i,35,7)*(1-.5*c)+.012}}function g_(i,t="positive",e=10,n=!0){const s=Ha(0,.32,.5,e,n),r=.002;return t==="positive"?r+s.b*Ce(i,11,.15)+s.si*Ce(i,28,.15)+s.si*.05*Ce(i,29,.15)+s.si*.033*Ce(i,30,.15)+s.cu*Ce(i,63,.15)+s.cu*.45*Ce(i,65,.15):r+s.c*2*Ce(i,12,.15)+s.o*3*Ce(i,16,.15)+s.si*Ce(i,28,.15)+s.o*.4*Ce(i,44,.15)}class __ extends Rc{constructor(){super(),this.kind="sims",this.technology="tof",this.mode="spectrum",this.polarity="positive",this.species="cu",this.thickness=10,this.matrix=!0,this.reset()}get phase(){return this.technology==="magnetic"?"continuous":super.phase}get selectedMass(){var t;return this.mode==="spectrum"?((t=this.rows.at(-1))==null?void 0:t.axis)??1:vi[this.polarity].find(e=>e.id===this.species).mass}setTechnology(t){if(!["magnetic","tof"].includes(t))throw new RangeError("Unknown SIMS technology");this.technology=t,this.configure({mode:t==="magnetic"?"depth":"spectrum"})}configure(t){if(t.mode&&!["spectrum","image","depth"].includes(t.mode))throw new RangeError("Unknown SIMS mode");if(t.polarity&&!vi[t.polarity])throw new RangeError("Unknown polarity");const e=t.polarity||this.polarity;if(t.species&&!vi[e].some(n=>n.id===t.species))throw new RangeError("Species not available in selected polarity");if("thickness"in t&&!Number.isFinite(t.thickness))throw new RangeError("Invalid thickness");for(const n of["mode","polarity","species","matrix"])n in t&&(this[n]=t[n]);vi[this.polarity].some(n=>n.id===this.species)||(this.species=vi[this.polarity][0].id),"thickness"in t&&(this.thickness=Math.max(2,Math.min(20,t.thickness))),this.reset()}point(t){if(this.mode==="depth"){const n=t/(this.total-1)*80,s=Ha(n,.32,.5,this.thickness,this.matrix),r=Object.fromEntries(vi[this.polarity].map(a=>[a.id,s[a.id]]));return{axis:n,value:s[this.species],...r}}if(this.mode==="image"){const n=t%64/63,s=Math.floor(t/64)/63;return{axis:t,x:n,y:s,value:Ha(0,n,s,this.thickness,this.matrix)[this.species]}}const e=1+t/(this.total-1)*69;return{axis:e,value:g_(e,this.polarity,this.thickness,this.matrix)}}metadata(){const t=this.technology==="magnetic";return{technology:t?"M-SIMS_magnetic_sector":"ToF-SIMS",beam_mode:t?"continuous_primary_sputter_and_analysis":"pulsed_analysis_dual_beam_depth",mass_separation:t?"electrostatic_energy_filter_then_magnetic_sector":"time_of_flight",acquisition_model:t?this.mode==="depth"?"single_collector_peak_hopping_cycle":this.mode==="image"?"selected_mass_raster":"magnetic_field_sweep":"full_spectrum_per_pulse_displayed_progressively",sample:"synthetic_Cu_pattern_SiO2_Si_with_B_layer",polarity:this.polarity,species:this.species,oxide_nm:this.thickness,matrix_effect:this.matrix,flight_length_m_assumed:t?null:1,acceleration_V_assumed:t?5e3:2e3,sector_radius_m_assumed:t?.35:null,trajectory_model:"conceptual_not_ray_traced",erosion_model:"nominal_depth_mode_only",depth_calibration:"nominal_not_measured",image_x_y:"index%64/63;floor(index/64)/63"}}}const ee=(i,t,e,n,s)=>({id:i,name:t,ko:e,role:n,check:s}),Xr=ee("stage","Sample positioning","시료 이동계","선택 위치를 광학/기계적 측정 축에 맞춥니다.","시료 고정·이동 여유·반복 위치를 확인합니다."),Gi=ee("control","Acquisition electronics","취득·제어계","입력 상태와 검출값을 좌표/시간에 연결합니다.","조건·동기·교정 기록과 저장 채널을 확인합니다."),Wi=ee("base","Isolation base","방진 베이스","외부 진동과 열 변동의 영향을 줄이는 개념 구조입니다.","기준 시료·주변 진동·온도 안정성을 확인합니다."),en=(i,t,e,n)=>({id:i,name:t,parts:e,steps:n}),Pl={xrm:{name:"XRM",tag:"X-RAY MICROSCOPY",heading:"투영을 모아, 내부 단면으로.",intro:"가상 패키지 단면의 흡수 투영을 취득하고 같은 투영으로 CT를 재구성합니다.",modes:{radiograph:"Radiography",ct:"CT · 단면 재구성"},defaultMode:"ct",duration:16,parameter:{label:"흡수 계수 배율",min:.5,max:2,step:.1,value:1,unit:"×"},selector:{label:"가상 단면",values:{void:"내부 보이드",healthy:"기준 · 보이드 없음"}},band:null,parts:[ee("source","X-ray source","X선원","연속 X선을 발생시키고 노출 구간에만 시료로 전달합니다.","선원 안정성·셔터·인터록 경보를 승인된 절차로 확인합니다."),ee("optics","Illumination optics","조사 광학계","X선 조사 경로를 정렬합니다. 이 계산은 평행빔 근사입니다.","기준 시료로 축 정렬·빔 균일도를 확인합니다."),ee("sample","Package phantom","가상 패키지 단면","흡수체와 고흡수 삽입물·보이드를 포함한 합성 단면입니다. HBM 적층 전체가 아닙니다.","시료 크기·고정과 투과 가능성을 검토합니다."),ee("stage","Rotation stage","회전 스테이지","각도 이동 후 정지 노출을 반복합니다.","회전 중심·흔들림·충돌 여유를 확인합니다."),ee("detector","Scintillator / detector","변환·검출계","투과 강도를 읽습니다. 선택한 한 행으로 단면 CT를 계산합니다.","다크·플랫·포화·불량 픽셀을 기준 영상과 비교합니다."),Gi,Wi],flow:"X선 노출 → 시료 흡수 → 투과 강도 I/I₀ → −ln(I/I₀) → 각도별 투영 → 필터 역투영",limits:"CT는 평행빔 2D 단면의 48채널 × 48각도 근사이며 Radiography는 한 각도입니다. 한 검출 행을 3D 검출판으로 확대 표시하며 완전한 3D CT가 아닙니다. 위상 대비·cone-beam·산란·실제 결함 판정은 구현하지 않습니다.",sources:[["ZEISS · XRM 재구성","https://www.zeiss.com/microscopy/en/products/software/advanced-reconstruction-toolbox.html"]],guides:[en("ring","링·줄무늬 아티팩트",["detector","stage","control"],["플랫/다크와 불량 픽셀 보정을 확인합니다.","회전 중심·시료 이동을 기준 데이터와 비교합니다.","각도 수·투과 부족·재구성 조건을 검토합니다."]),en("weak","투과 신호 부족",["source","sample","detector"],["기준 투영과 포화 여부를 비교합니다.","시료 두께·재료·노출 기록을 확인합니다.","실제 조사는 방사선 안전 절차를 따릅니다."])]},nanoindenter:{name:"Nanoindenter",tag:"INSTRUMENTED INDENTATION",heading:"누르는 힘과, 남는 깊이.",intro:"하중 인가·유지·제하를 따라가며 하중–변위 곡선과 잔류 압흔을 연결합니다.",modes:{indent:"Load–Hold–Unload"},defaultMode:"indent",duration:14,parameter:{label:"최대 하중",min:200,max:2e3,step:100,value:1e3,unit:"μN"},selector:{label:"가상 재료",values:{silicon:"Si 유사 · 경질",copper:"Cu 유사 · 연질",polymer:"Polymer 유사"}},band:null,parts:[ee("source","Force actuator","하중 액추에이터","설정된 하중 이력을 인가하는 개념 구동계입니다.","기준 재료·하중 영점·기기 컴플라이언스를 확인합니다."),ee("optics","Displacement sensor","변위 센서","압입 깊이 변화와 열 드리프트를 읽는 개념 센서입니다.","표면 검출·변위 영점·드리프트·교정을 확인합니다."),ee("probe","Berkovich tip","삼각뿔 팁","이상적 Berkovich 면적 함수 A=24.5h_c²를 사용합니다.","팁 면적 함수·오염·마모는 교정 시료로 확인합니다."),ee("sample","Indentation coupon","압입용 가상 쿠폰","이상화 탄소성 응답을 갖는 벌크 재료입니다. 제거 시 잔류 압흔이 남습니다.","두께·표면 거칠기·기판 효과·압흔 간격을 확인합니다."),Xr,Gi,Wi],flow:"하중 명령 → 팁 접촉·압입 → 변위·힘 동시 취득 → 제하 기울기 S → 접촉 면적 → H / Eᵣ 예시",limits:"합성 하중–변위 곡선과 이상적 Oliver–Pharr 계산 예시입니다. 입력 재료 응답에서 생성한 곡선을 다시 계산하므로 독립 검증값이 아닙니다. 크리프·pile-up·드리프트·팁 라운딩·기판 효과를 계산하지 않습니다. Eᵣ는 감소 탄성률이며 시료 Young 탄성률이 아닙니다.",sources:[["Oliver & Pharr · 원 논문","https://web.mit.edu/cortiz/www/3.052/3.052CourseReader/45_OliverPharr1992Nanoindentation.pdf"]],guides:[en("drift","깊이 드리프트·곡선 이동",["optics","base","control"],["온도 안정화와 드리프트 기록을 확인합니다.","표면 검출과 하중/변위 영점을 재확인합니다.","기준 재료에서 반복성을 비교합니다."]),en("area","경도·탄성률 편차",["probe","sample","source"],["팁 면적 함수와 프레임 교정 기록을 확인합니다.","표면·기판·압흔 간격 영향을 검토합니다.","단일 압흔으로 재료 특성을 확정하지 않습니다."])]},raman:{name:"Raman",tag:"INELASTIC LIGHT SCATTERING",heading:"같은 빛에서, 다른 진동 신호.",intro:"레이저 여기·Rayleigh 제거·분광 검출을 연결하고 가상 폴리머 도메인을 맵으로 봅니다.",modes:{spectrum:"Spectrum · Stokes",map:"Chemical map"},defaultMode:"spectrum",duration:12,parameter:{label:"합성 폴리머 응답 가중치",min:.2,max:2,step:.1,value:1,unit:"×"},selector:{label:"여기 파장",values:{532:"532 nm",785:"785 nm"}},band:{label:"맵 Raman shift",min:400,max:3100,step:10,value:1e3},parts:[ee("source","Excitation laser","여기 레이저","단색광을 조사합니다. 파장 변경은 피크 Raman shift 자체를 바꾸지 않습니다.","안전 인터록·출력 안정성과 파장 교정 기록을 확인합니다."),ee("optics","Objective / confocal","대물렌즈·공초점","시료에 집속하고 산란광을 수집합니다.","초점·시료 높이·공초점 정렬을 기준 시료와 비교합니다."),ee("sample","Si / polymer domains","Si·폴리머 가상 표면","Si 유사 피크와 폴리머 유사 피크를 합성했습니다. HBM 재료 동정 결과가 아닙니다.","오염·형광·레이저 손상 가능성을 검토합니다."),ee("filter","Rayleigh rejection","Rayleigh 차단 필터","강한 탄성 산란은 차단하고 Stokes 신호를 분광기로 전달합니다.","레이저 파장과 필터의 대응·누설을 확인합니다."),ee("detector","Grating / CCD","격자·분광 검출기","여러 Raman shift 채널을 동시에 적분합니다.","에너지축 교정·암신호·포화·검출기 상태를 확인합니다."),Xr,Gi,Wi],flow:"연속 레이저 → 탄성/비탄성 산란 → Rayleigh 제거 → 격자 분광 → CCD 전 채널 적분 → 스펙트럼/XY 맵",limits:"실제 Raman 산란 단면적·공명·온도·편광·형광·손상은 계산하지 않습니다. λ⁻⁴ 세기 스케일은 교육용 근사입니다. 스펙트럼은 전 채널 동시 적분의 8단계 누적이며 맵은 독립 위치별 대표 적분입니다. 합성 피크로 물질을 동정할 수 없습니다.",sources:[["HORIBA · Raman 검출 원리","https://www.horiba.com/int/scientific/technologies/raman-imaging-and-spectroscopy/raman-spectrometer-presentation/"]],guides:[en("fluorescence","넓은 배경·약한 피크",["source","sample","detector"],["암신호·포화와 기준 시료를 비교합니다.","여기 파장·형광·표면 오염 영향을 검토합니다.","출력 변경 전 시료 손상 가능성을 확인합니다."]),en("focus","맵 대비·공간 해상도 저하",["optics","stage","sample"],["초점과 XY 위치 반복성을 확인합니다.","시료 평탄도와 드리프트를 점검합니다.","관심 피크와 배경 채널을 비교합니다."])]},ftir:{name:"FTIR",tag:"FOURIER TRANSFORM INFRARED",heading:"간섭 신호에서, 흡수 스펙트럼으로.",intro:"배경을 먼저 취득하고 간섭신호를 Fourier 변환해 투과율과 흡광도를 계산합니다.",modes:{background:"Background",transmission:"Transmission",atr:"ATR · 유효 응답"},defaultMode:"background",duration:10,parameter:{label:"합성 광학 두께 / ATR 접촉 가중치",min:.2,max:2,step:.1,value:1,unit:"×"},selector:{label:"가상 폴리머",values:{pmma:"PMMA 유사",ps:"PS 유사"}},band:null,parts:[ee("source","Broadband IR source","광대역 IR 광원","여러 파수 성분을 동시에 조사합니다. 파수를 한 개씩 주사하지 않습니다.","광원·퍼지·배경 안정성을 확인합니다."),ee("splitter","Beam splitter","빔 분할기","빛을 고정/이동 거울의 두 팔로 나누고 다시 합칩니다.","정렬·재질 범위·오염·습기 영향을 확인합니다."),ee("fixed","Fixed mirror","고정 거울","기준 광학 경로를 구성합니다.","광학 정렬과 기준 간섭 신호를 확인합니다."),ee("moving","Moving mirror","이동 거울","광로차(OPD)를 바꾸어 간섭 신호를 생성합니다. OPD 변화는 거울 이동의 두 배입니다.","스캔 구동·위치 기준·진동 경보를 확인합니다."),ee("sample","Transmission / ATR","투과 셀·ATR 결정","투과 시료 또는 ATR 표면 접촉의 유효 흡수 응답을 비교합니다.","투과창 오염·시료 두께 또는 ATR 접촉·결정 손상을 확인합니다."),ee("detector","IR detector","IR 검출기","파장별 순차 검출이 아니라 합쳐진 간섭 신호를 읽습니다.","암신호·포화·배경과 샘플 광학 경로를 확인합니다."),Gi,Wi],flow:"광대역 IR → 두 팔의 광로차 → 재결합 → 시료/ATR → 간섭신호 → DFT → 샘플/배경 → T와 A=−log₁₀T",limits:"256개 광로차 표본과 이산 Fourier 변환을 실제로 계산합니다. 이상적인 주기 경계·잡음 없는 32 cm⁻¹ 격자입니다. ATR은 유효 흡수/접촉 가중치 근사이며 침투 깊이·굴절률·Fresnel·실제 ATR 보정은 계산하지 않습니다. PMMA/PS 피크는 교육용 근사입니다.",sources:[["Thermo Fisher · FTIR 원리","https://www.thermofisher.com/us/en/home/industrial/spectroscopy-elemental-isotope-analysis/molecular-spectroscopy/fourier-transform-infrared-spectroscopy/faqs.html"],["Shimadzu · FT와 배경 비","https://www.ssi.shimadzu.com/service-support/technical-support/analysis-basics/tips-ftir/apodization.html"]],guides:[en("background","음의 흡광도·배경 불일치",["source","sample","control"],["동일 액세서리/경로에서 새 배경을 취득합니다.","퍼지·수분·CO₂·온도 변화를 확인합니다.","샘플과 배경의 조건·시점을 비교합니다."]),en("interferogram","간섭 신호 이상",["splitter","fixed","moving","detector"],["기준 간섭신호와 중심 버스트를 비교합니다.","정렬·거울 구동·진동·포화 경보를 확인합니다.","광학부 개방 없이 승인된 서비스 절차를 따릅니다."])]},afmir:{name:"AFM-IR",tag:"PHOTOTHERMAL NANOSPECTROSCOPY",heading:"흡수한 빛을, 팁의 진동으로.",intro:"IR 펄스·국소 열팽창·캔틸레버 진동의 순서를 따라 나노화학 신호를 읽습니다.",modes:{spectrum:"Local IR spectrum",map:"Chemical map"},defaultMode:"spectrum",duration:16,parameter:{label:"가상 접촉 기계응답 가중치",min:.3,max:2,step:.1,value:1,unit:"×"},selector:{label:"가상 도메인",values:{pmma:"PMMA 유사 / PS 유사",ps:"PS 유사 / PMMA 유사"}},band:{label:"맵 IR 파수",min:900,max:1900,step:10,value:1730},parts:[ee("source","Pulsed tunable IR","펄스 가변 IR 광원","선택 파수의 펄스를 팁 주변 시료에 조사합니다.","파수·출력 정규화·펄스 동기와 인터록을 확인합니다."),ee("reader","Optical lever laser","광학 읽기 레이저","별도 가시광 레이저로 캔틸레버 진동을 읽습니다. IR을 직접 검출하는 경로가 아닙니다.","반사 광점·수광량·검출기 정렬을 확인합니다."),ee("probe","Contact cantilever / tip","접촉 캔틸레버·팁","시료 열팽창에 의해 진동하며 접촉 기계응답의 영향을 받습니다.","팁 마모·접촉 안정성·접촉 공진과 기준 시료를 확인합니다."),ee("piezo","Z feedback scanner","Z 피드백 스캐너","합성 지형을 따라 평균 접촉 위치를 유지합니다. 고주파 IR 응답과 구분합니다.","Z 범위·추종 안정성·지형 교차 영향을 점검합니다."),ee("sample","Polymer nanodomains","가상 폴리머 나노 도메인","IR 흡수 가중치와 표면 높이는 별도 함수입니다. 화학 맵은 지형 맵이 아닙니다.","두께·열·기계응답·파수 의존성을 비교합니다."),ee("detector","Photodiode / demodulation","광검출·진동 응답 처리","광학 레버로 읽은 진동 응답을 파수/위치와 연결합니다.","검출 수광량·진동 배경·동기/정규화 조건을 확인합니다."),Xr,Gi,Wi],flow:"IR 펄스 → 국소 흡수·열팽창 → 접촉 캔틸레버 진동 → 별도 광학 레버 → 진동 응답 → 스펙트럼/맵",limits:"접촉 photothermal AFM-IR의 대표 펄스/감쇠 진동입니다. 특정 RE/PLL·tapping·s-SNOM 구현이 아닙니다. 지도 한 주기는 독립 위치 16개 묶음이며 실제 펄스율이 아닙니다. 기계·열·두께 영향을 모두 흡수 계수로 해석할 수 없고 모델은 진동 응답 가중치만 사용합니다.",sources:[["Bruker · photothermal AFM-IR","https://www.bruker.com/en/products-and-solutions/infrared-and-raman/nanoscale-infrared-spectrometers/re-afm-ir.html"]],guides:[en("cross","지형과 화학 맵이 함께 변함",["probe","piezo","sample"],["높이와 진동 응답을 구분해 비교합니다.","접촉 안정성·기계응답·두께 영향을 검토합니다.","서로 다른 파수와 기준 재료를 비교합니다."]),en("weak","IR 응답 약화",["source","reader","probe","detector"],["읽기 레이저 수광량·정렬을 확인합니다.","IR 조사 위치·파수·출력·동기를 확인합니다.","접촉 상태·팁과 기준 시료 응답을 비교합니다."])]}},Ye=(i,t,e)=>Math.exp(-.5*((i-t)/e)**2),lo=(i,t)=>Math.min(1,.08+.9*Ye(i,.35,.16)*Ye(t,.53,.23)+.6*Ye(i,.76,.11)*Ye(t,.3,.12)),v_=(i,t)=>12+35*Ye(i,.57,.18)*Ye(t,.46,.18)+8*Math.sin(i*12)*Math.sin(t*9);function Va(i,t="pmma"){return .015+(t==="pmma"?[[1730,.85,32],[1140,.45,45],[1450,.18,40],[2950,.3,65]]:[[1600,.6,28],[1490,.4,28],[1025,.3,30],[3030,.5,45]]).reduce((n,[s,r,a])=>n+r*Ye(i,s,a),0)}function Dl(i,t=.35,e=.53,n=532,s=1){const r=lo(t,e);return .008+((1-r)*Ye(i,520,12)+r*s*(.85*Ye(i,1e3,18)+.55*Ye(i,1600,28)+.7*Ye(i,2900,60)))*(532/n)**4}function Yr(i,t,e,n,s=1){const r=lo(t,e);return s*(r*Va(i,n)+(1-r)*Va(i,n==="pmma"?"ps":"pmma"))}function Ga(i,t=1e3,e="silicon"){const n={silicon:12,copper:3,polymer:.25}[e],s=Math.sqrt(t*1e3/(n*24.5)),r=s/.8,a=.6*r;if(i<.08)return{load:0,depth:0,phase:"approach",maximum:r,residual:a};if(i<.55){const o=(i-.08)/.47;return{load:t*o**2,depth:r*o,phase:"loading",maximum:r,residual:a}}if(i<.7)return{load:t,depth:r,phase:"hold",maximum:r,residual:a};if(i<.95){const o=(i-.7)/.25;return{load:t*(1-o)**1.5,depth:a+(r-a)*(1-o),phase:"unloading",maximum:r,residual:a}}return{load:0,depth:a,phase:"retract",maximum:r,residual:a}}function x_(i,t){const{maximum:e,residual:n}=Ga(.6,i,t),s=1.5*i/(e-n),r=e-.75*i/s,a=24.5*r**2;return{hardness:i*1e3/a,reducedModulus:1e3*Math.sqrt(Math.PI)*s/(2*1.034*Math.sqrt(a)),stiffness:s,contactDepth:r,area:a}}function M_(i="void"){return[{x:0,y:0,radius:.8,mu:1},{x:.35,y:.13,radius:.16,mu:1.4},{x:-.3,y:-.24,radius:.2,mu:i==="void"?-.95:0}]}function S_(i,t="void",e=1,n=48){return Array.from({length:n},(s,r)=>{const a=-1+2*r/(n-1),o=M_(t).reduce((c,l)=>{const u=a-l.x*Math.cos(i)-l.y*Math.sin(i);return c+(Math.abs(u)<l.radius?2*l.mu*Math.sqrt(l.radius**2-u**2):0)},0)*e;return{offset:a,line:o,transmission:Math.exp(-o)}})}function Pc(i,t=48){const e=new Float64Array(t*t);if(!i.length)return e;const n=2/(t-1),s=i.map(r=>r.projection.map((a,o)=>r.projection.reduce((c,l,u)=>{const f=o-u,d=f===0?1/(4*n**2):Math.abs(f)%2===1?-1/(Math.PI**2*f**2*n**2):0;return c+l.line*d*n},0)));for(let r=0;r<t;r++)for(let a=0;a<t;a++){const o=-1+2*a/(t-1),c=-1+2*r/(t-1);if(o*o+c*c>1)continue;let l=0;for(let u=0;u<i.length;u++){const f=(o*Math.cos(i[u].angle)+c*Math.sin(i[u].angle)+1)/n,d=Math.floor(f),p=f-d;d>=0&&d<t-1&&(l+=s[u][d]*(1-p)+s[u][d+1]*p)}e[r*t+a]=l*Math.PI/48}return e}const Ke=256,co=32;function E_(i,t=1,e="transmission",n=!1){return Array.from({length:Ke/2},(s,r)=>{const a=r*co,o=.4+.6*Ye(a,1800,1600),c=Va(a,i)*t*(e==="atr"?1200/Math.max(600,a):1);return n?o:o*10**-c})}function y_(i){return Array.from({length:Ke},(t,e)=>i.reduce((n,s,r)=>n+(r===0?s:2*s*Math.cos(2*Math.PI*r*e/Ke)),0)/Ke)}function b_(i){if(i.length!==Ke)throw new RangeError("Complete interferogram required");return Array.from({length:Ke/2},(t,e)=>{let n=0,s=0;for(let r=0;r<Ke;r++)n+=i[r]*Math.cos(2*Math.PI*e*r/Ke),s-=i[r]*Math.sin(2*Math.PI*e*r/Ke);return Math.hypot(n,s)})}function T_(i,t){return i.map((e,n)=>{const s=e/Math.max(1e-12,t[n]);return{axis:n*co,value:-Math.log10(Math.max(1e-12,s)),transmittance:s}})}class A_{constructor(t){var e;if(!Pl[t])throw new RangeError("Unknown instrument");this.kind=t,this.config=Pl[t],this.mode=this.config.defaultMode,this.parameter=this.config.parameter.value,this.sample=Object.keys(this.config.selector.values)[0],this.band=((e=this.config.band)==null?void 0:e.value)??0,this.accessory="transmission",this.backgrounds={},this.reset()}get total(){return this.kind==="xrm"?this.mode==="ct"?48:1:this.kind==="nanoindenter"?240:this.kind==="ftir"?Ke:this.mode==="map"?1024:this.kind==="raman"?8:64}get duration(){return this.kind==="xrm"&&this.mode==="radiograph"?2:this.config.duration}get progress(){return this.index/this.total}get background(){return this.backgrounds[this.accessory]}reset(){this.index=0,this.elapsed=0,this.status="idle",this.rows=[],this.spectrum=[],this.integrationHistory=[],this.reconstruction=null,this.error="",this.ftSignal=null}configure(t){if("mode"in t&&!Object.hasOwn(this.config.modes,t.mode))throw new RangeError("Unknown mode");if("sample"in t&&!Object.hasOwn(this.config.selector.values,t.sample))throw new RangeError("Unknown sample");if("parameter"in t&&(!Number.isFinite(t.parameter)||t.parameter<this.config.parameter.min||t.parameter>this.config.parameter.max))throw new RangeError("Invalid parameter");if("band"in t&&(!this.config.band||!Number.isFinite(t.band)||t.band<this.config.band.min||t.band>this.config.band.max))throw new RangeError("Invalid band");for(const e of["mode","sample","parameter","band"])e in t&&(this[e]=t[e]);this.kind==="ftir"&&this.mode!=="background"&&(this.accessory=this.mode),this.reset()}start(){return this.kind==="ftir"&&this.mode!=="background"&&!this.background?(this.error="현재 액세서리의 Background를 먼저 취득하세요.",!1):(this.status==="complete"&&this.reset(),this.error="",this.status="scanning",this.kind==="ftir"&&!this.ftSignal&&(this.ftSignal=y_(E_(this.sample,this.parameter,this.accessory,this.mode==="background"))),!0)}pause(){this.status==="scanning"&&(this.status="paused")}clearBackground(){this.backgrounds={},this.reset()}get cycleCount(){return this.kind==="afmir"&&this.mode==="map"?64:this.total}get cycle(){return Math.min(this.cycleCount-1,Math.floor(this.elapsed/this.duration*this.cycleCount))}get cyclePhase(){const t=this.elapsed/this.duration*this.cycleCount;return t-Math.floor(t)}get coordinate(){const t=Math.min(this.total-1,this.status==="complete"?this.total-1:this.kind==="afmir"?this.cycle*(this.mode==="map"?16:1):Math.max(0,this.index-1));return this.mode==="map"?{x:t%32/31,y:Math.floor(t/32)/31}:{x:.35,y:.53}}get angle(){return this.kind!=="xrm"?0:this.mode==="radiograph"?Math.PI/6:this.status==="complete"?this.rows.at(-1).angle:Math.max(0,this.cycle-1+Math.min(1,this.cyclePhase/.35))*Math.PI/48}get phase(){return this.status==="idle"||this.status==="complete"?this.status:this.kind==="nanoindenter"?Ga(this.elapsed/this.duration,this.parameter,this.sample).phase:this.kind==="xrm"?this.mode==="ct"&&this.cyclePhase<.35?"rotate":"expose":this.kind==="afmir"?this.cyclePhase<.12?"pulse":this.cyclePhase<.25?"expansion":this.cyclePhase<.85?"ringdown":"record":this.kind==="ftir"?"interferogram":"integrate"}get signals(){const t=this.status==="scanning";return this.kind==="afmir"?{input:t&&this.phase==="pulse",output:t&&["expansion","ringdown"].includes(this.phase)}:{input:t&&this.phase!=="rotate",output:t&&this.phase!=="rotate"}}get currentResponse(){const{x:t,y:e}=this.coordinate;return Yr(this.mode==="map"?this.band:900+1e3*this.cycle/63,t,e,this.sample,this.parameter)}tick(t){if(this.status!=="scanning"||!Number.isFinite(t)||t<=0)return;this.elapsed=Math.min(this.duration,this.elapsed+t);const e=this.elapsed/this.duration*this.cycleCount,n=this.kind==="afmir"?Math.min(this.total,(Math.floor(e)+(e%1+1e-8>=.9?1:0))*(this.mode==="map"?16:1)):Math.min(this.total,Math.floor(this.elapsed/this.duration*this.total+1e-8));for(;this.index<n;)this.acquire(this.index),this.index++;this.elapsed>=this.duration-1e-8&&(this.elapsed=this.duration,this.status="complete",this.finish())}acquire(t){if(this.kind==="xrm"){const s=this.mode==="ct"?t*Math.PI/48:Math.PI/6,r=S_(s,this.sample,this.parameter);this.rows.push({axis:s*180/Math.PI,angle:s,projection:r}),this.mode==="ct"&&(this.reconstruction=Pc(this.rows));return}if(this.kind==="nanoindenter"){const s=t/(this.total-1),r=Ga(s,this.parameter,this.sample);this.rows.push({axis:s*this.duration,value:r.load,...r});return}if(this.kind==="ftir"){this.rows.push({axis:t/(Ke*co),value:this.ftSignal[t]});return}if(this.kind==="raman"&&this.mode==="spectrum"){this.rows=Array.from({length:256},(s,r)=>{const a=100+3100*r/255;return{axis:a,value:Dl(a,.35,.53,Number(this.sample),this.parameter)*(t+1)/8,frame:t+1}}),this.integrationHistory.push({x:(t+1)*this.duration/8,y:this.rows.reduce((s,r)=>s+r.value,0)});return}const e=t%32/31,n=Math.floor(t/32)/31;if(this.mode==="map"){const s=this.kind==="raman"?Dl(this.band,e,n,Number(this.sample),this.parameter):Yr(this.band,e,n,this.sample,this.parameter);this.rows.push({axis:t,x:e,y:n,value:s,height:v_(e,n),domain:lo(e,n)})}else{const s=900+1e3*t/63;this.rows.push({axis:s,value:Yr(s,.35,.53,this.sample,this.parameter)})}}finish(){if(this.kind==="ftir"){const t=b_(this.rows.map(e=>e.value));this.mode==="background"?this.backgrounds[this.accessory]=t:this.spectrum=T_(t,this.background).filter(e=>e.axis>=600&&e.axis<=3600)}}get results(){return this.kind==="nanoindenter"&&this.elapsed/this.duration>=.95?x_(this.parameter,this.sample):null}metadata(){return{instrument:this.config.name,mode:this.mode,sample:this.sample,parameter:this.parameter,band_cm_1:this.config.band?this.band:null,accessory:this.kind==="ftir"?this.accessory:null,background_ready:!!this.background,accumulation_steps:this.kind==="raman"&&this.mode==="spectrum"?this.index:null,synthetic:!0,units:this.kind==="nanoindenter"?"load_uN_depth_nm":this.kind==="xrm"?"angle_deg_detector_normalized_transmission_ratio":this.kind==="ftir"?"OPD_cm_absorbance_and_transmittance":"wavenumber_cm_1_response_au",timing:"expanded_representative_not_hardware_timing",limitations:this.config.limits}}csv(){const t=["record","index","axis","axis_unit","x","y","value","transmission","load_uN","depth_nm","height_nm","phase","metadata"],e=JSON.stringify(this.metadata()),n=r=>'"'+String(r??"").replaceAll('"','""')+'"',s=[];return this.rows.forEach((r,a)=>{if(this.kind==="xrm")for(const o of r.projection)s.push(["projection",a,r.axis,"angle_deg",o.offset,"",o.line,o.transmission,"","","",""]);else s.push(["measured",a,r.axis,this.kind==="ftir"?"OPD_cm":this.kind==="nanoindenter"?"time_s":this.mode==="map"?"pixel_index":"cm^-1",r.x,r.y,r.value,"",r.load,r.depth,r.height,r.phase])}),this.kind==="ftir"&&this.spectrum.forEach((r,a)=>s.push(["derived_absorbance",a,r.axis,"cm^-1","","",r.value,r.transmittance,"","","",""])),[t.join(","),...s.map(r=>[...r,e].map(n).join(","))].join(`
`)}}function qs(i,t){return JSON.stringify([i,...(i==="fib"?["rate","imageDepth"]:["mode","surface","gain","rate","defocus","sample","center","width","x","y","thickness","exposureThickness","reflection","exposureReflection","spacingIn","spacingOut","roughness","technology","polarity","species","region","passEnergy","neutralizer","matrix","parameter","band","accessory","voltage","charge"]).map(n=>[n,t[n]])])}function Dc(i){const t=new Float64Array(700);for(const e of i){const n=Math.floor(e.massToCharge*10);n>=0&&n<t.length&&t[n]++}return Array.from(t,(e,n)=>({axis:(n+.5)/10,value:e}))}const w_=(i,t,e)=>i.map(n=>({...n,massToCharge:Bl(n.tof+t*45,e)}));function wn(i,t,e,n,s={}){return{shape:"grid",width:i,height:t,values:Float64Array.from(e),label:n,axisLabel:"정규화 XY / 취득 순서",valueLabel:"응답 (a.u.)",...s}}function pn(i,t,e,n,s={}){return{shape:"curve",points:i.map(r=>({...r})),label:t,axisLabel:e,valueLabel:n,...s}}function Lc(i,t){var r;let e;if(i==="afm")e=wn(t.size,t.size,t.trace,"Trace 높이맵 · Z 추종 결과",{valueLabel:"높이 (nm)",channel:"Trace"});else if(i==="sem")e=wn(t.size,t.size,t.pixels,`${t.mode.toUpperCase()} 영상`);else if(i==="fib")e=wn(t.size,t.size,t.image,"취득된 SEM 영상 · 가공 스냅샷",{mode:"imaging",capturedDepth:t.imageDepth*180});else if(i==="sam")t.mode==="a"?e=pn(Array.from(t.values).slice(0,t.index).map((a,o)=>({axis:-20+300*o/(t.total-1),value:a})),"A-Scan RF","전면 기준 시간 (ns)","RF 응답 (a.u.)"):e=wn(t.size,t.mode==="b"?t.depthRows:t.size,t.values,t.mode==="b"?"B-Scan · RF 단면":t.mode==="through"?"Through · 투과 응답":"C-Scan · 수신 게이트 응답");else if(i==="apt")e=pn(Dc(t.rows),"APT · 동일 취득 이온의 질량 히스토그램","m/z (Da/e)","이벤트 수",{events:t.rows.map(a=>({...a})),voltage:t.voltage});else if(i==="xrd")e=pn(t.values.map(a=>({axis:a.x,value:a.y})),`${t.mode.toUpperCase()} 곡선`,t.mode==="xrr"?"θ (deg)":"2θ (deg)","강도 (a.u.)",{log:t.mode==="xrr"});else if(i==="tem"){if(t.progress<=0)return null;if(t.mode==="eels")e=pn(Array.from({length:401},(a,o)=>({axis:o*2,value:bc(o*2,t.exposureThickness)*t.progress})),"EELS · 현재 누적 신호","에너지 손실 (eV)","강도 (a.u.)",{log:!0});else{const o=new Float64Array(16384).fill(NaN);for(let c=0;c<128;c++)for(let l=0;l<128;l++){if(t.mode==="stem"&&Math.floor(c/2)*64+Math.floor(l/2)>=Math.floor(t.progress*4096))continue;const u=l/127,f=c/127;o[c*128+l]=(t.mode==="image"?qg(u,f,t.exposureThickness):t.mode==="df"?Xg(u,f,t.exposureThickness,t.exposureReflection):t.mode==="diffraction"?jg(u,f,t.exposureThickness):Yg(u,f,t.exposureThickness))*(t.mode==="stem"?1:t.progress)}e=wn(128,128,o,`${t.mode.toUpperCase()} · 현재 누적 영상`)}}else if(i==="xps"||i==="sims")if(t.mode==="image"){const a=new Float64Array(4096).fill(NaN);t.rows.forEach((o,c)=>a[c]=o.value),e=wn(64,64,a,"선택 이온 XY 맵")}else e=pn(t.rows.map(a=>({axis:a.axis,value:a.value})),t.mode==="depth"?"명목 깊이 응답":i==="xps"?"XPS 에너지 스펙트럼":"SIMS 질량 스펙트럼",t.mode==="depth"?"명목 깊이 (nm)":i==="xps"?"결합 에너지 (eV)":"m/z (Da/e)","응답 (a.u.)",{reverse:i==="xps"&&t.mode!=="depth"});else if(i==="xrm"){const a=t.rows.map(o=>({...o,projection:o.projection.map(c=>({...c}))}));t.mode==="ct"&&t.reconstruction?e=wn(48,48,t.reconstruction,"CT · 취득 투영의 FBP 단면",{projections:a}):a.length&&(e=pn(a.at(-1).projection.map(o=>({axis:o.offset,value:o.transmission})),"Radiography · 최근 한 행 투과율","검출기 정규화 위치","I / I₀",{projections:a}))}else if(i==="ftir"){if(!t.spectrum.length)return null;e=pn(t.spectrum.map(a=>({axis:a.axis,value:a.value})),`${t.accessory.toUpperCase()} · 변환된 흡광도`,"파수 (cm⁻¹)","흡광도 A",{reverse:!0})}else if(i==="nanoindenter")e=pn(t.rows.map(a=>({axis:a.depth,value:a.load,time:a.axis,phase:a.phase})),"P–h · 취득 순서 보존","압입 깊이 (nm)","하중 (μN)");else if(i==="raman"||i==="afmir")if(t.mode==="map"){const a=new Float64Array(1024).fill(NaN),o=new Float64Array(1024).fill(NaN);t.rows.forEach((c,l)=>{a[l]=c.value,o[l]=c.height}),e=wn(32,32,a,`${t.band} cm⁻¹ 응답 맵`,{heights:o})}else e=pn(t.rows.map(a=>({axis:a.axis,value:a.value})),i==="raman"?"동시 채널 누적 Raman":"국소 AFM-IR 스펙트럼",i==="raman"?"Raman shift (cm⁻¹)":"IR 파수 (cm⁻¹)","응답 (a.u.)");if(!e)return null;const n=e.shape==="grid"?Array.from(e.values).filter(Number.isFinite).length:e.points.filter(a=>Number.isFinite(a.value)).length,s=i==="fib"?Math.floor(t.scan*t.size**2):i==="tem"?Math.floor(t.progress*4096):t.index??((r=t.values)==null?void 0:r.length)??0;return!n||!s?null:{...e,kind:i,mode:e.mode??t.mode??"scan",technology:t.technology,acquired:s,provenance:"acquired",conditions:qs(i,t)}}function R_(i,t){var r;const e={afm:()=>new kg,apt:()=>new zl,fib:()=>new Vg,tem:()=>new $g,xrd:()=>new Qg,sem:()=>new i_,sam:()=>new h_,xps:()=>new p_,sims:()=>new __},n=((r=e[i])==null?void 0:r.call(e))??new A_(i);if(i==="afm"){for(const a of["surface","gain","rate"])n[a]=t[a];n.start(),n.tick(2),n.tick(2e3)}else if(i==="fib")n.startMilling(),n.tick(5),n.startImaging(),n.tick(10);else if(i==="tem")n.configure({mode:t.mode,thickness:t.thickness,reflection:t.reflection}),n.start(),n.tick(100);else if(i==="xrd"){for(const a of["mode","spacingIn","spacingOut","thickness","roughness"])n[a]=t[a];n.start(),n.tick(100)}else if(i==="sem")n.configure(t.mode,t.defocus),n.start(),n.tick(100);else{const a={apt:["mode","voltage","charge"],sam:["mode","sample","center","width","x","y"],xps:["mode","region","thickness","charge","neutralizer","passEnergy"],sims:["mode","polarity","species","thickness","matrix"]}[i]??["mode","sample","parameter","band"];i==="sims"&&n.setTechnology(t.technology);const o=Object.fromEntries(a.filter(c=>{var l;return t[c]!==void 0&&(c!=="band"||((l=t.config)==null?void 0:l.band))}).map(c=>[c,t[c]]));i==="ftir"?(n.configure({...o,mode:t.accessory}),n.configure({mode:"background"}),n.start(),n.tick(100),n.configure({mode:t.accessory})):n.configure(o),n.start(),n.tick(100)}const s=Lc(i,n);return s?{...s,provenance:"reference_demo",label:"고정 합성 예시 · "+s.label}:null}const Ll=i=>Math.sin(i*12.9898+78.233)*Math.cos(i*4.1414),Hs=(i,t,e)=>Math.exp(-.5*((i-t)/e)**2);function qr(i){let t=1/0,e=-1/0;for(const n of i)Number.isFinite(n)&&(t=Math.min(t,n),e=Math.max(e,n));return{low:t,high:e,span:Math.max(e-t,Math.abs(e)*.05,1e-9)}}function C_(i,t){let e=0,n=0;for(let s=i.shape==="grid"?-2:0;s<=(i.shape==="grid"?2:0);s++)for(let r=-2;r<=2;r++){const a=i.shape==="grid"?t%i.width+r:t+r,o=i.shape==="grid"?Math.floor(t/i.width)+s:0;if(a<0||a>=(i.shape==="grid"?i.width:i.points.length)||o<0||o>=(i.shape==="grid"?i.height:1))continue;const c=i.shape==="grid"?i.values[o*i.width+a]:i.points[a].value;Number.isFinite(c)&&(e+=c,n++)}return n?e/n:NaN}function P_(i,t,e=.6){var f;if(!Number.isFinite(e)||e<0||e>1)throw new RangeError("Severity must be between zero and one");if(!i)return null;if(t&&!yc(t,i))throw new RangeError("Fault is incompatible with this data channel");const n={...i,...i.shape==="grid"?{values:Float64Array.from(i.values)}:{points:i.points.map(d=>({...d}))},fault:{id:(t==null?void 0:t.id)??"none",severity:e,training:!0}};if(!t||e===0)return n;const s=e,r=t.transform,a=i.shape==="grid"?Array.from(i.values):i.points.map(d=>d.value),o=qr(a),c=i.shape==="curve"?qr(i.points.map(d=>d.axis)):null;if(r==="apt-time"||r==="apt-loss"){const d=r==="apt-time"?w_(i.events,s,i.voltage):i.events.filter((p,g)=>!(p.hitX>-.2&&g*37%101/101<s*.85));return n.events=d,n.points=Dc(d),n.fault.retained=d.length,n}if(r.startsWith("xrm-"))return n.projections=i.projections.map(d=>({...d,projection:d.projection.map((p,g)=>{var m,h;let v=p.line;if(r==="xrm-column")v+=s*.7*Hs(g,31,.65);else{const T=g-s*2,b=Math.floor(T),E=T-b;v=(((m=d.projection[b])==null?void 0:m.line)??0)*(1-E)+(((h=d.projection[b+1])==null?void 0:h.line)??0)*E}return{...p,line:v,transmission:Math.exp(-v)}})})),i.shape==="grid"?n.values=Pc(n.projections,i.width):n.points=n.projections.at(-1).projection.map(d=>({axis:d.offset,value:d.transmission})),n;const l=i.heights?qr(i.heights):null,u=((f=i.points)==null?void 0:f.reduce((d,p)=>Math.max(d,p.time??0),0))??1;for(let d=0;d<a.length;d++){const p=a[d];if(!Number.isFinite(p))continue;const g=d/Math.max(1,a.length-1),v=i.shape==="grid"?d%i.width:0,m=i.shape==="grid"?Math.floor(d/i.width):0;let h=p;if(r==="blur"||r==="xps-charge")h=p*(1-s)+C_(i,d)*s;else if(r==="double"){const T=v>=5?i.values[d-5]:NaN;Number.isFinite(T)&&(h=p+s*(Math.max(p,T)-p))}else r==="stripes"?h+=s*o.span*.25*Math.sin(m*1.7):r==="curtain"?h+=s*o.span*.25*(Math.sin(v*1.3)+.35*Math.cos(v*2.7)):r==="charging"?h=Math.max(0,Math.min(1,p+s*.4*(Math.sin(m*.7)+.7))):r==="attenuate"?h*=1-s*.8:r==="noise"?h+=s*o.span*(.15+.3*Ll(d)):r==="background"?h+=s*o.span*.18*(1+.1*Math.sin(d*.12)):r==="low-snr"?h=p*(1-.75*s)+s*o.span*(.2+.12*Ll(d)):r==="fluorescence"?h+=s*o.span*(.3+1.5*Hs(g,.65,.3)):r==="ftir-background"?h+=s*(.15*(g-.5)+.4*Hs(i.points[d].axis,2350,70)-.5*Hs(i.points[d].axis,1630,65)):r==="force-offset"?h+=s*o.high*.15:r==="height-cross"&&Number.isFinite(i.heights[d])&&(h+=s*o.span*.8*(i.heights[d]-l.low)/l.span);if(i.shape==="grid")n.values[d]=h;else{const T=n.points[d];T.value=h,r==="axis-shift"?T.axis+=s*c.span*.02:r==="xps-charge"?T.axis+=s*3:r==="mass-shift"?T.axis=(Math.sqrt(Math.max(0,T.axis))+s*.2)**2:r==="depth-drift"&&(T.axis+=s*c.high*.25*(T.time??g)/Math.max(u,1e-9))}}return n}function Il(i,t){const e=i.shape==="grid"?i.values:i.points.map(o=>o.value),n=t.shape==="grid"?t.values:t.points.map(o=>o.value);let s=0,r=0,a=0;for(let o=0;o<e.length;o++)Number.isFinite(e[o])&&Number.isFinite(n[o])&&(s+=Math.abs(e[o]-n[o]),i.shape==="curve"&&(a+=Math.abs(i.points[o].axis-t.points[o].axis)),r++);return{count:r,meanAbsoluteDifference:r?s/r:0,meanAxisDifference:r?a/r:0}}const Ul=i=>'"'+String(i??"").replaceAll('"','""')+'"';function D_(i,t){const e={training_only:!0,source:i.provenance,instrument:i.kind,mode:i.mode,axis:i.axisLabel,value:i.valueLabel,conditions:i.conditions,fault:t.fault,original_acquisition_unchanged:!0},n=["# "+JSON.stringify(e),"index,axis_original,axis_training,value_original,value_training"],s=i.shape==="grid"?i.values.length:i.points.length;for(let r=0;r<s;r++){const a=i.shape==="grid"?{axis:`${r%i.width}:${Math.floor(r/i.width)}`,value:i.values[r]}:i.points[r],o=i.shape==="grid"?{axis:a.axis,value:t.values[r]}:t.points[r];Number.isFinite(a.value)&&n.push([r,Ul(a.axis),Ul(o.axis),a.value,o.value].join(","))}return n.join(`
`)}function Vt(i,t,e){const n=document.createElement(i);return t!==void 0&&(n.textContent=t),e&&(n.className=e),n}function Wa(i){let t=1/0,e=-1/0;for(const n of i)Number.isFinite(n)&&(t=Math.min(t,n),e=Math.max(e,n));return[t,e>t?e:t+1]}const Xa=(i,t)=>i.log?Math.log10(Math.max(1e-8,t)):t;function Nl(i,t,e,n,s){const r=i.getContext("2d"),a=i.width,o=i.height;if(r.fillStyle="#101b28",r.fillRect(0,0,a,o),!t){r.fillStyle="#b6c8dc",r.font="15px sans-serif",r.fillText("취득 데이터 또는 고정 예시를 선택하세요",24,130);return}if(t.shape==="grid"){const[p,g]=n,v=(a-32)/t.width,m=(o-36)/t.height;for(let h=0;h<t.values.length;h++){const T=t.values[h];if(!Number.isFinite(T))continue;const b=Math.max(0,Math.min(1,(T-p)/(g-p)));r.fillStyle=`hsl(${235-235*b} 80% ${28+b*35}%)`,r.fillRect(16+h%t.width*v,10+Math.floor(h/t.width)*m,v+.3,m+.3)}r.fillStyle="#b6c8dc",r.font="12px sans-serif",r.fillText(`공통 색 범위 ${p.toPrecision(3)} ~ ${g.toPrecision(3)} · 미취득 공백`,16,o-8);return}const c=[...t.points,...(e==null?void 0:e.points)??[]],l=s??Wa(c.map(p=>p.axis)),[u,f]=n;r.strokeStyle="#5e748b",r.beginPath(),r.moveTo(48,15),r.lineTo(48,o-38),r.lineTo(a-14,o-38),r.stroke();const d=(p,g,v)=>{r.strokeStyle=g,r.lineWidth=2,r.setLineDash(v?[5,4]:[]),r.beginPath();let m=!1;for(const h of p){if(!Number.isFinite(h.value)){m=!1;continue}const T=(h.axis-l[0])/(l[1]-l[0]),b=48+(t.reverse?1-T:T)*(a-64),E=o-38-(Xa(t,h.value)-u)/(f-u)*(o-56);m?r.lineTo(b,E):r.moveTo(b,E),m=!0}r.stroke(),r.setLineDash([])};e&&d(e.points,"#72b9b4",!0),d(t.points,e?"#ff8b83":"#7de2b6",!1),r.fillStyle="#b6c8dc",r.font="11px sans-serif",r.fillText(f.toPrecision(3),2,17),r.fillText(u.toPrecision(3),2,o-38),r.fillText(t.axisLabel,50,o-9),r.fillText((t.reverse?l[1]:l[0]).toPrecision(3),48,o-24),r.fillText((t.reverse?l[0]:l[1]).toPrecision(3),a-60,o-24)}function L_({kind:i,engine:t,parts:e,selectPart:n,scene:s},r){var A;const a=typeof e=="function"?e:()=>e,o=document.getElementById("partName"),c=(o==null?void 0:o.closest(".inspector"))??(o==null?void 0:o.closest("section")),l=Vt("details",void 0,"part-lesson");l.open=!0,l.append(Vt("summary","부품 상세 · 입력에서 데이터까지"));const u=Vt("div");l.append(u),c==null||c.append(l);let f="";function d(){var ft;const Ct=a().find(Qt=>Qt.name===(o==null?void 0:o.textContent));if(!Ct)return;const gt=Ct.id+qs(i,t);if(gt===f)return;f=gt;const pt=Og(i,Ct,t);u.replaceChildren(),(ft=ti[i])!=null&&ft[Ct.id]||u.append(Vt("p","기본 역할과 점검 설명 · 일반화 모델","learning-muted"));for(const[Qt,_t]of[["input","입력"],["output","출력"],["mechanism","작동 원리"],["normal","기준 확인"],["signature","이상 시 보이는 단서"],["checks","점검 순서"],["chain","장비의 신호 경로"]])u.append(Vt("h4",_t),Vt("p",pt[Qt]));u.append(Vt("p",pt.scope,"learning-muted"))}d();const p=new MutationObserver(d);o&&p.observe(o,{childList:!0,subtree:!0,characterData:!0});const g=Vt("section",void 0,"learning-lab");g.id="learningLab",g.setAttribute("aria-label","학습용 이상 데이터 비교"),g.append(Vt("div","FAULT LEARNING · ORIGINAL DATA PRESERVED","learning-eyebrow"),Vt("h2","이상 데이터 실습"),Vt("p","원본 취득 기준 ↔ 학습용 왜곡을 비교합니다. 실제 고장 진단·정량 예측이 아니며 기존 그래프·원본 CSV·장비 상태는 바꾸지 않습니다. 원본 자체의 정상 여부도 보장하지 않습니다.","learning-warning"));const v=Vt("div",void 0,"learning-controls"),m=Vt("button","현재 취득 데이터"),h=Vt("button","고정 합성 예시"),T=Vt("label","문제 상황 "),b=Vt("select");b.id="faultScenario",T.htmlFor=b.id;const E=Vt("option","추가 왜곡 없음");E.value="",b.append(E);for(const Ct of Hr[i]){const gt=Vt("option",Ct.name);gt.value=Ct.id,b.append(gt)}T.append(b);const R=Vt("label","예시 강도 "),w=Vt("input"),C=Vt("output","60%");w.type="range",w.id="faultSeverity",w.min="0",w.max="100",w.value="60",R.htmlFor=w.id,R.append(w,C);const L=Vt("button","왜곡 해제"),S=Vt("button","비교 CSV · 학습용");v.append(m,h,T,R,L,S),g.append(v);const M=Vt("p",void 0,"learning-status");M.id="learningStatus",M.setAttribute("aria-live","polite"),g.append(M);const P=Vt("div",void 0,"learning-plots"),F=Vt("canvas"),k=Vt("canvas");for(const[Ct,gt]of[[F,"원본 취득 기준"],[k,"학습용 왜곡 · 점선은 원본"]]){Ct.width=480,Ct.height=290,Ct.setAttribute("aria-label",gt);const pt=Vt("figure");pt.append(Vt("figcaption",gt),Ct),P.append(pt)}g.append(P);const j=Vt("p",void 0,"learning-muted"),W=Vt("div",void 0,"learning-explanation"),Y=Vt("div",void 0,"learning-related");g.append(j,W,Y);const K=Vt("details");K.append(Vt("summary","원리 참고 자료 · 제조사/연구 자료"));for(const[Ct,gt]of Fg[i]??[]){const pt=Vt("a",Ct);pt.href=gt,pt.target="_blank",pt.rel="noopener noreferrer",K.append(pt)}g.append(K),(document.querySelector("main")??document.body).append(g);const st=Vt("button","이상 데이터 실습");st.type="button",st.onclick=()=>g.scrollIntoView({behavior:"smooth",block:"start"}),r.append(st);let V="acquired",at=null,Et="",ht=null,It=null,Dt="",G=[],$=[];const dt=(A=s==null?void 0:s.related)==null?void 0:A.bind(s);dt&&(s.related=Ct=>{G=[...Ct],dt([...new Set([...G,...$])])});function Ut(Ct){$=Ct,dt==null||dt([...new Set([...G,...$])])}function yt(){d();const Ct=qs(i,t);V==="reference_demo"&&Et!==Ct&&(at=R_(i,t),Et=Ct),ht=V==="reference_demo"?at:Lc(i,t);let gt=!1;const pt=ht??{mode:t.mode,shape:["map","image"].includes(t.mode)?"grid":"curve"};for(const kt of b.options){const y=Hr[i].find(_=>_.id===kt.value);kt.disabled=!!(y&&!yc(y,pt)),kt.title=kt.disabled?"현재 데이터 채널/모드에는 적용할 수 없습니다.":"",kt.selected&&kt.disabled&&(gt=!0)}gt&&(b.value="");const ft=Hr[i].find(kt=>kt.id===b.value),Qt=Number(w.value)/100;It=ht?P_(ht,ft,Qt):null,C.value=w.value+"%",S.disabled=!ht,m.setAttribute("aria-pressed",String(V==="acquired")),h.setAttribute("aria-pressed",String(V==="reference_demo")),M.textContent=(gt?"모드 변경: 호환되지 않는 왜곡을 해제했습니다. ":"")+(ht?`${V==="reference_demo"?"독립 고정 합성 예시 · 실제 취득 아님":"현재 취득 범위의 합성 데이터"} / ${ht.label} / ${ht.acquired} 취득 단위`:"아직 비교할 결과가 없습니다. 측정 시작 또는 고정 합성 예시를 선택하세요."+(i==="ftir"?" 같은 액세서리의 배경과 샘플 취득 완료 후 흡광도를 비교합니다.":""));const _t=ht?[...ht.shape==="grid"?ht.values:ht.points.map(kt=>Xa(ht,kt.value)),...It.shape==="grid"?It.values:It.points.map(kt=>Xa(It,kt.value))]:[],Bt=Wa(_t);P.querySelector("figure+figure figcaption").textContent=(ht==null?void 0:ht.shape)==="grid"?"학습용 왜곡 · 동일 색 범위":"학습용 왜곡 · 점선은 원본";const pe=(ht==null?void 0:ht.shape)==="curve"?Wa([...ht.points,...It.points].map(kt=>kt.axis)):null;if(Nl(F,ht,null,Bt,pe),Nl(k,It,ht,Bt,pe),j.textContent=ht?`공통 축/색 범위 · ${ht.valueLabel}${ht.log?" · 세로축 log₁₀ (표시 하한 10⁻⁸)":""} · 평균 |응답 차이| ${Il(ht,It).meanAbsoluteDifference.toPrecision(3)} · 평균 |축 차이| ${Il(ht,It).meanAxisDifference.toPrecision(3)}${It.fault.retained!==void 0?` · 보존 이벤트 ${It.fault.retained}/${ht.events.length}`:""} · 강도는 교육용 배율이며 고장 크기/확률이 아닙니다.`:"",W.replaceChildren(),Y.replaceChildren(),ft){for(const[kt,y]of[["appearance","화면에서 달라지는 점"],["cause","적용한 가정/변환"],["checks","확인 순서"],["confound","같이 고려할 다른 원인"]])W.append(Vt("h3",y),Vt("p",ft[kt]));for(const kt of ft.parts){const y=a().find(O=>O.id===kt);if(!y)continue;const _=Vt("button",y.ko??y.name);_.onclick=()=>{n(kt),c==null||c.scrollIntoView({behavior:"smooth",block:"center"})},Y.append(_)}Ut(ft.parts)}else W.append(Vt("p","문제 상황을 선택하면 관련 부품과 오해하기 쉬운 원인, 점검 순서가 함께 표시됩니다. 미취득 영역은 생성하지 않습니다.")),Ut([])}function Xt(){Dt="",yt()}m.onclick=()=>{V="acquired",Xt()},h.onclick=()=>{V="reference_demo",Et="",Xt()},b.onchange=Xt,w.oninput=Xt,L.onclick=()=>{b.value="",Xt()},S.onclick=()=>{if(!ht)return;const Ct=new Blob(["\uFEFF"+D_(ht,It)],{type:"text/csv;charset=utf-8"}),gt=URL.createObjectURL(Ct),pt=Vt("a");pt.href=gt,pt.download=i+"-training-comparison.csv",pt.click(),setTimeout(()=>URL.revokeObjectURL(gt),1e3)},yt();const Se=setInterval(()=>{var gt,pt;if(document.hidden)return;const Ct=JSON.stringify([qs(i,t),t.index,t.progress,t.scan,(gt=t.rows)==null?void 0:gt.length,(pt=t.values)==null?void 0:pt.length]);Ct!==Dt&&(Dt=Ct,yt())},350);window.addEventListener("pagehide",()=>{clearInterval(Se),p.disconnect()},{once:!0})}function I_(i,t,e){const n=document.querySelector("#homeButton,#resetCamera,#resetView"),s=document.querySelector("#explodeButton,#explode");if(!n||!s)throw new Error("Viewer toolbar missing");n.textContent="시점 초기화",n.setAttribute("aria-label","시점 초기화"),n.onclick=()=>i==null?void 0:i.home();let r=document.getElementById("focusButton");r||(r=document.createElement("button"),r.id="focusButton",r.type="button",r.setAttribute("aria-pressed","true"),s.before(r)),r.textContent="선택 강조",r.setAttribute("aria-label","선택 강조"),r.title="선택: 녹색 / 관련 부품: 황색 / 나머지: 반투명",r.onclick=()=>{const u=r.getAttribute("aria-pressed")!=="true";r.setAttribute("aria-pressed",String(u)),i==null||i.focus(u)},s.textContent="분해 보기",s.onclick=()=>{const u=s.getAttribute("aria-pressed")!=="true";s.setAttribute("aria-pressed",String(u)),i==null||i.explode(u)};const a=document.createElement("div");a.className="playback-controls";const o=document.createElement("label");o.htmlFor="playbackRate",o.textContent="재생 속도";const c=document.createElement("select");c.id="playbackRate",c.title="이 장비의 애니메이션과 가상 취득 속도입니다. 실제 측정 조건은 바뀌지 않습니다.";for(const u of Ec){const f=document.createElement("option");f.value=String(u),f.textContent=u+"×"+(u===.25?" · 학습 기본":""),c.append(f)}c.value=String(t.rate),c.onchange=()=>t.setRate(Number(c.value));const l=document.createElement("span");l.textContent="선택 녹색 · 관련 황색 · 속도 변경 시 취득 데이터 유지",o.append(c),a.append(o,l),document.getElementById("scene").before(a),document.addEventListener("visibilitychange",()=>t.resetTimestamp()),e&&L_({...e,scene:i},a)}const ji=new Ug,qt=new zl,Gt=i=>document.getElementById(i);let gn="reconstruction",$i="all",ye,jn;Gt("app").innerHTML=`<div class="app"><aside class="sidebar"><div class="brand"><span>✦</span><b>APT<em>lab</em></b></div><div class="eyebrow">ATOM PROBE WORKSPACE</div><h2>한 이벤트에서 3D까지</h2><p class="intro">전계 증발 · TOF · 위치 검출</p><div id="parts"></div><div class="side-footer">GENERALIZED MODEL<p>교육용 합성 데이터 · 실장비 연결 없음</p></div></aside><div class="workspace"><header><b>Workspace / Atom Probe Tomography</b><span>SIMULATION</span></header><main>
<div class="heading"><div><div class="eyebrow">EVAPORATE. DETECT. RECONSTRUCT.</div><h1>APT, 원자 이벤트를 공간으로.</h1><p>니들 끝에서 출발한 이온이 질량 신호와 3D 점군으로 쌓이는 과정을 탐색하세요.</p></div><button id="aboutButton">모델 안내</button></div>
<div class="layout"><div class="main-col"><section class="card"><div class="card-head"><strong>3D Explorer</strong><div class="buttons"><button id="homeButton">시점 초기화</button><button id="focusButton" aria-pressed="true">선택 강조</button><button id="explodeButton" aria-pressed="false">분해 보기</button></div></div><div id="scene"><div class="scene-label"><span>SELECTED COMPONENT</span><strong id="selectedLabel"></strong></div><p id="pulseStage" role="status"></p><div class="legend"><span><i class="laser-key"></i>레이저 펄스</span><span><i class="signal"></i>증발 이온</span><span><i class="ion"></i>전압 펄스</span></div><div id="webglError" hidden>WebGL 2 지원 브라우저에서 3D를 확인하세요.</div></div><div class="viewer-foot">드래그 회전 · 스크롤 확대 · 메쉬 클릭<span>치수·팁 소모·시간 확대 / 실제 궤적 아님</span></div></section>
<section class="card process"><div class="section-head"><div><div class="eyebrow">PULSED FIELD EVAPORATION</div><h3>펄스와 가상 취득</h3></div><span class="badge" id="status" role="status"></span></div><div class="mode-buttons" role="group" aria-label="APT 펄스 모드"><button data-mode="laser" aria-pressed="true">Laser-pulsed</button><button data-mode="voltage" aria-pressed="false">Voltage-pulsed</button></div><p id="modeDescription"></p><div class="fields"><label for="voltageInput">유효 가속전압 가정 <output id="voltageValue"></output><input type="range" id="voltageInput" min="2000" max="8000" step="500" value="5000"></label><label for="chargeSelect">모든 이온의 전하 상태 가정<select id="chargeSelect"><option value="1">1+ · 단일 전하</option><option value="2">2+ · 이중 전하</option></select></label></div><div class="mode-buttons"><button class="primary" id="startButton">취득 시작</button><button id="resetButton">새 가상 시료 / 초기화</button><button id="exportButton" disabled>CSV 저장</button></div><div class="progress"><i id="progress"></i></div><div class="image-meta"><span id="count"></span><span id="depthLabel"></span></div><p class="warning">파괴 분석입니다. 초기화는 실제 원자를 복원하는 것이 아니라 새 가상 니들로 교체합니다. 전압은 계산 예시이며 실장비 설정값이 아닙니다.</p><p class="fine">조건 변경은 취득 초기화 · 32개 대표 주기 / 시뮬레이션 12초. 한 주기는 독립적인 합성 이벤트 128개 묶음이며, 실제 한 펄스에서 128개 이온이 나온다는 뜻이 아닙니다. 입자 1개만 대표 표시하고 검출 후 묶음을 기록합니다.</p></section>
<section class="card chain"><div class="eyebrow">EVENT TO DATA</div><div class="flow" id="flow"></div><p class="flow-note" id="flowNote"></p><div class="check"><b>이상적 TOF 관계 · L = 0.10 m 가정</b><p id="equation"></p></div><p class="fine" id="eventReadout"></p></section></div>
<aside class="right-col"><section class="card observation"><div class="eyebrow">LIVE SYNTHETIC EVENTS</div><h3 id="plotTitle"></h3><p id="plotDescription"></p><div class="mode-buttons" role="group" aria-label="APT 데이터 보기"><button data-view="reconstruction" aria-pressed="true">3D 점군</button><button data-view="spectrum" aria-pressed="false">질량 스펙트럼</button><button data-view="detector" aria-pressed="false">검출 히트맵</button></div><div id="reconstruction" aria-label="합성 이벤트로 누적되는 회전 가능한 3D 점군"></div><canvas id="dataCanvas" width="520" height="380" aria-label="APT 합성 질량 또는 검출 이벤트" hidden></canvas><div class="element-legend">${Object.entries(er).map(([i,t])=>`<span style="--element:${t.color}">${i}</span>`).join("")}</div><label for="elementSelect">표시 원소 필터<select id="elementSelect"><option value="all">전체 Si · Cu · B</option><option value="Si">Si만</option><option value="Cu">Cu만</option><option value="B">B만</option></select></label><div class="image-meta"><span id="visibleCount"></span><button id="reconstructionHome">점군 시점 초기화</button></div><p class="fine">명목 반경 8 nm · 깊이 30 nm. XY 고정 역투영과 이벤트 순서로 만든 개념 점군이며 물리적 역산·정량 조성 지도가 아닙니다.</p></section>
<section class="card inspector"><div class="eyebrow">SELECTED COMPONENT</div><h3 id="partName"></h3><div id="partKo" class="part-ko"></div><p id="partRole"></p><div class="check"><b>점검 포인트</b><p id="partCheck"></p></div></section><section class="card maintenance"><div class="eyebrow">MAINTENANCE GUIDE</div><label for="symptomSelect">증상별 점검 · 관련 부품은 황색</label><select id="symptomSelect"><option value="">증상을 선택하세요</option>${kl.map(i=>`<option value="${i.id}">${i.name}</option>`).join("")}</select><div id="guide" class="guide"></div><p class="warning">고전압·레이저·초고진공·저온 장비입니다. 인터록 해제·전원부 개방·저온 부품 접촉을 하지 마세요. 제조사 절차와 교육받은 담당자를 따릅니다.</p></section></aside></div><footer><span>APT LAB / EVENT BY EVENT</span><span>합성 데이터 · 교정·정량·물질 동정·합격 판정 아님</span></footer></main></div></div>
<dialog id="aboutDialog"><button id="closeAbout" aria-label="안내 닫기">×</button><h2>APT 교육 모델의 범위</h2><p>APT(Atom Probe Tomography)는 니들형 시료의 펄스 전계 증발과 시간·위치 검출을 연결합니다. 이 예시는 레이저 보조와 전압 펄스를 시각적으로 구분하며 같은 합성 이벤트 시료를 사용합니다. 실제 장비에는 펄스 사이의 배경 증발도 있을 수 있습니다. 이 모델은 정상 펄스 유도 이벤트만 대표하며 두 모드의 성능 차이·온도·증발률을 계산하지 않습니다.</p><p>Cu-rich 0–8 nm 캡, Si 기지, 19 nm 부근 B-rich 분포가 있는 가상 니들입니다. 이온종·동위원소 비율·좌표는 교육용 임의 설정이며 실제 HBM 내부 분석 결과가 아닙니다. 실제 APT 시료는 별도 니들 준비가 필요합니다.</p><p>단일 이온의 도착 시간과 XY 히트를 함께 생성합니다. 0.10 m 직선 경로와 유효 가속전압·균일 전하 상태를 가정해 TOF와 m/z를 이상식으로 연결합니다. 시간 영점·전압 펄스 파형·에너지 분산·열 꼬리·질량 중첩·분자 이온·다중 히트·검출 효율은 계산하지 않습니다.</p><p>점군은 검출 XY의 고정 선형 역투영과 이벤트 순서 깊이입니다. 실제 팁 반경 변화·국소 배율·영상 압축·원자 부피 기반 재구성이 아니며 입력한 합성 구조를 점진 표시합니다. 파괴 분석을 되돌릴 수 없고 초기화·모드·조건 변경은 새 가상 시료입니다. 부품 치수·팁 소모·시간도 확대 표현입니다.</p><a href="https://www.cameca.com/Products/APT/Introduction-to-APT" target="_blank" rel="noreferrer">원리 참고 · CAMECA</a><br><a href="https://www.nist.gov/laboratories/tools-instruments/atom-probe-tomography-leap-4000x-sihr-local-electrode-atom-probe" target="_blank" rel="noreferrer">원리 참고 · NIST</a></dialog>`;function ei(i){const t=ss.find(e=>e.id===i);ye==null||ye.select(i);for(const[e,n]of[["selectedLabel",t.name],["partName",t.name],["partKo",t.ko],["partRole",t.role],["partCheck",t.check]])Gt(e).textContent=n;document.querySelectorAll("[data-part]").forEach(e=>e.setAttribute("aria-pressed",String(e.dataset.part===i)))}for(const i of ss){const t=document.createElement("button");t.className="part",t.dataset.part=i.id,t.textContent=i.name,t.onclick=()=>ei(i.id),Gt("parts").append(t)}try{ye=Dg(Gt("scene"),ss,ei),jn=Lg(Gt("reconstruction"))}catch(i){console.error(i),Gt("webglError").hidden=!1}ei("tip");for(const[i,t]of[["pulser","펄스 트리거"],["tip","전계 증발"],["flight","비행시간"],["detector","시간 + XY"],["tip","3D 재구성"]]){const e=document.createElement("button");e.textContent=t,e.onclick=()=>ei(i),Gt("flow").append(e)}function Un(){const i={idle:"대기",scanning:"취득 중",paused:"일시정지",complete:"취득 완료"},t=qt.rows.at(-1),e=qt.rows.filter(o=>$i==="all"||o.element===$i).length,n={idle:"대기",pulse:"펄스 입력",evaporation:"팁 전계 증발",flight:"이온 비행 · 입력 펄스는 꺼짐",detection:"검출 도착",waiting:"검출 묶음 기록 · 다음 트리거 대기",complete:"취득 완료"};Gt("pulseStage").textContent=`대표 주기 ${qt.sequence.cycle+1}/${qt.cycleCount} · ${n[qt.sequence.stage]}${qt.status==="paused"?" · 일시정지":""}`,Gt("status").textContent=i[qt.status],Gt("startButton").textContent=qt.status==="scanning"?"일시정지":qt.status==="paused"?"계속 취득":qt.status==="complete"?"다시 취득":"취득 시작",Gt("exportButton").disabled=!qt.index,Gt("count").textContent=`${qt.index.toLocaleString()} / 4,096 이벤트`,Gt("depthLabel").textContent=`명목 깊이 ${((t==null?void 0:t.z)||0).toFixed(1)} nm`,Gt("visibleCount").textContent=`표시 ${e.toLocaleString()}개 / 취득 ${qt.index.toLocaleString()}개`,Gt("progress").style.width=qt.progress*100+"%",Gt("voltageValue").textContent=(qt.voltage/1e3).toFixed(1)+" kV";const s=qt.mode==="laser";Gt("modeDescription").textContent=s?"Laser-pulsed: 정전 바이어스가 걸린 팁에 레이저 펄스를 조사해 전계 증발을 유도하는 개념입니다.":"Voltage-pulsed: 정전 바이어스에 전압 펄스를 더해 전계 증발을 유도하는 개념입니다. 이 모드에서는 레이저 선을 숨깁니다.",Gt("flowNote").textContent=`${s?"레이저 보조":"전압 펄스"} 전계 증발 → 이온 비행 → 시간·위치 동시 검출 → m/z 및 합성 3D 점군. 같은 이벤트가 세 보기와 CSV에 대응합니다.`,Gt("equation").textContent=`t = L√[(m/z)u / (2e|V|)]. ²⁸Si${qt.charge===1?"⁺":"²⁺"}: m/z ${(28/qt.charge).toFixed(1)} Da/e → ${Ya(28/qt.charge,qt.voltage).toFixed(2)} ns (이상식, 실측 아님).`,Gt("eventReadout").textContent=t?`최근 이벤트 #${t.event} · 합성 ${t.element}${t.charge}+ · ${t.massToCharge.toFixed(2)} Da/e · ${t.tof.toFixed(2)} ns · XY (${t.hitX.toFixed(2)}, ${t.hitY.toFixed(2)})`:"아직 취득한 이벤트가 없습니다.";const r={reconstruction:"3D 점군 · 이벤트 순서 재구성",spectrum:"질량 스펙트럼 · TOF 유래 m/z",detector:"검출기 · XY 히트맵"},a={reconstruction:"드래그 회전·스크롤 확대. Cu-rich 캡과 B-rich 층이 취득 순서대로 드러납니다.",spectrum:"취득한 이벤트의 m/z 히스토그램입니다. 전하 2+에서는 동일 질량의 m/z가 절반으로 이동합니다.",detector:"각 이온의 정규화 XY 도착 위치입니다. 필터는 표시만 바꾸고 취득 데이터는 보존합니다."};Gt("plotTitle").textContent=r[gn],Gt("plotDescription").textContent=a[gn],Gt("reconstruction").hidden=gn!=="reconstruction",Gt("dataCanvas").hidden=gn==="reconstruction",Gt("reconstructionHome").hidden=gn!=="reconstruction",gn!=="reconstruction"&&Ig(Gt("dataCanvas"),qt,gn,$i)}function ho(i){qt.configure(i),Un()}document.querySelectorAll("[data-mode]").forEach(i=>i.onclick=()=>{ho({mode:i.dataset.mode}),document.querySelectorAll("[data-mode]").forEach(t=>t.setAttribute("aria-pressed",String(t===i))),ei(qt.mode==="laser"?"laser":"pulser")});document.querySelectorAll("[data-view]").forEach(i=>i.onclick=()=>{gn=i.dataset.view,document.querySelectorAll("[data-view]").forEach(t=>t.setAttribute("aria-pressed",String(t===i))),Un()});Gt("elementSelect").onchange=i=>{$i=i.target.value,Un()};Gt("voltageInput").oninput=i=>ho({voltage:Number(i.target.value)});Gt("chargeSelect").onchange=i=>ho({charge:Number(i.target.value)});Gt("startButton").onclick=()=>{qt.status==="scanning"?qt.pause():qt.start(),Un()};Gt("resetButton").onclick=()=>{qt.reset(),Un()};Gt("homeButton").onclick=()=>ye==null?void 0:ye.home();Gt("reconstructionHome").onclick=()=>jn==null?void 0:jn.home();for(const[i,t]of[["focusButton","focus"],["explodeButton","explode"]])Gt(i).onclick=e=>{const n=e.currentTarget.getAttribute("aria-pressed")!=="true";e.currentTarget.setAttribute("aria-pressed",String(n)),ye==null||ye[t](n)};Gt("symptomSelect").onchange=i=>{const t=kl.find(e=>e.id===i.target.value);ye==null||ye.related((t==null?void 0:t.parts)||[]),document.querySelectorAll("[data-part]").forEach(e=>e.classList.toggle("related",(t==null?void 0:t.parts.includes(e.dataset.part))||!1)),Gt("guide").innerHTML=t?`<div class="guide-parts">${t.parts.map(e=>`<button data-related="${e}">${ss.find(n=>n.id===e).ko}</button>`).join("")}</div><ol>${t.steps.map(e=>`<li>${e}</li>`).join("")}</ol>`:"",document.querySelectorAll("[data-related]").forEach(e=>e.onclick=()=>ei(e.dataset.related))};Gt("aboutButton").onclick=()=>Gt("aboutDialog").showModal();Gt("closeAbout").onclick=()=>Gt("aboutDialog").close();Gt("exportButton").onclick=()=>{if(!qt.index)return;const i=URL.createObjectURL(new Blob(["\uFEFF"+qt.csv()],{type:"text/csv;charset=utf-8"})),t=document.createElement("a");t.href=i,t.download=`apt-${qt.mode}-${qt.charge}plus.csv`,t.click(),setTimeout(()=>URL.revokeObjectURL(i),1e3)};Un();let Fl=-1,Ol=0;function Ic(i){const t=ji.step(i);qt.tick(t),(qt.index!==Fl||qt.status==="scanning")&&i-Ol>80&&(Un(),Fl=qt.index,Ol=i),ye==null||ye.render(qt,ji.realDelta,ji.elapsed),gn==="reconstruction"&&(jn==null||jn.render(qt,$i)),requestAnimationFrame(Ic)}document.addEventListener("visibilitychange",()=>{document.hidden&&(qt.pause(),Un()),ji.resetTimestamp()});requestAnimationFrame(Ic);I_(ye,ji,{kind:"apt",engine:qt,parts:ss,selectPart:ei});
